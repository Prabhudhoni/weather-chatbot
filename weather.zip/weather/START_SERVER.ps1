# Weather Info Assistant - Local Server Starter (PowerShell)
# This script starts a local web server to run the application

Write-Host ""
Write-Host "========================================"
Write-Host "Weather Info Assistant - Server Startup"
Write-Host "========================================"
Write-Host ""

# Check if Python is installed
try {
    $pythonVersion = python --version 2>&1
    Write-Host "Python found: $pythonVersion"
} catch {
    Write-Host "ERROR: Python is not installed or not in PATH"
    Write-Host ""
    Write-Host "Please install Python from: https://www.python.org/downloads/"
    Write-Host "Make sure to check 'Add Python to PATH' during installation"
    Write-Host ""
    Read-Host "Press Enter to exit"
    exit 1
}

# Get the current directory
$currentDir = Get-Location

Write-Host "Starting local web server..."
Write-Host ""
Write-Host "========================================"
Write-Host "Server Information:"
Write-Host "========================================"
Write-Host "URL: http://localhost:8000"
Write-Host "Port: 8000"
Write-Host "Directory: $currentDir"
Write-Host ""
Write-Host "Press Ctrl+C to stop the server"
Write-Host "========================================"
Write-Host ""

# Start Python HTTP server
python -m http.server 8000
