// ===========================
// WEATHER INFO ASSISTANT
// Main Script Module
// ===========================

// ===========================
// MODULE 1: UI MODULE
// ===========================

const UIModule = {
    // Display current weather cards
    displayCurrentWeather(weatherData) {
        const container = document.getElementById('currentWeatherContainer');
        container.innerHTML = '';

        if (!weatherData || weatherData.length === 0) {
            container.innerHTML = '<p class="error-message">No weather data available</p>';
            return;
        }

        weatherData.forEach(city => {
            const card = this.createWeatherCard(city);
            container.appendChild(card);
        });
    },

    // Create a weather card element
    createWeatherCard(data) {
        const card = document.createElement('div');
        card.className = 'weather-card';

        const weatherIcon = this.getWeatherIcon(data.condition);
        const tempCelsius = Math.round(data.temperature);

        const location = `${data.village ? data.village + ', ' : ''}${data.district ? data.district + ', ' : ''}${data.state ? data.state + ', ' : ''}${data.country ? data.country : ''}`;
        
        card.innerHTML = `
            <div class="city-name">${data.city}</div>
            <div class="location-info" style="font-size: 0.75rem; color: #666; margin-bottom: 0.5rem;">📍 ${location}</div>
            <div class="weather-icon">${weatherIcon}</div>
            <div class="temperature">${tempCelsius}°C</div>
            <div class="weather-condition">${data.condition}</div>
            <div class="weather-details">
                <div class="detail-item">
                    <span class="detail-label">💧 Humidity</span>
                    <span class="detail-value">${data.humidity}%</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">💨 Wind Speed</span>
                    <span class="detail-value">${data.windSpeed} km/h</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">🌡️ Feels Like</span>
                    <span class="detail-value">${Math.round(data.feelsLike)}°C</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">🔽 Pressure</span>
                    <span class="detail-value">${data.pressure} mb</span>
                </div>
            </div>
        `;

        return card;
    },

    // Display 5-day forecast
    displayForecast(forecastData) {
        const container = document.getElementById('forecastContainer');
        container.innerHTML = '';

        if (!forecastData || forecastData.length === 0) {
            container.innerHTML = '<p class="error-message">No forecast data available</p>';
            return;
        }

        forecastData.forEach(day => {
            const card = this.createForecastCard(day);
            container.appendChild(card);
        });
    },

    // Create a forecast card element
    createForecastCard(day) {
        const card = document.createElement('div');
        card.className = 'forecast-card';

        const weatherIcon = this.getWeatherIcon(day.condition);
        const maxTemp = Math.round(day.maxTemp);
        const minTemp = Math.round(day.minTemp);

        card.innerHTML = `
            <div class="forecast-date">${day.date}</div>
            <div class="forecast-icon">${weatherIcon}</div>
            <div class="forecast-temp">${maxTemp}°C / ${minTemp}°C</div>
            <div class="forecast-condition">${day.condition}</div>
            <div class="forecast-details">
                <div>💧 ${day.humidity}%</div>
                <div>💨 ${day.windSpeed} km/h</div>
            </div>
        `;

        return card;
    },

    // Display weather alerts
    displayAlerts(alerts) {
        const container = document.getElementById('alertsContainer');
        container.innerHTML = '';

        if (!alerts || alerts.length === 0) {
            container.innerHTML = '<div class="no-alerts">✅ No weather alerts at this time</div>';
            return;
        }

        alerts.forEach(alert => {
            const alertBox = document.createElement('div');
            alertBox.className = `alert-box ${alert.type}`;

            const icon = this.getAlertIcon(alert.type);

            alertBox.innerHTML = `
                <div class="alert-title">${icon} ${alert.title}</div>
                <div class="alert-message">${alert.message}</div>
            `;

            container.appendChild(alertBox);
        });
    },

    // Get weather icon based on condition
    getWeatherIcon(condition) {
        const conditionLower = condition.toLowerCase();

        if (conditionLower.includes('sunny') || conditionLower.includes('clear')) return '☀️';
        if (conditionLower.includes('cloud')) return '☁️';
        if (conditionLower.includes('rain')) return '🌧️';
        if (conditionLower.includes('snow')) return '❄️';
        if (conditionLower.includes('storm') || conditionLower.includes('thunder')) return '⛈️';
        if (conditionLower.includes('fog') || conditionLower.includes('mist')) return '🌫️';
        if (conditionLower.includes('wind')) return '💨';
        if (conditionLower.includes('hail')) return '🧊';
        if (conditionLower.includes('drizzle')) return '🌦️';

        return '🌤️';
    },

    // Get alert icon based on type
    getAlertIcon(type) {
        switch (type) {
            case 'warning': return '⚠️';
            case 'danger': return '🚨';
            case 'info': return 'ℹ️';
            default: return '📢';
        }
    },

    // Show loading state
    showLoading(containerId) {
        const container = document.getElementById(containerId);
        container.innerHTML = '<div class="loading"></div>';
    },

    // Show error message
    showError(containerId, message) {
        const container = document.getElementById(containerId);
        container.innerHTML = `<div class="error-message">❌ ${message}</div>`;
    }
};

// ===========================
// MODULE 2: DATASET LOADER MODULE
// ===========================

const DatasetLoaderModule = {
    dataset: null,

    // Load dataset from JSON file (supports comprehensive, villages, expanded, and original datasets)
    async loadDataset(datasetType = 'comprehensive') {
        try {
            let filename;
            if (datasetType === 'comprehensive') {
                filename = 'dataset-comprehensive-all.json';
            } else if (datasetType === 'villages') {
                filename = 'dataset-villages.json';
            } else if (datasetType === 'expanded') {
                filename = 'dataset-expanded.json';
            } else {
                filename = 'dataset.json';
            }
            
            const response = await fetch(filename);
            if (!response.ok) {
                // Fallback chain: comprehensive -> villages -> expanded -> original
                if (datasetType === 'comprehensive') {
                    console.warn('Comprehensive dataset not found, trying villages dataset');
                    return this.loadDataset('villages');
                } else if (datasetType === 'villages') {
                    console.warn('Villages dataset not found, trying expanded dataset');
                    return this.loadDataset('expanded');
                } else if (datasetType === 'expanded') {
                    console.warn('Expanded dataset not found, trying original dataset');
                    return this.loadDataset('original');
                }
                throw new Error('Failed to load all datasets');
            }
            this.dataset = await response.json();
            console.log(`✅ Successfully loaded ${datasetType} dataset with ${this.dataset.cities.length} cities`);
            return this.dataset;
        } catch (error) {
            console.error('Error loading dataset:', error);
            // Show user-friendly error message
            const message = 'Unable to load weather data. Please ensure you are running the application through a web server (not file://)';
            UIModule.showError('currentWeatherContainer', message);
            return null;
        }
    },

    // Get all cities from dataset
    getAllCities() {
        return this.dataset?.cities || [];
    },

    // Get specific city data
    getCityData(cityName) {
        if (!this.dataset) return null;
        return this.dataset.cities.find(city => 
            city.city.toLowerCase() === cityName.toLowerCase()
        );
    },

    // Get all alerts
    getAllAlerts() {
        return this.dataset?.alerts || [];
    },

    // Get forecast for a city
    getCityForecast(cityName) {
        const city = this.getCityData(cityName);
        return city?.forecast || [];
    }
};

// ===========================
// MODULE 3: WEATHER FETCH MODULE
// ===========================

const WeatherFetchModule = {
    // Fetch weather from dataset
    async fetchWeatherFromDataset(cityName) {
        const cityData = DatasetLoaderModule.getCityData(cityName);
        if (!cityData) {
            throw new Error(`City "${cityName}" not found in dataset`);
        }
        return cityData;
    },

    // Get all weather data
    async getAllWeatherData() {
        return DatasetLoaderModule.getAllCities();
    }
};

// ===========================
// MODULE 4: WEATHER FORECAST MODULE
// ===========================

const WeatherForecastModule = {
    // Get 5-day forecast for a city
    async getForecast(cityName) {
        try {
            const forecast = DatasetLoaderModule.getCityForecast(cityName);
            if (!forecast || forecast.length === 0) {
                throw new Error('No forecast data available');
            }
            return forecast;
        } catch (error) {
            console.error('Error fetching forecast:', error);
            return [];
        }
    },

    // Generate forecast from current weather (fallback)
    generateForecast(currentWeather) {
        const forecast = [];
        const conditions = ['Sunny', 'Cloudy', 'Rainy', 'Partly Cloudy', 'Stormy'];

        for (let i = 1; i <= 5; i++) {
            const date = new Date();
            date.setDate(date.getDate() + i);

            forecast.push({
                date: date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' }),
                condition: conditions[Math.floor(Math.random() * conditions.length)],
                maxTemp: currentWeather.temperature + Math.random() * 5,
                minTemp: currentWeather.temperature - Math.random() * 5,
                humidity: Math.floor(Math.random() * 100),
                windSpeed: Math.floor(Math.random() * 30)
            });
        }

        return forecast;
    }
};

// ===========================
// MODULE 5: ALERTS MODULE
// ===========================

const AlertsModule = {
    // Get all alerts
    getAllAlerts() {
        return DatasetLoaderModule.getAllAlerts();
    },

    // Get alerts for specific city
    getAlertsForCity(cityName) {
        const allAlerts = this.getAllAlerts();
        return allAlerts.filter(alert => 
            alert.city.toLowerCase() === cityName.toLowerCase()
        );
    },

    // Generate alerts based on weather conditions
    generateAlerts(weatherData) {
        const alerts = [];

        if (weatherData.temperature > 40) {
            alerts.push({
                type: 'danger',
                title: '🔥 Extreme Heat Warning',
                message: `Temperature is ${Math.round(weatherData.temperature)}°C. Stay hydrated and avoid prolonged sun exposure.`
            });
        }

        if (weatherData.temperature < 0) {
            alerts.push({
                type: 'warning',
                title: '❄️ Frost Warning',
                message: `Temperature is ${Math.round(weatherData.temperature)}°C. Roads may be icy.`
            });
        }

        if (weatherData.windSpeed > 50) {
            alerts.push({
                type: 'warning',
                title: '💨 High Wind Warning',
                message: `Wind speed is ${weatherData.windSpeed} km/h. Secure loose objects.`
            });
        }

        if (weatherData.condition.toLowerCase().includes('rain')) {
            alerts.push({
                type: 'info',
                title: '🌧️ Rain Expected',
                message: 'Carry an umbrella and be cautious while driving.'
            });
        }

        if (weatherData.humidity > 80) {
            alerts.push({
                type: 'info',
                title: '💧 High Humidity',
                message: `Humidity is ${weatherData.humidity}%. It may feel more humid than the actual temperature.`
            });
        }

        return alerts;
    }
};

// ===========================
// MAIN APPLICATION LOGIC
// ===========================

class WeatherApp {
    constructor() {
        this.currentCity = null;
        this.init();
    }

    async init() {
        // Load dataset
        await DatasetLoaderModule.loadDataset();

        // Setup event listeners
        this.setupEventListeners();

        // Load initial data
        await this.loadInitialData();
    }

    setupEventListeners() {
        // Search functionality
        const searchBtn = document.getElementById('searchBtn');
        const cityInput = document.getElementById('cityInput');

        searchBtn.addEventListener('click', () => this.handleSearch());
        cityInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.handleSearch();
        });

        // Search suggestions
        cityInput.addEventListener('input', (e) => this.showSearchSuggestions(e.target.value));

        // Hide suggestions when clicking outside
        document.addEventListener('click', (e) => {
            if (e.target !== cityInput) {
                document.getElementById('searchSuggestions').classList.remove('active');
            }
        });
    }

    async loadInitialData() {
        try {
            UIModule.showLoading('currentWeatherContainer');
            UIModule.showLoading('forecastContainer');
            UIModule.showLoading('alertsContainer');

            // Load all cities
            const allCities = DatasetLoaderModule.getAllCities();
            UIModule.displayCurrentWeather(allCities);

            // Load alerts
            const alerts = AlertsModule.getAllAlerts();
            UIModule.displayAlerts(alerts);

            // Load forecast for first city
            if (allCities.length > 0) {
                const forecast = await WeatherForecastModule.getForecast(allCities[0].city);
                UIModule.displayForecast(forecast);
            }
        } catch (error) {
            console.error('Error loading initial data:', error);
        }
    }

    async handleSearch() {
        const cityInput = document.getElementById('cityInput');
        const cityName = cityInput.value.trim();

        if (!cityName) {
            UIModule.showError('currentWeatherContainer', 'Please enter a city name');
            return;
        }

        try {
            UIModule.showLoading('currentWeatherContainer');
            UIModule.showLoading('forecastContainer');
            UIModule.showLoading('alertsContainer');

            // Fetch weather data
            const weatherData = await WeatherFetchModule.fetchWeatherFromDataset(cityName);
            UIModule.displayCurrentWeather([weatherData]);

            // Fetch forecast
            const forecast = await WeatherForecastModule.getForecast(cityName);
            UIModule.displayForecast(forecast);

            // Generate and display alerts
            const alerts = AlertsModule.generateAlerts(weatherData);
            UIModule.displayAlerts(alerts);

            // Clear input and suggestions
            cityInput.value = '';
            document.getElementById('searchSuggestions').classList.remove('active');

            this.currentCity = cityName;
        } catch (error) {
            UIModule.showError('currentWeatherContainer', error.message);
            UIModule.displayAlerts([]);
        }
    }

    showSearchSuggestions(searchTerm) {
        const suggestionsContainer = document.getElementById('searchSuggestions');

        if (!searchTerm) {
            suggestionsContainer.classList.remove('active');
            return;
        }

        const allCities = DatasetLoaderModule.getAllCities();
        const filtered = allCities.filter(city =>
            city.city.toLowerCase().includes(searchTerm.toLowerCase())
        );

        if (filtered.length === 0) {
            suggestionsContainer.classList.remove('active');
            return;
        }

        suggestionsContainer.innerHTML = filtered.map(city => `
            <div class="suggestion-item" onclick="app.selectCity('${city.city}')">${city.city}</div>
        `).join('');

        suggestionsContainer.classList.add('active');
    }

    selectCity(cityName) {
        document.getElementById('cityInput').value = cityName;
        this.handleSearch();
    }
}

// Initialize app when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.app = new WeatherApp();
});
