# 🚀 Quick Start Guide - Weather Info Assistant

## ⚡ Get Started in 30 Seconds

### Option 1: Direct Browser Opening (Easiest)
1. Navigate to the `WeatherInfoAssistant` folder
2. Double-click `index.html`
3. The application opens in your default browser
4. **Done!** Start exploring weather data

### Option 2: Using a Local Server (Recommended)

#### On Windows (PowerShell)
```powershell
# Navigate to the project folder
cd "c:\Users\prabh\OneDrive\Desktop\weather"

# Start Python server
python -m http.server 8000

# Open browser and go to: http://localhost:8000
```

#### On Mac/Linux (Terminal)
```bash
cd ~/path/to/WeatherInfoAssistant
python3 -m http.server 8000
# Then open: http://localhost:8000
```

---

## 📖 What You'll See

### 🏠 Homepage
- **Navigation Bar**: Links to Home, Forecast, and Alerts
- **Search Bar**: Search for any city in the dataset
- **Current Weather Cards**: Shows weather for all 10 cities
- **5-Day Forecast**: Forecast for the selected city
- **Weather Alerts**: Real-time alerts and warnings

### 💬 Chatbot
- **Floating Chat Icon** (bottom-right): Click to open chat
- **Chat Window**: Ask weather questions naturally
- **AI Responses**: Powered by Google Generative AI

---

## 🎮 How to Use

### 1. View Weather
- Scroll down to see all cities' current weather
- Each card shows: Temperature, Humidity, Wind Speed, Pressure

### 2. Search for a City
- Type city name in search bar
- Select from suggestions
- Weather updates instantly

### 3. Check Forecast
- Scroll to "5-Day Forecast" section
- See temperature trends and conditions

### 4. View Alerts
- Scroll to "Weather Alerts" section
- See warnings and advisories

### 5. Chat with Bot
- Click the 💬 icon (bottom-right)
- Type your question: "Weather in Chennai?"
- Get instant AI-powered response

---

## 📊 Available Cities

The dataset includes weather for:
1. **Chennai** - Hot and humid
2. **Mumbai** - Coastal weather
3. **Delhi** - Cold with fog
4. **Bangalore** - Pleasant climate
5. **Kolkata** - Moderate weather
6. **Hyderabad** - Sunny skies
7. **Pune** - Clear weather
8. **Jaipur** - Desert climate
9. **Ahmedabad** - Sunny and warm
10. **Lucknow** - Foggy mornings

---

## 🤖 Chatbot Examples

Try asking:
- "Weather in Mumbai?"
- "Will it rain today?"
- "What's the temperature in Delhi?"
- "Is it cold in Bangalore?"
- "Tell me about weather in Pune"
- "What's the humidity in Chennai?"

---

## ⚙️ System Requirements

- ✅ Modern web browser (Chrome, Firefox, Safari, Edge)
- ✅ Internet connection (for chatbot)
- ✅ No installation needed
- ✅ No server setup required

---

## 🎨 Features Overview

| Feature | Description |
|---------|-------------|
| 🌡️ Current Weather | Real-time temperature and conditions |
| 📅 5-Day Forecast | Future weather predictions |
| ⚠️ Alerts | Weather warnings and advisories |
| 🤖 AI Chatbot | Natural language weather queries |
| 🔍 Search | Find weather for any city |
| 📱 Responsive | Works on all devices |
| 🎯 Modern UI | Beautiful gradient design |

---

## 🆘 Troubleshooting

### Issue: Page shows blank
- **Solution**: Refresh the page (Ctrl+R or Cmd+R)
- Check browser console (F12) for errors

### Issue: Chatbot not responding
- **Solution**: Check internet connection
- Refresh page and try again
- Check browser console for API errors

### Issue: Weather data not loading
- **Solution**: Ensure `dataset.json` is in the same folder
- Refresh the page
- Clear browser cache

### Issue: Search not working
- **Solution**: City name must match dataset exactly
- Try selecting from suggestions dropdown
- Check spelling

---

## 📝 File Descriptions

| File | Purpose |
|------|---------|
| `index.html` | Main webpage structure |
| `style.css` | Main styling and layout |
| `script.js` | Weather app logic and modules |
| `chatbot.js` | Chatbot AI integration |
| `chatbot-style.css` | Chatbot styling |
| `dataset.json` | Weather data for 10 cities |
| `README.md` | Full documentation |
| `QUICKSTART.md` | This file |

---

## 🎯 Next Steps

1. ✅ Open the application
2. ✅ Explore current weather
3. ✅ Try the search feature
4. ✅ Check the 5-day forecast
5. ✅ Open the chatbot and ask questions
6. ✅ Check weather alerts

---

## 💡 Pro Tips

- **Mobile**: Tap the chat icon to open chatbot on mobile
- **Search**: Type city name and select from dropdown
- **Forecast**: Click on a city card to see its forecast
- **Alerts**: Scroll down to see all active weather alerts
- **Responsive**: Resize browser to see mobile layout

---

## 🔗 API Information

### Google Generative AI (Chatbot)
- **Service**: Google Generative AI (Gemini)
- **API Key**: Pre-configured (included in code)
- **Rate Limit**: 60 requests per minute
- **Cost**: Free tier available

### Local Dataset
- **Format**: JSON
- **Cities**: 10 major Indian cities
- **Data**: Temperature, humidity, wind speed, pressure, 5-day forecast

---

## 📞 Quick Help

**Q: Can I add more cities?**
A: Yes! Edit `dataset.json` and add new city objects

**Q: Can I use my own API key?**
A: Yes! Edit `chatbot.js` and replace the API key

**Q: Does it work offline?**
A: Partially - weather display works, but chatbot needs internet

**Q: Is it mobile-friendly?**
A: Yes! Fully responsive on all devices

---

## 🎉 You're All Set!

Enjoy exploring weather information with the Weather Info Assistant! 🌤️

For detailed documentation, see `README.md`
