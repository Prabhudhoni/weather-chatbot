// ===========================
// CHATBOT MODULE
// Weather Assistant Chatbot
// ===========================

const ChatbotModule = {
    // Configuration
    config: {
        apiKey: 'AIzaSyB1ChlVjhz2Z717cYX-W8IUXslDFURsCs0', // Google Generative AI Key
        openWeatherMapKey: '', // Will be set by user or use fallback
        apiEndpoint: 'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent'
    },

    // Initialize chatbot
    init() {
        this.setupEventListeners();
        this.displayWelcomeMessage();
    },

    // Setup event listeners
    setupEventListeners() {
        const chatbotIcon = document.getElementById('chatbotIcon');
        const closeChatbot = document.getElementById('closeChatbot');
        const sendBtn = document.getElementById('sendBtn');
        const chatInput = document.getElementById('chatInput');

        chatbotIcon.addEventListener('click', () => this.toggleChatbot());
        closeChatbot.addEventListener('click', () => this.closeChatbot());
        sendBtn.addEventListener('click', () => this.sendMessage());
        chatInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });
    },

    // Toggle chatbot window
    toggleChatbot() {
        const chatbotWindow = document.getElementById('chatbotWindow');
        chatbotWindow.classList.toggle('active');

        if (chatbotWindow.classList.contains('active')) {
            document.getElementById('chatInput').focus();
        }
    },

    // Close chatbot
    closeChatbot() {
        document.getElementById('chatbotWindow').classList.remove('active');
    },

    // Display welcome message
    displayWelcomeMessage() {
        const messagesContainer = document.getElementById('chatMessages');
        const welcomeMsg = document.createElement('div');
        welcomeMsg.className = 'chat-message message-bot';
        welcomeMsg.innerHTML = `
            <div class="message-content">
                <div class="welcome-message">
                    <strong>👋 Welcome to Weather Assistant!</strong><br>
                    Ask me anything about weather. Try:<br>
                    • "Weather in Chennai?"<br>
                    • "Will it rain today?"<br>
                    • "What's the temperature in London?"
                </div>
            </div>
        `;
        messagesContainer.appendChild(welcomeMsg);
        this.scrollToBottom();
    },

    // Send message
    async sendMessage() {
        const chatInput = document.getElementById('chatInput');
        const message = chatInput.value.trim();

        if (!message) return;

        // Display user message
        this.displayMessage(message, 'user');
        chatInput.value = '';

        // Show typing indicator
        this.showTypingIndicator();

        try {
            // First check if it's a weather query for a city in our dataset
            const weatherInfo = this.extractWeatherQuery(message);
            let response;

            if (weatherInfo.city) {
                // Try to get weather from our dataset
                const cityData = this.getWeatherFromDataset(weatherInfo.city);
                if (cityData) {
                    response = this.formatWeatherResponse(cityData);
                } else {
                    // Try AI for unknown cities
                    response = await this.getAIResponse(message);
                }
            } else {
                // General question - use AI
                response = await this.getAIResponse(message);
            }
            
            // Remove typing indicator
            this.removeTypingIndicator();

            // Display bot response
            this.displayMessage(response, 'bot');
        } catch (error) {
            this.removeTypingIndicator();
            console.error('Chatbot error:', error);
            this.displayMessage(this.getFallbackResponse(message), 'bot');
        }
    },

    // Display message in chat
    displayMessage(text, sender) {
        const messagesContainer = document.getElementById('chatMessages');
        const messageDiv = document.createElement('div');
        messageDiv.className = `chat-message message-${sender}`;

        const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

        messageDiv.innerHTML = `
            <div>
                <div class="message-content">${this.escapeHtml(text)}</div>
                <div class="message-timestamp">${timestamp}</div>
            </div>
        `;

        messagesContainer.appendChild(messageDiv);
        this.scrollToBottom();
    },

    // Show typing indicator
    showTypingIndicator() {
        const messagesContainer = document.getElementById('chatMessages');
        const typingDiv = document.createElement('div');
        typingDiv.className = 'chat-message message-bot';
        typingDiv.id = 'typingIndicator';
        typingDiv.innerHTML = `
            <div class="typing-indicator">
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
                <div class="typing-dot"></div>
            </div>
        `;
        messagesContainer.appendChild(typingDiv);
        this.scrollToBottom();
    },

    // Remove typing indicator
    removeTypingIndicator() {
        const typingIndicator = document.getElementById('typingIndicator');
        if (typingIndicator) {
            typingIndicator.remove();
        }
    },

    // Get AI response using Google Generative AI
    async getAIResponse(userMessage) {
        try {
            // First, try to extract weather-specific information
            const weatherInfo = this.extractWeatherQuery(userMessage);

            // Build the prompt
            let prompt = `You are a helpful weather assistant. Answer the following question about weather:\n\n"${userMessage}"\n\n`;

            if (weatherInfo.city) {
                prompt += `The user is asking about: ${weatherInfo.city}\n`;
            }

            prompt += `Provide a helpful, concise weather-related response. If you don't have real-time data, provide general weather information and suggestions.`;

            // Call Google Generative AI API
            const response = await fetch(
                `${this.config.apiEndpoint}?key=${this.config.apiKey}`,
                {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        contents: [{
                            parts: [{
                                text: prompt
                            }]
                        }]
                    })
                }
            );

            if (!response.ok) {
                throw new Error(`API error: ${response.status}`);
            }

            const data = await response.json();

            // Extract text from response
            if (data.candidates && data.candidates[0] && data.candidates[0].content && data.candidates[0].content.parts && data.candidates[0].content.parts[0]) {
                return data.candidates[0].content.parts[0].text;
            }

            throw new Error('Invalid API response format');
        } catch (error) {
            console.error('Error getting AI response:', error);
            return this.getFallbackResponse(userMessage);
        }
    },

    // Extract weather query information
    extractWeatherQuery(message) {
        const cityRegex = /(?:in|at|for|weather in|weather at)\s+([A-Za-z\s]+?)(?:\?|$|\.)/i;
        const match = message.match(cityRegex);

        return {
            city: match ? match[1].trim() : null,
            isWeatherQuery: /weather|temperature|rain|snow|wind|humidity|forecast|climate|storm|sunny|cloudy|condition/i.test(message)
        };
    },

    // Get weather from our dataset
    getWeatherFromDataset(cityName) {
        try {
            if (typeof DatasetLoaderModule !== 'undefined' && DatasetLoaderModule.getCityData) {
                return DatasetLoaderModule.getCityData(cityName);
            }
            return null;
        } catch (error) {
            console.error('Error getting weather from dataset:', error);
            return null;
        }
    },

    // Format weather data into readable response
    formatWeatherResponse(weatherData) {
        const location = `${weatherData.village ? weatherData.village + ', ' : ''}${weatherData.district ? weatherData.district + ', ' : ''}${weatherData.state ? weatherData.state + ', ' : ''}${weatherData.country ? weatherData.country : ''}`;
        
        return `🌤️ **Weather in ${weatherData.city}**
📍 Location: ${location}

🌡️ Temperature: ${Math.round(weatherData.temperature)}°C
☁️ Condition: ${weatherData.condition}
💧 Humidity: ${weatherData.humidity}%
💨 Wind Speed: ${weatherData.windSpeed} km/h
🤔 Feels Like: ${Math.round(weatherData.feelsLike)}°C
🔽 Pressure: ${weatherData.pressure} mb

${this.getWeatherAdvice(weatherData)}`;
    },

    // Get weather-specific advice
    getWeatherAdvice(weatherData) {
        const temp = weatherData.temperature;
        const condition = weatherData.condition.toLowerCase();
        const humidity = weatherData.humidity;

        let advice = '💡 **Advice:** ';

        if (temp > 35) {
            advice += 'It\'s very hot! Stay hydrated and use sunscreen. ☀️';
        } else if (temp < 5) {
            advice += 'It\'s cold! Wear warm clothes and layers. ❄️';
        } else if (temp >= 20 && temp <= 25) {
            advice += 'Perfect weather! Great for outdoor activities. 🌞';
        } else if (temp >= 15 && temp < 20) {
            advice += 'Pleasant weather! A light jacket might be needed. 🧥';
        }

        if (condition.includes('rain')) {
            advice += ' Carry an umbrella! 🌧️';
        } else if (condition.includes('sunny') || condition.includes('clear')) {
            advice += ' Great day for outdoor activities! ☀️';
        }

        if (humidity > 80) {
            advice += ' High humidity - it might feel more humid than the actual temperature. 💧';
        }

        return advice;
    },

    // Fallback response when API fails
    getFallbackResponse(userMessage) {
        const responses = {
            greeting: [
                '👋 Hello! I\'m your weather assistant. Ask me about weather conditions, forecasts, or climate information.',
                'Hi there! 🌤️ I\'m here to help with weather-related questions. What would you like to know?'
            ],
            weather: [
                '🌤️ I can help you with weather information! Please specify a city or location.',
                '☁️ To get weather information, please tell me which city you\'d like to know about.',
                '🌧️ Weather queries are my specialty! Which location would you like weather for?'
            ],
            rain: [
                '🌧️ Rain is a common weather phenomenon. For specific rain forecasts, please mention a city.',
                '💧 To check if it will rain, please tell me your location or the city you\'re interested in.'
            ],
            temperature: [
                '🌡️ Temperature varies by location. Which city would you like to know the temperature for?',
                '🔥 To get temperature information, please specify a location.'
            ],
            default: [
                '🤔 That\'s an interesting question! I\'m specifically trained to help with weather-related queries. Try asking about weather in a specific city.',
                '💭 I\'m a weather assistant. Could you ask me something weather-related? For example, "Weather in Mumbai?"'
            ]
        };

        const messageLower = userMessage.toLowerCase();

        if (/hello|hi|hey|greet/i.test(messageLower)) {
            return this.getRandomResponse(responses.greeting);
        } else if (/weather|condition|climate/i.test(messageLower)) {
            return this.getRandomResponse(responses.weather);
        } else if (/rain|rainy/i.test(messageLower)) {
            return this.getRandomResponse(responses.rain);
        } else if (/temperature|temp|hot|cold/i.test(messageLower)) {
            return this.getRandomResponse(responses.temperature);
        } else {
            return this.getRandomResponse(responses.default);
        }
    },

    // Get random response from array
    getRandomResponse(responses) {
        return responses[Math.floor(Math.random() * responses.length)];
    },

    // Escape HTML to prevent XSS
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    },

    // Scroll to bottom of messages
    scrollToBottom() {
        const messagesContainer = document.getElementById('chatMessages');
        setTimeout(() => {
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }, 0);
    }
};

// ===========================
// ENHANCED WEATHER CHATBOT
// With Real-time Weather Integration
// ===========================

const EnhancedChatbot = {
    // Get weather data for chatbot responses
    async getWeatherForCity(cityName) {
        try {
            // Try to get from dataset first
            if (window.app && window.app.currentCity) {
                const cityData = DatasetLoaderModule.getCityData(cityName);
                if (cityData) {
                    return this.formatWeatherResponse(cityData);
                }
            }

            // Fallback to generic response
            return `I don't have real-time data for ${cityName} in my current dataset. However, I can help you search for it on the main page!`;
        } catch (error) {
            console.error('Error getting weather:', error);
            return 'Unable to fetch weather data at the moment.';
        }
    },

    // Format weather data into readable response
    formatWeatherResponse(weatherData) {
        return `
🌤️ **Weather in ${weatherData.city}**

Temperature: ${Math.round(weatherData.temperature)}°C
Condition: ${weatherData.condition}
Humidity: ${weatherData.humidity}%
Wind Speed: ${weatherData.windSpeed} km/h
Feels Like: ${Math.round(weatherData.feelsLike)}°C
Pressure: ${weatherData.pressure} mb

${this.getWeatherAdvice(weatherData)}
        `.trim();
    },

    // Get weather-specific advice
    getWeatherAdvice(weatherData) {
        const temp = weatherData.temperature;
        const condition = weatherData.condition.toLowerCase();
        const humidity = weatherData.humidity;

        let advice = '💡 **Advice:** ';

        if (temp > 35) {
            advice += 'It\'s very hot! Stay hydrated and use sunscreen. ☀️';
        } else if (temp < 5) {
            advice += 'It\'s cold! Wear warm clothes and layers. ❄️';
        } else if (temp >= 20 && temp <= 25) {
            advice += 'Perfect weather! Great for outdoor activities. 🌞';
        }

        if (condition.includes('rain')) {
            advice += ' Carry an umbrella! 🌧️';
        }

        if (humidity > 80) {
            advice += ' High humidity - it might feel more humid than the actual temperature. 💧';
        }

        return advice;
    }
};

// Initialize chatbot when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    ChatbotModule.init();
});
