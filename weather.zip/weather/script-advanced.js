// ===========================
// WEATHERPRO - ADVANCED SCRIPT
// ===========================

const WeatherApp = {
    config: {
        apiKey: 'AIzaSyB1ChlVjhz2Z717cYX-W8IUXslDFURsCs0',
        tempUnit: 'celsius',
        windUnit: 'kmh',
        pressureUnit: 'mb',
        timeFormat: '24h',
        theme: 'dark',
        refreshInterval: 10
    },
    
    currentCity: null,
    weatherData: {},
    historicalData: [],
    charts: {},
    
    init() {
        this.setupEventListeners();
        this.loadSettings();
        this.initializeMap();
        this.displayWelcome();
        this.startAutoRefresh();
    },
    
    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => this.switchSection(e));
        });
        
        // Search
        document.getElementById('searchBtn').addEventListener('click', () => this.searchCity());
        document.getElementById('citySearch').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.searchCity();
        });
        
        // GPS
        document.getElementById('gpsBtn').addEventListener('click', () => this.useGPS());
        
        // Quick Actions
        document.getElementById('downloadBtn').addEventListener('click', () => this.showDownloadModal());
        document.getElementById('shareBtn').addEventListener('click', () => this.shareWeather());
        document.getElementById('alertsBtn').addEventListener('click', () => this.showAlerts());
        document.getElementById('compareBtn').addEventListener('click', () => this.compareWeather());
        
        // Settings
        document.querySelectorAll('.toggle-btn').forEach(btn => {
            btn.addEventListener('click', (e) => this.handleToggle(e));
        });
        
        document.getElementById('clearCacheBtn').addEventListener('click', () => this.clearCache());
        document.getElementById('exportSettingsBtn').addEventListener('click', () => this.exportSettings());
        document.getElementById('importSettingsBtn').addEventListener('click', () => this.importSettings());
        
        // Theme
        document.getElementById('themeToggle').addEventListener('click', () => this.toggleTheme());
        
        // Modal
        document.querySelectorAll('.close').forEach(btn => {
            btn.addEventListener('click', (e) => e.target.closest('.modal').classList.remove('active'));
        });
    },
    
    switchSection(e) {
        e.preventDefault();
        const section = e.target.closest('.nav-link').dataset.section;
        
        document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
        document.getElementById(section).classList.add('active');
        
        document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
        e.target.closest('.nav-link').classList.add('active');
        
        if (section === 'analytics') this.initializeCharts();
        if (section === 'map') this.updateMap();
    },
    
    async searchCity() {
        const city = document.getElementById('citySearch').value.trim();
        if (!city) return;
        
        try {
            const data = await this.fetchWeatherData(city);
            this.displayCurrentWeather(data);
            this.currentCity = city;
            this.saveToHistory(data);
        } catch (error) {
            console.error('Error fetching weather:', error);
            alert('City not found. Please try another.');
        }
    },
    
    async fetchWeatherData(city) {
        // Simulated weather data - replace with real API
        return {
            city: city,
            temperature: 28,
            condition: 'Partly Cloudy',
            humidity: 65,
            windSpeed: 12,
            pressure: 1013,
            feelsLike: 30,
            visibility: 10,
            uvIndex: 6,
            forecast: this.generateForecast()
        };
    },
    
    generateForecast() {
        const forecast = [];
        for (let i = 0; i < 5; i++) {
            forecast.push({
                date: new Date(Date.now() + i * 86400000).toLocaleDateString('en-US', { weekday: 'short' }),
                maxTemp: 30 - i,
                minTemp: 20 - i,
                condition: ['Sunny', 'Cloudy', 'Rainy', 'Partly Cloudy', 'Clear'][i]
            });
        }
        return forecast;
    },
    
    displayCurrentWeather(data) {
        document.getElementById('currentCity').textContent = data.city;
        document.getElementById('currentTemp').textContent = data.temperature;
        document.getElementById('currentCondition').textContent = data.condition;
        document.getElementById('humidity').textContent = data.humidity + '%';
        document.getElementById('windSpeed').textContent = data.windSpeed + ' km/h';
        document.getElementById('pressure').textContent = data.pressure + ' mb';
        document.getElementById('feelsLike').textContent = data.feelsLike + '°C';
        document.getElementById('visibility').textContent = data.visibility + ' km';
        document.getElementById('uvIndex').textContent = data.uvIndex;
        document.getElementById('lastUpdated').textContent = 'Last updated: ' + new Date().toLocaleTimeString();
        
        this.displayForecast(data.forecast);
    },
    
    displayForecast(forecast) {
        const dailyContainer = document.getElementById('dailyForecast');
        dailyContainer.innerHTML = '';
        
        forecast.forEach(day => {
            const card = document.createElement('div');
            card.className = 'daily-item';
            card.innerHTML = `
                <div class="day">${day.date}</div>
                <div class="icon"><i class="fas fa-cloud"></i></div>
                <div class="temp-range">
                    <span class="temp-high">${day.maxTemp}°</span>
                    <span class="temp-low">${day.minTemp}°</span>
                </div>
                <div>${day.condition}</div>
            `;
            dailyContainer.appendChild(card);
        });
    },
    
    useGPS() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    const { latitude, longitude } = position.coords;
                    this.fetchWeatherByCoords(latitude, longitude);
                },
                (error) => alert('Unable to get your location: ' + error.message)
            );
        }
    },
    
    async fetchWeatherByCoords(lat, lon) {
        // Fetch weather by coordinates
        const data = await this.fetchWeatherData('Current Location');
        this.displayCurrentWeather(data);
    },
    
    saveToHistory(data) {
        this.historicalData.push({
            ...data,
            timestamp: new Date()
        });
        localStorage.setItem('weatherHistory', JSON.stringify(this.historicalData));
    },
    
    initializeMap() {
        const map = L.map('map-container').setView([20, 0], 2);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors',
            maxZoom: 19
        }).addTo(map);
        this.map = map;
    },
    
    updateMap() {
        if (this.map) {
            this.map.invalidateSize();
        }
    },
    
    initializeCharts() {
        if (Object.keys(this.charts).length > 0) return;
        
        // Temperature Chart
        const tempCtx = document.getElementById('temperatureChart').getContext('2d');
        this.charts.temperature = new Chart(tempCtx, {
            type: 'line',
            data: {
                labels: ['Day 1', 'Day 2', 'Day 3', 'Day 4', 'Day 5'],
                datasets: [{
                    label: 'Temperature (°C)',
                    data: [28, 29, 27, 26, 28],
                    borderColor: '#00d4ff',
                    backgroundColor: 'rgba(0, 212, 255, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: { responsive: true, plugins: { legend: { display: true } } }
        });
        
        // Humidity Chart
        const humidityCtx = document.getElementById('humidityChart').getContext('2d');
        this.charts.humidity = new Chart(humidityCtx, {
            type: 'bar',
            data: {
                labels: ['Day 1', 'Day 2', 'Day 3', 'Day 4', 'Day 5'],
                datasets: [{
                    label: 'Humidity (%)',
                    data: [65, 70, 68, 72, 66],
                    backgroundColor: 'rgba(0, 212, 255, 0.5)',
                    borderColor: '#00d4ff',
                    borderWidth: 2
                }]
            },
            options: { responsive: true }
        });
        
        // Wind Chart
        const windCtx = document.getElementById('windChart').getContext('2d');
        this.charts.wind = new Chart(windCtx, {
            type: 'radar',
            data: {
                labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
                datasets: [{
                    label: 'Wind Speed (km/h)',
                    data: [12, 15, 10, 18, 14],
                    borderColor: '#00d4ff',
                    backgroundColor: 'rgba(0, 212, 255, 0.2)'
                }]
            },
            options: { responsive: true }
        });
        
        // Precipitation Chart
        const precipCtx = document.getElementById('precipitationChart').getContext('2d');
        this.charts.precipitation = new Chart(precipCtx, {
            type: 'bar',
            data: {
                labels: ['Day 1', 'Day 2', 'Day 3', 'Day 4', 'Day 5'],
                datasets: [{
                    label: 'Precipitation (mm)',
                    data: [0, 5, 10, 2, 0],
                    backgroundColor: '#0099cc'
                }]
            },
            options: { responsive: true }
        });
        
        // Condition Chart
        const conditionCtx = document.getElementById('conditionChart').getContext('2d');
        this.charts.condition = new Chart(conditionCtx, {
            type: 'doughnut',
            data: {
                labels: ['Sunny', 'Cloudy', 'Rainy', 'Partly Cloudy'],
                datasets: [{
                    data: [30, 25, 20, 25],
                    backgroundColor: ['#ffd93d', '#b0b0b0', '#0099cc', '#00d4ff']
                }]
            },
            options: { responsive: true }
        });
        
        // Pressure Chart
        const pressureCtx = document.getElementById('pressureChart').getContext('2d');
        this.charts.pressure = new Chart(pressureCtx, {
            type: 'line',
            data: {
                labels: ['Day 1', 'Day 2', 'Day 3', 'Day 4', 'Day 5'],
                datasets: [{
                    label: 'Pressure (mb)',
                    data: [1013, 1012, 1014, 1015, 1013],
                    borderColor: '#51cf66',
                    backgroundColor: 'rgba(81, 207, 102, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: { responsive: true }
        });
    },
    
    showDownloadModal() {
        document.getElementById('downloadModal').classList.add('active');
        
        document.querySelectorAll('.download-option').forEach(btn => {
            btn.addEventListener('click', (e) => this.downloadReport(e.target.closest('.download-option').dataset.format));
        });
    },
    
    downloadReport(format) {
        const data = {
            city: this.currentCity,
            temperature: document.getElementById('currentTemp').textContent,
            condition: document.getElementById('currentCondition').textContent,
            timestamp: new Date().toISOString()
        };
        
        if (format === 'pdf') {
            this.downloadPDF(data);
        } else if (format === 'csv') {
            this.downloadCSV(data);
        } else if (format === 'json') {
            this.downloadJSON(data);
        } else if (format === 'image') {
            this.downloadImage();
        }
        
        document.getElementById('downloadModal').classList.remove('active');
    },
    
    downloadJSON(data) {
        const json = JSON.stringify(data, null, 2);
        const blob = new Blob([json], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `weather-${data.city}-${Date.now()}.json`;
        a.click();
    },
    
    downloadCSV(data) {
        const csv = `City,Temperature,Condition,Timestamp\n${data.city},${data.temperature},${data.condition},${data.timestamp}`;
        const blob = new Blob([csv], { type: 'text/csv' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `weather-${data.city}-${Date.now()}.csv`;
        a.click();
    },
    
    downloadPDF(data) {
        alert('PDF download requires additional library. Using JSON instead.');
        this.downloadJSON(data);
    },
    
    downloadImage() {
        alert('Image download feature coming soon!');
    },
    
    shareWeather() {
        const text = `Check the weather in ${this.currentCity}: ${document.getElementById('currentTemp').textContent}°C and ${document.getElementById('currentCondition').textContent}`;
        
        if (navigator.share) {
            navigator.share({
                title: 'Weather Report',
                text: text
            });
        } else {
            alert('Weather: ' + text);
        }
    },
    
    showAlerts() {
        alert('Weather Alerts:\n- High temperature warning\n- Possible rainfall tomorrow');
    },
    
    compareWeather() {
        alert('Compare feature: Select two cities to compare their weather');
    },
    
    handleToggle(e) {
        const buttons = e.target.parentElement.querySelectorAll('.toggle-btn');
        buttons.forEach(btn => btn.classList.remove('active'));
        e.target.classList.add('active');
    },
    
    loadSettings() {
        const saved = localStorage.getItem('weatherSettings');
        if (saved) {
            this.config = { ...this.config, ...JSON.parse(saved) };
        }
    },
    
    saveSettings() {
        localStorage.setItem('weatherSettings', JSON.stringify(this.config));
    },
    
    clearCache() {
        localStorage.removeItem('weatherHistory');
        localStorage.removeItem('weatherCache');
        alert('Cache cleared successfully!');
    },
    
    exportSettings() {
        const settings = JSON.stringify(this.config, null, 2);
        const blob = new Blob([settings], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `weather-settings-${Date.now()}.json`;
        a.click();
    },
    
    importSettings() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.json';
        input.onchange = (e) => {
            const file = e.target.files[0];
            const reader = new FileReader();
            reader.onload = (event) => {
                try {
                    const settings = JSON.parse(event.target.result);
                    this.config = { ...this.config, ...settings };
                    this.saveSettings();
                    alert('Settings imported successfully!');
                } catch (error) {
                    alert('Error importing settings: ' + error.message);
                }
            };
            reader.readAsText(file);
        };
        input.click();
    },
    
    toggleTheme() {
        document.body.classList.toggle('light-theme');
        this.config.theme = document.body.classList.contains('light-theme') ? 'light' : 'dark';
        this.saveSettings();
    },
    
    displayWelcome() {
        this.displayCurrentWeather({
            city: 'Welcome to WeatherPro',
            temperature: '--',
            condition: 'Search for a city to get started',
            humidity: '--',
            windSpeed: '--',
            pressure: '--',
            feelsLike: '--',
            visibility: '--',
            uvIndex: '--',
            forecast: []
        });
    },
    
    startAutoRefresh() {
        setInterval(() => {
            if (this.currentCity) {
                this.searchCity();
            }
        }, this.config.refreshInterval * 60000);
    }
};

// Initialize on load
document.addEventListener('DOMContentLoaded', () => {
    WeatherApp.init();
});
