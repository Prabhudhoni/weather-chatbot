// ===========================
// ADVANCED CHATBOT MODULE
// ===========================

const AdvancedChatbot = {
    config: {
        apiKey: 'AIzaSyB1ChlVjhz2Z717cYX-W8IUXslDFURsCs0',
        apiEndpoint: 'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent'
    },
    
    init() {
        this.setupEventListeners();
        this.displayWelcomeMessage();
    },
    
    setupEventListeners() {
        const chatbotIcon = document.getElementById('chatbotIcon');
        const closeChatbot = document.getElementById('closeChatbot');
        const sendBtn = document.getElementById('sendBtn');
        const chatInput = document.getElementById('chatInput');
        
        chatbotIcon.addEventListener('click', () => this.toggleChatbot());
        closeChatbot.addEventListener('click', () => this.closeChatbot());
        sendBtn.addEventListener('click', () => this.sendMessage());
        chatInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });
    },
    
    toggleChatbot() {
        const chatbotWindow = document.getElementById('chatbotWindow');
        chatbotWindow.classList.toggle('active');
        if (chatbotWindow.classList.contains('active')) {
            document.getElementById('chatInput').focus();
        }
    },
    
    closeChatbot() {
        document.getElementById('chatbotWindow').classList.remove('active');
    },
    
    displayWelcomeMessage() {
        const messagesContainer = document.getElementById('chatMessages');
        const welcomeMsg = document.createElement('div');
        welcomeMsg.className = 'chat-message message-bot';
        welcomeMsg.innerHTML = `
            <div class="message-content">
                <strong>👋 WeatherPro Assistant</strong><br>
                Ask me about:<br>
                • Weather in any city<br>
                • Historical data<br>
                • Weather comparisons<br>
                • Download reports
            </div>
        `;
        messagesContainer.appendChild(welcomeMsg);
        this.scrollToBottom();
    },
    
    async sendMessage() {
        const chatInput = document.getElementById('chatInput');
        const message = chatInput.value.trim();
        
        if (!message) return;
        
        this.displayMessage(message, 'user');
        chatInput.value = '';
        
        this.showTypingIndicator();
        
        try {
            const response = await this.getAIResponse(message);
            this.removeTypingIndicator();
            this.displayMessage(response, 'bot');
        } catch (error) {
            this.removeTypingIndicator();
            this.displayMessage('Sorry, I encountered an error. Please try again.', 'bot');
            console.error('Chatbot error:', error);
        }
    },
    
    displayMessage(text, sender) {
        const messagesContainer = document.getElementById('chatMessages');
        const messageDiv = document.createElement('div');
        messageDiv.className = `chat-message message-${sender}`;
        
        const messageContent = document.createElement('div');
        messageContent.className = 'message-content';
        messageContent.textContent = text;
        
        messageDiv.appendChild(messageContent);
        messagesContainer.appendChild(messageDiv);
        this.scrollToBottom();
    },
    
    showTypingIndicator() {
        const messagesContainer = document.getElementById('chatMessages');
        const typingDiv = document.createElement('div');
        typingDiv.className = 'chat-message message-bot typing-indicator';
        typingDiv.innerHTML = '<div class="message-content"><span></span><span></span><span></span></div>';
        typingDiv.id = 'typingIndicator';
        messagesContainer.appendChild(typingDiv);
        this.scrollToBottom();
    },
    
    removeTypingIndicator() {
        const typingIndicator = document.getElementById('typingIndicator');
        if (typingIndicator) typingIndicator.remove();
    },
    
    async getAIResponse(userMessage) {
        try {
            const weatherInfo = this.extractWeatherQuery(userMessage);
            
            let prompt = `You are a helpful weather assistant. Answer the following question:\n\n"${userMessage}"\n\n`;
            
            if (weatherInfo.city) {
                prompt += `The user is asking about: ${weatherInfo.city}\n`;
            }
            
            prompt += `Provide a helpful, concise response about weather or weather-related topics.`;
            
            const response = await fetch(
                `${this.config.apiEndpoint}?key=${this.config.apiKey}`,
                {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        contents: [{
                            parts: [{ text: prompt }]
                        }]
                    })
                }
            );
            
            if (!response.ok) {
                throw new Error(`API error: ${response.status}`);
            }
            
            const data = await response.json();
            
            if (data.candidates && data.candidates[0] && data.candidates[0].content && data.candidates[0].content.parts && data.candidates[0].content.parts[0]) {
                return data.candidates[0].content.parts[0].text;
            }
            
            throw new Error('Invalid API response format');
        } catch (error) {
            console.error('Error getting AI response:', error);
            return this.getFallbackResponse(userMessage);
        }
    },
    
    extractWeatherQuery(message) {
        const cityRegex = /(?:in|at|for|weather in|weather at)\s+([A-Za-z\s]+?)(?:\?|$|\.)/i;
        const match = message.match(cityRegex);
        
        return {
            city: match ? match[1].trim() : null,
            isWeatherQuery: /weather|temperature|rain|snow|wind|humidity|forecast|climate|storm|sunny|cloudy|condition|download|report|history|compare|analytics/i.test(message)
        };
    },
    
    getFallbackResponse(userMessage) {
        const responses = {
            greeting: [
                '👋 Hello! I\'m WeatherPro Assistant. How can I help?',
                'Hi! 🌤️ What weather information do you need?'
            ],
            weather: [
                '🌤️ I can help with weather information! Which city?',
                '☁️ Tell me which city you\'d like weather for.'
            ],
            download: [
                '📥 You can download weather reports in PDF, CSV, JSON, or Image format.',
                '💾 Use the Download button to get weather reports.'
            ],
            analytics: [
                '📊 Check the Analytics section for detailed weather charts and trends.',
                '📈 View temperature, humidity, and wind speed analytics.'
            ],
            default: [
                '🤔 I\'m a weather assistant. Ask me about weather!',
                '💭 Try asking about weather in a specific city.'
            ]
        };
        
        const messageLower = userMessage.toLowerCase();
        
        if (/hello|hi|hey|greet/i.test(messageLower)) {
            return this.getRandomResponse(responses.greeting);
        } else if (/download|report|export/i.test(messageLower)) {
            return this.getRandomResponse(responses.download);
        } else if (/analytics|chart|graph|trend/i.test(messageLower)) {
            return this.getRandomResponse(responses.analytics);
        } else if (/weather|temperature|rain|wind|humidity/i.test(messageLower)) {
            return this.getRandomResponse(responses.weather);
        } else {
            return this.getRandomResponse(responses.default);
        }
    },
    
    getRandomResponse(responses) {
        return responses[Math.floor(Math.random() * responses.length)];
    },
    
    scrollToBottom() {
        const messagesContainer = document.getElementById('chatMessages');
        setTimeout(() => {
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }, 0);
    }
};

// Initialize chatbot
document.addEventListener('DOMContentLoaded', () => {
    AdvancedChatbot.init();
});
