// ===========================
// RADAR MAP MODULE
// ===========================

function updateRadar(city) {
    try {
        const radarMap = document.getElementById('radarMap');
        const layerSelect = document.getElementById('radarLayerSelect');
        
        if (!radarMap || !layerSelect) return;
        
        const layer = layerSelect.value;
        
        // Display placeholder message instead of actual map
        radarMap.innerHTML = `
            <div style="width:100%; height:100%; display:flex; align-items:center; justify-content:center; background:#1a1f2e; border-radius:1rem;">
                <div style="text-align:center; color:#b0b0b0;">
                    <p>Weather Radar Map</p>
                    <p style="font-size:0.9rem; margin-top:0.5rem;">Layer: ${layer}</p>
                    <p style="font-size:0.85rem; margin-top:1rem; color:#666;">Add your OpenWeatherMap API key to enable live radar</p>
                </div>
            </div>
        `;
    } catch (error) {
        console.error('Radar update error:', error);
    }
}

function getRadarMapUrl(layer) {
    const baseUrl = 'https://tile.openweathermap.org/map';
    const apiKey = 'YOUR_OPENWEATHERMAP_API_KEY';
    
    const layers = {
        'clouds': `${baseUrl}/clouds_new/1/0/0.png?appid=${apiKey}`,
        'precipitation': `${baseUrl}/precipitation_new/1/0/0.png?appid=${apiKey}`,
        'temp': `${baseUrl}/temp_new/1/0/0.png?appid=${apiKey}`,
        'pressure': `${baseUrl}/pressure_new/1/0/0.png?appid=${apiKey}`
    };
    
    return layers[layer] || layers['clouds'];
}

document.addEventListener('DOMContentLoaded', () => {
    try {
        const radarLayerSelect = document.getElementById('radarLayerSelect');
        if (radarLayerSelect) {
            radarLayerSelect.addEventListener('change', () => {
                if (currentCity) {
                    updateRadar(currentCity);
                }
            });
        }
    } catch (error) {
        console.error('Radar initialization error:', error);
    }
});
