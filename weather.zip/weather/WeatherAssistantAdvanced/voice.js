// ===========================
// VOICE MODULE
// ===========================

function initializeVoice() {
    // Check browser support
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const speechSynthesis = window.speechSynthesis;
    
    if (!SpeechRecognition) {
        console.warn('Speech Recognition not supported');
    }
    
    if (!speechSynthesis) {
        console.warn('Speech Synthesis not supported');
    }
}

function speakText(text, lang = 'en') {
    if (!('speechSynthesis' in window)) {
        console.log('Speech Synthesis not supported');
        return;
    }
    
    // Cancel any ongoing speech
    window.speechSynthesis.cancel();
    
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = getLangCode(lang);
    utterance.rate = 1;
    utterance.pitch = 1;
    utterance.volume = 1;
    
    window.speechSynthesis.speak(utterance);
}

function getLangCode(lang) {
    const langCodes = {
        'en': 'en-US',
        'ta': 'ta-IN',
        'hi': 'hi-IN',
        'te': 'te-IN',
        'ka': 'ka-IN'
    };
    
    return langCodes[lang] || 'en-US';
}

// Initialize on load
document.addEventListener('DOMContentLoaded', initializeVoice);
