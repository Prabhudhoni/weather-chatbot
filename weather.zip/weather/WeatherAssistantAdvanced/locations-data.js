// Complete India & Tamil Nadu Locations Database
const locationsDatabase = {
  // Tamil Nadu Districts
  'tamilnadu': {
    'ariyalur': { temp: 32, condition: 'Sunny', humidity: 65, wind: 12 },
    'chengalpattu': { temp: 31, condition: 'Partly Cloudy', humidity: 70, wind: 14 },
    'coimbatore': { temp: 28, condition: 'Cloudy', humidity: 75, wind: 16 },
    'cuddalore': { temp: 33, condition: 'Sunny', humidity: 68, wind: 13 },
    'dharmapuri': { temp: 30, condition: 'Partly Cloudy', humidity: 72, wind: 15 },
    'dindigul': { temp: 29, condition: 'Cloudy', humidity: 74, wind: 14 },
    'erode': { temp: 27, condition: 'Rainy', humidity: 80, wind: 18 },
    'kanchipuram': { temp: 32, condition: 'Sunny', humidity: 66, wind: 12 },
    'kanyakumari': { temp: 26, condition: 'Cloudy', humidity: 78, wind: 20 },
    'karur': { temp: 31, condition: 'Partly Cloudy', humidity: 71, wind: 15 },
    'krishnagiri': { temp: 30, condition: 'Sunny', humidity: 69, wind: 13 },
    'madurai': { temp: 34, condition: 'Sunny', humidity: 64, wind: 11 },
    'mayiladuthurai': { temp: 32, condition: 'Partly Cloudy', humidity: 72, wind: 14 },
    'nagapattinam': { temp: 31, condition: 'Cloudy', humidity: 76, wind: 17 },
    'namakkal': { temp: 30, condition: 'Sunny', humidity: 68, wind: 12 },
    'nilgiris': { temp: 18, condition: 'Cloudy', humidity: 85, wind: 22 },
    'perambalur': { temp: 31, condition: 'Partly Cloudy', humidity: 70, wind: 14 },
    'pudukkottai': { temp: 32, condition: 'Sunny', humidity: 67, wind: 13 },
    'ramanathapuram': { temp: 33, condition: 'Sunny', humidity: 65, wind: 12 },
    'ranipet': { temp: 31, condition: 'Partly Cloudy', humidity: 71, wind: 15 },
    'salem': { temp: 29, condition: 'Cloudy', humidity: 73, wind: 16 },
    'sivaganga': { temp: 33, condition: 'Sunny', humidity: 66, wind: 12 },
    'tenkasi': { temp: 28, condition: 'Cloudy', humidity: 77, wind: 19 },
    'thanjavur': { temp: 32, condition: 'Partly Cloudy', humidity: 74, wind: 15 },
    'theni': { temp: 27, condition: 'Cloudy', humidity: 76, wind: 18 },
    'thiruvallur': { temp: 32, condition: 'Sunny', humidity: 68, wind: 13 },
    'thiruvannamalai': { temp: 30, condition: 'Partly Cloudy', humidity: 70, wind: 14 },
    'thiruvarur': { temp: 31, condition: 'Cloudy', humidity: 75, wind: 16 },
    'tirupathur': { temp: 30, condition: 'Sunny', humidity: 69, wind: 13 },
    'tiruppur': { temp: 28, condition: 'Cloudy', humidity: 74, wind: 17 },
    'tiruvannamalai': { temp: 30, condition: 'Partly Cloudy', humidity: 70, wind: 14 },
    'trichy': { temp: 31, condition: 'Sunny', humidity: 68, wind: 12 },
    'vellore': { temp: 31, condition: 'Partly Cloudy', humidity: 71, wind: 15 },
    'villupuram': { temp: 32, condition: 'Sunny', humidity: 67, wind: 13 },
    'virudhunagar': { temp: 33, condition: 'Sunny', humidity: 65, wind: 12 },
    'kallakurichi': { temp: 31, condition: 'Partly Cloudy', humidity: 70, wind: 14 },
    'chengalpattu': { temp: 31, condition: 'Cloudy', humidity: 75, wind: 16 }
  },

  // Major Indian Cities
  'india': {
    'delhi': { temp: 25, condition: 'Partly Cloudy', humidity: 60, wind: 10 },
    'mumbai': { temp: 28, condition: 'Cloudy', humidity: 75, wind: 15 },
    'bangalore': { temp: 24, condition: 'Cloudy', humidity: 70, wind: 12 },
    'hyderabad': { temp: 26, condition: 'Sunny', humidity: 65, wind: 11 },
    'kolkata': { temp: 27, condition: 'Rainy', humidity: 80, wind: 18 },
    'pune': { temp: 23, condition: 'Partly Cloudy', humidity: 62, wind: 9 },
    'ahmedabad': { temp: 29, condition: 'Sunny', humidity: 58, wind: 8 },
    'jaipur': { temp: 26, condition: 'Sunny', humidity: 55, wind: 7 },
    'lucknow': { temp: 24, condition: 'Cloudy', humidity: 68, wind: 13 },
    'chandigarh': { temp: 22, condition: 'Partly Cloudy', humidity: 65, wind: 11 },
    'kochi': { temp: 27, condition: 'Rainy', humidity: 85, wind: 20 },
    'guwahati': { temp: 25, condition: 'Cloudy', humidity: 78, wind: 16 },
    'srinagar': { temp: 15, condition: 'Cloudy', humidity: 70, wind: 12 },
    'shimla': { temp: 12, condition: 'Cloudy', humidity: 75, wind: 14 },
    'darjeeling': { temp: 14, condition: 'Cloudy', humidity: 80, wind: 15 },
    'manali': { temp: 10, condition: 'Cloudy', humidity: 72, wind: 13 },
    'ooty': { temp: 16, condition: 'Cloudy', humidity: 78, wind: 14 },
    'goa': { temp: 28, condition: 'Rainy', humidity: 82, wind: 19 },
    'udaipur': { temp: 25, condition: 'Sunny', humidity: 60, wind: 10 },
    'agra': { temp: 26, condition: 'Sunny', humidity: 58, wind: 9 }
  }
};

// Function to get weather for any location
function getWeatherData(location) {
  const loc = location.toLowerCase().trim();
  
  // Search in Tamil Nadu
  if (locationsDatabase.tamilnadu[loc]) {
    return {
      city: location,
      state: 'Tamil Nadu',
      country: 'India',
      ...locationsDatabase.tamilnadu[loc],
      forecast: generateForecast()
    };
  }
  
  // Search in India
  if (locationsDatabase.india[loc]) {
    return {
      city: location,
      state: 'India',
      country: 'India',
      ...locationsDatabase.india[loc],
      forecast: generateForecast()
    };
  }
  
  // Default to Chennai if not found
  return {
    city: 'Chennai',
    state: 'Tamil Nadu',
    country: 'India',
    temp: 32,
    condition: 'Partly Cloudy',
    humidity: 75,
    wind: 15,
    forecast: generateForecast()
  };
}

// Generate 5-day forecast
function generateForecast() {
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
  const conditions = ['Sunny', 'Cloudy', 'Rainy', 'Partly Cloudy'];
  
  return days.map(day => ({
    day: day,
    maxTemp: Math.floor(Math.random() * 10) + 28,
    minTemp: Math.floor(Math.random() * 8) + 20,
    condition: conditions[Math.floor(Math.random() * conditions.length)]
  }));
}

// Get all Tamil Nadu districts
function getTamilNaduDistricts() {
  return Object.keys(locationsDatabase.tamilnadu).map(district => 
    district.charAt(0).toUpperCase() + district.slice(1)
  );
}

// Get all Indian cities
function getIndianCities() {
  return Object.keys(locationsDatabase.india).map(city => 
    city.charAt(0).toUpperCase() + city.slice(1)
  );
}

// Search locations
function searchLocations(query) {
  const q = query.toLowerCase().trim();
  const results = [];
  
  // Search in Tamil Nadu
  for (let district in locationsDatabase.tamilnadu) {
    if (district.includes(q)) {
      results.push({
        name: district.charAt(0).toUpperCase() + district.slice(1),
        state: 'Tamil Nadu',
        type: 'District'
      });
    }
  }
  
  // Search in India
  for (let city in locationsDatabase.india) {
    if (city.includes(q)) {
      results.push({
        name: city.charAt(0).toUpperCase() + city.slice(1),
        state: 'India',
        type: 'City'
      });
    }
  }
  
  return results;
}
