// ============================================
// WEEK 3: EXPANSION FEATURES
// User Accounts, Social Sharing, Analytics, Deployment
// ============================================

// ============================================
// 1. USER ACCOUNTS & AUTHENTICATION
// ============================================
class UserAuthentication {
    constructor() {
        this.currentUser = this.loadUser();
        this.users = this.loadUsers();
    }

    loadUser() {
        const user = localStorage.getItem('currentUser');
        return user ? JSON.parse(user) : null;
    }

    loadUsers() {
        const users = localStorage.getItem('allUsers');
        return users ? JSON.parse(users) : {};
    }

    saveUsers() {
        localStorage.setItem('allUsers', JSON.stringify(this.users));
    }

    saveCurrentUser() {
        localStorage.setItem('currentUser', JSON.stringify(this.currentUser));
    }

    register(email, password, name) {
        if(this.users[email]) {
            return { success: false, message: 'Email already registered' };
        }

        const hashedPassword = this.hashPassword(password);
        this.users[email] = {
            email,
            password: hashedPassword,
            name,
            createdAt: new Date().toISOString(),
            profile: {
                avatar: this.getDefaultAvatar(name),
                bio: '',
                location: ''
            },
            preferences: {
                favorites: [],
                units: 'metric',
                theme: 'light',
                notifications: true
            }
        };

        this.saveUsers();
        return { success: true, message: 'Registration successful' };
    }

    login(email, password) {
        if(!this.users[email]) {
            return { success: false, message: 'Email not found' };
        }

        const hashedPassword = this.hashPassword(password);
        if(this.users[email].password !== hashedPassword) {
            return { success: false, message: 'Incorrect password' };
        }

        this.currentUser = {
            email,
            name: this.users[email].name,
            profile: this.users[email].profile,
            preferences: this.users[email].preferences,
            loginTime: new Date().toISOString()
        };

        this.saveCurrentUser();
        return { success: true, message: 'Login successful', user: this.currentUser };
    }

    logout() {
        this.currentUser = null;
        localStorage.removeItem('currentUser');
        return { success: true, message: 'Logged out successfully' };
    }

    isLoggedIn() {
        return this.currentUser !== null;
    }

    getCurrentUser() {
        return this.currentUser;
    }

    updateProfile(name, bio, location) {
        if(!this.currentUser) return { success: false, message: 'Not logged in' };

        this.users[this.currentUser.email].profile.bio = bio;
        this.users[this.currentUser.email].profile.location = location;
        this.currentUser.profile.bio = bio;
        this.currentUser.profile.location = location;

        this.saveUsers();
        this.saveCurrentUser();
        return { success: true, message: 'Profile updated' };
    }

    hashPassword(password) {
        // Simple hash (use bcrypt in production)
        let hash = 0;
        for(let i = 0; i < password.length; i++) {
            const char = password.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash;
        }
        return hash.toString();
    }

    getDefaultAvatar(name) {
        const initials = name.split(' ').map(n => n[0]).join('').toUpperCase();
        return `https://ui-avatars.com/api/?name=${initials}&background=0066cc&color=fff`;
    }
}

// ============================================
// 2. SOCIAL SHARING
// ============================================
class SocialSharing {
    constructor() {
        this.appUrl = window.location.origin + window.location.pathname;
        this.appName = 'Weather AI Assistant';
    }

    shareToTwitter(text, url = this.appUrl) {
        const twitterUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`;
        window.open(twitterUrl, '_blank', 'width=600,height=400');
    }

    shareToFacebook(url = this.appUrl) {
        const facebookUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`;
        window.open(facebookUrl, '_blank', 'width=600,height=400');
    }

    shareToWhatsApp(text) {
        const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(text + ' ' + this.appUrl)}`;
        window.open(whatsappUrl, '_blank');
    }

    shareToLinkedIn(url = this.appUrl, title = this.appName) {
        const linkedinUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`;
        window.open(linkedinUrl, '_blank', 'width=600,height=400');
    }

    shareToEmail(recipient, subject, body) {
        const mailtoUrl = `mailto:${recipient}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body + '\n\n' + this.appUrl)}`;
        window.location.href = mailtoUrl;
    }

    shareWeatherReport(city, weather) {
        const text = `🌤️ Weather in ${city}: ${weather.temp}°C, ${weather.condition}. Check it out!`;
        return {
            twitter: () => this.shareToTwitter(text),
            facebook: () => this.shareToFacebook(),
            whatsapp: () => this.shareToWhatsApp(text),
            linkedin: () => this.shareToLinkedIn(),
            email: (recipient) => this.shareToEmail(recipient, `Weather Report: ${city}`, text)
        };
    }

    generateShareableLink(data) {
        const encoded = btoa(JSON.stringify(data));
        return `${this.appUrl}?share=${encoded}`;
    }

    createShareButton(platform, text, container) {
        const button = document.createElement('button');
        const icons = {
            twitter: 'fab fa-twitter',
            facebook: 'fab fa-facebook',
            whatsapp: 'fab fa-whatsapp',
            linkedin: 'fab fa-linkedin',
            email: 'fas fa-envelope'
        };

        button.innerHTML = `<i class="${icons[platform]}"></i> Share on ${platform.charAt(0).toUpperCase() + platform.slice(1)}`;
        button.style.cssText = `
            padding: 0.75rem 1rem;
            margin: 0.5rem;
            border: none;
            border-radius: 0.5rem;
            background: #0066cc;
            color: white;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s;
        `;

        button.onmouseover = () => button.style.transform = 'scale(1.05)';
        button.onmouseout = () => button.style.transform = 'scale(1)';

        button.onclick = () => {
            if(platform === 'twitter') this.shareToTwitter(text);
            else if(platform === 'facebook') this.shareToFacebook();
            else if(platform === 'whatsapp') this.shareToWhatsApp(text);
            else if(platform === 'linkedin') this.shareToLinkedIn();
        };

        if(container) {
            container.appendChild(button);
        }

        return button;
    }
}

// ============================================
// 3. ANALYTICS & TRACKING
// ============================================
class AnalyticsManager {
    constructor() {
        this.events = [];
        this.sessionStart = new Date();
        this.loadEvents();
    }

    loadEvents() {
        const saved = localStorage.getItem('analyticsEvents');
        this.events = saved ? JSON.parse(saved) : [];
    }

    saveEvents() {
        localStorage.setItem('analyticsEvents', JSON.stringify(this.events));
    }

    trackEvent(eventName, eventData = {}) {
        const event = {
            name: eventName,
            timestamp: new Date().toISOString(),
            data: eventData,
            userAgent: navigator.userAgent,
            url: window.location.href
        };

        this.events.push(event);
        this.saveEvents();

        // Send to server (if available)
        this.sendToServer(event);

        console.log('Event tracked:', event);
    }

    trackPageView(pageName) {
        this.trackEvent('page_view', { page: pageName });
    }

    trackSearch(query) {
        this.trackEvent('search', { query });
    }

    trackWeatherCheck(city) {
        this.trackEvent('weather_check', { city });
    }

    trackChatMessage(message) {
        this.trackEvent('chat_message', { message: message.substring(0, 50) });
    }

    trackDownload(format) {
        this.trackEvent('download', { format });
    }

    trackFeatureUsage(feature) {
        this.trackEvent('feature_usage', { feature });
    }

    getSessionDuration() {
        return Math.round((new Date() - this.sessionStart) / 1000);
    }

    getEventStats() {
        const stats = {};
        this.events.forEach(event => {
            stats[event.name] = (stats[event.name] || 0) + 1;
        });
        return stats;
    }

    getTopSearches(limit = 10) {
        const searches = this.events
            .filter(e => e.name === 'search')
            .map(e => e.data.query)
            .reduce((acc, query) => {
                acc[query] = (acc[query] || 0) + 1;
                return acc;
            }, {});

        return Object.entries(searches)
            .sort((a, b) => b[1] - a[1])
            .slice(0, limit)
            .map(([query, count]) => ({ query, count }));
    }

    sendToServer(event) {
        // Send analytics to server
        // fetch('/api/analytics', {
        //     method: 'POST',
        //     headers: { 'Content-Type': 'application/json' },
        //     body: JSON.stringify(event)
        // }).catch(err => console.log('Analytics send failed:', err));
    }

    exportAnalytics() {
        const data = {
            sessionDuration: this.getSessionDuration(),
            totalEvents: this.events.length,
            eventStats: this.getEventStats(),
            topSearches: this.getTopSearches(),
            events: this.events
        };
        return JSON.stringify(data, null, 2);
    }

    clearAnalytics() {
        this.events = [];
        localStorage.removeItem('analyticsEvents');
    }
}

// ============================================
// 4. DEPLOYMENT UTILITIES
// ============================================
class DeploymentManager {
    constructor() {
        this.version = '2.0.0';
        this.buildDate = new Date().toISOString();
    }

    getAppInfo() {
        return {
            name: 'Weather AI Assistant',
            version: this.version,
            buildDate: this.buildDate,
            environment: this.getEnvironment(),
            features: this.getFeatures()
        };
    }

    getEnvironment() {
        if(window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
            return 'development';
        }
        return 'production';
    }

    getFeatures() {
        return {
            darkMode: true,
            geolocation: true,
            realAPI: true,
            pwa: true,
            pushNotifications: true,
            sevenDayForecast: true,
            multiLanguage: true,
            advancedCharts: true,
            userAccounts: true,
            socialSharing: true,
            analytics: true
        };
    }

    checkBrowserCompatibility() {
        const compatibility = {
            serviceWorker: 'serviceWorker' in navigator,
            geolocation: 'geolocation' in navigator,
            notification: 'Notification' in window,
            localStorage: typeof(Storage) !== 'undefined',
            fetch: 'fetch' in window,
            speechRecognition: 'SpeechRecognition' in window || 'webkitSpeechRecognition' in window,
            speechSynthesis: 'speechSynthesis' in window
        };

        return compatibility;
    }

    getPerformanceMetrics() {
        if(!window.performance) return null;

        const perfData = window.performance.timing;
        return {
            pageLoadTime: perfData.loadEventEnd - perfData.navigationStart,
            domContentLoaded: perfData.domContentLoadedEventEnd - perfData.navigationStart,
            resourcesLoaded: perfData.loadEventEnd - perfData.responseEnd,
            timeToFirstByte: perfData.responseStart - perfData.navigationStart
        };
    }

    generateReport() {
        return {
            appInfo: this.getAppInfo(),
            compatibility: this.checkBrowserCompatibility(),
            performance: this.getPerformanceMetrics(),
            timestamp: new Date().toISOString()
        };
    }

    exportReport() {
        const report = this.generateReport();
        const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `app-report-${new Date().toISOString().split('T')[0]}.json`;
        a.click();
        URL.revokeObjectURL(url);
    }

    checkHealth() {
        const health = {
            status: 'healthy',
            checks: {}
        };

        // Check localStorage
        try {
            localStorage.setItem('healthCheck', 'ok');
            localStorage.removeItem('healthCheck');
            health.checks.localStorage = 'ok';
        } catch(e) {
            health.checks.localStorage = 'error';
            health.status = 'degraded';
        }

        // Check API connectivity
        fetch('/api/health', { method: 'HEAD' })
            .then(() => health.checks.api = 'ok')
            .catch(() => {
                health.checks.api = 'error';
                health.status = 'degraded';
            });

        return health;
    }
}

// ============================================
// INITIALIZATION
// ============================================
const userAuth = new UserAuthentication();
const socialSharing = new SocialSharing();
const analytics = new AnalyticsManager();
const deployment = new DeploymentManager();

// Track page view on load
document.addEventListener('DOMContentLoaded', () => {
    analytics.trackPageView(document.title);
});

// Export for use in HTML
window.userAuth = userAuth;
window.socialSharing = socialSharing;
window.analytics = analytics;
window.deployment = deployment;
