// ===========================
// LANGUAGE MODULE
// ===========================

function getTranslations(lang) {
    const translations = {
        en: {
            heroTitle: 'Weather Info Assistant',
            heroSubtitle: 'Get real-time weather, forecasts, and alerts',
            searchPlaceholder: 'Search city...',
            chatbotTitle: 'Weather Assistant',
            chatPlaceholder: 'Ask about weather...',
            forecastTitle: '5-Day Forecast',
            chartsTitle: 'Weather Analytics',
            radarTitle: 'Weather Radar',
            summaryTitle: "Today's Weather Summary"
        },
        ta: {
            heroTitle: 'வானிலை உதவி',
            heroSubtitle: 'நிகழ்நேர வானிலை, முன்னறிவிப்பு மற்றும் எச்சரிக்கைகள் பெறுங்கள்',
            searchPlaceholder: 'நகரத்தைத் தேடுங்கள்...',
            chatbotTitle: 'வானிலை உதவி',
            chatPlaceholder: 'வானிலை பற்றி கேளுங்கள்...',
            forecastTitle: '5 நாள் முன்னறிவிப்பு',
            chartsTitle: 'வானிலை பகுப்பாய்வு',
            radarTitle: 'வானிலை ரேடார்',
            summaryTitle: 'இன்றைய வானிலை சுருக்கம்'
        },
        hi: {
            heroTitle: 'मौसम सहायक',
            heroSubtitle: 'रीयल-टाइम मौसम, पूर्वानुमान और सतर्कता प्राप्त करें',
            searchPlaceholder: 'शहर खोजें...',
            chatbotTitle: 'मौसम सहायक',
            chatPlaceholder: 'मौसम के बारे में पूछें...',
            forecastTitle: '5 दिन का पूर्वानुमान',
            chartsTitle: 'मौसम विश्लेषण',
            radarTitle: 'मौसम रडार',
            summaryTitle: 'आज का मौसम सारांश'
        },
        te: {
            heroTitle: 'వాతావరణ సహాయకుడు',
            heroSubtitle: 'రియల్-టైమ్ వాతావరణం, సూచనలు మరియు హెచ్చరికలను పొందండి',
            searchPlaceholder: 'నగరాన్ని వెతకండి...',
            chatbotTitle: 'వాతావరణ సహాయకుడు',
            chatPlaceholder: 'వాతావరణం గురించి అడగండి...',
            forecastTitle: '5 రోజుల సూచన',
            chartsTitle: 'వాతావరణ విశ్లేషణ',
            radarTitle: 'వాతావరణ రాడార్',
            summaryTitle: 'ఈ రోజు వాతావరణ సారాంశం'
        },
        ka: {
            heroTitle: 'ಹವಾಮಾನ ಸಹಾಯಕ',
            heroSubtitle: 'ನೈಜ-ಸಮಯ ಹವಾಮಾನ, ಮುನ್ನೆಚ್ಚರಿಕೆ ಮತ್ತು ಎಚ್ಚರಿಕೆಗಳನ್ನು ಪಡೆಯಿರಿ',
            searchPlaceholder: 'ನಗರವನ್ನು ಹುಡುಕಿ...',
            chatbotTitle: 'ಹವಾಮಾನ ಸಹಾಯಕ',
            chatPlaceholder: 'ಹವಾಮಾನದ ಬಗ್ಗೆ ಕೇಳಿ...',
            forecastTitle: '5 ದಿನಗಳ ಮುನ್ನೆಚ್ಚರಿಕೆ',
            chartsTitle: 'ಹವಾಮಾನ ವಿಶ್ಲೇಷಣೆ',
            radarTitle: 'ಹವಾಮಾನ ರೇಡಾರ್',
            summaryTitle: 'ಇಂದಿನ ಹವಾಮಾನ ಸಾರಾಂಶ'
        }
    };
    
    return translations[lang] || translations['en'];
}
