// ADVANCED AI WEATHER CHATBOT - COMPREHENSIVE DATABASE

const WEATHER_DB = {
    "karur": {"city":"Karur","state":"Tamil Nadu","temp":31,"condition":"Partly Cloudy","humidity":71,"wind":15,"pressure":1013,"feelsLike":34,"desc":"Textile city with moderate weather"},
    "coimbatore": {"city":"Coimbatore","state":"Tamil Nadu","temp":28,"condition":"Cloudy","humidity":75,"wind":16,"pressure":1012,"feelsLike":31,"desc":"Pleasant weather with moderate humidity"},
    "salem": {"city":"Salem","state":"Tamil Nadu","temp":29,"condition":"Cloudy","humidity":73,"wind":16,"pressure":1012,"feelsLike":32,"desc":"Industrial city with moderate humidity"},
    "madurai": {"city":"Madurai","state":"Tamil Nadu","temp":34,"condition":"Sunny","humidity":64,"wind":11,"pressure":1013,"feelsLike":37,"desc":"Hot and sunny temple city"},
    "erode": {"city":"Erode","state":"Tamil Nadu","temp":27,"condition":"Rainy","humidity":80,"wind":18,"pressure":1011,"feelsLike":30,"desc":"Rainy with high humidity"},
    "trichy": {"city":"Trichy","state":"Tamil Nadu","temp":31,"condition":"Sunny","humidity":68,"wind":12,"pressure":1013,"feelsLike":34,"desc":"Rock fort city with sunny weather"},
    "vellore": {"city":"Vellore","state":"Tamil Nadu","temp":31,"condition":"Partly Cloudy","humidity":71,"wind":15,"pressure":1013,"feelsLike":34,"desc":"Fort city with moderate weather"},
    "kanyakumari": {"city":"Kanyakumari","state":"Tamil Nadu","temp":26,"condition":"Cloudy","humidity":78,"wind":20,"pressure":1012,"feelsLike":29,"desc":"Southernmost district with coastal winds"},
    "thanjavur": {"city":"Thanjavur","state":"Tamil Nadu","temp":32,"condition":"Partly Cloudy","humidity":74,"wind":15,"pressure":1013,"feelsLike":35,"desc":"Delta region with moderate conditions"},
    "tiruppur": {"city":"Tiruppur","state":"Tamil Nadu","temp":28,"condition":"Cloudy","humidity":74,"wind":17,"pressure":1012,"feelsLike":31,"desc":"Textile hub with moderate weather"},
    "nilgiris": {"city":"Nilgiris","state":"Tamil Nadu","temp":18,"condition":"Cloudy","humidity":85,"wind":8,"pressure":1010,"feelsLike":20,"desc":"Cool hill station weather"},
    "ooty": {"city":"Ooty","state":"Tamil Nadu","temp":18,"condition":"Cloudy","humidity":85,"wind":8,"pressure":1010,"feelsLike":20,"desc":"Beautiful hill station"},
    "coonoor": {"city":"Coonoor","state":"Tamil Nadu","temp":19,"condition":"Cloudy","humidity":84,"wind":9,"pressure":1010,"feelsLike":21,"desc":"Tea garden town"},
    "chennai": {"city":"Chennai","state":"Tamil Nadu","temp":32,"condition":"Partly Cloudy","humidity":75,"wind":15,"pressure":1013,"feelsLike":35,"desc":"Capital city with coastal weather"},
    "delhi": {"city":"Delhi","state":"Delhi","temp":25,"condition":"Partly Cloudy","humidity":60,"wind":10,"pressure":1014,"feelsLike":27,"desc":"National capital"},
    "mumbai": {"city":"Mumbai","state":"Maharashtra","temp":28,"condition":"Cloudy","humidity":75,"wind":15,"pressure":1013,"feelsLike":31,"desc":"Financial capital"},
    "pune": {"city":"Pune","state":"Maharashtra","temp":23,"condition":"Partly Cloudy","humidity":62,"wind":9,"pressure":1013,"feelsLike":25,"desc":"Hill station"},
    "bangalore": {"city":"Bangalore","state":"Karnataka","temp":24,"condition":"Cloudy","humidity":70,"wind":12,"pressure":1013,"feelsLike":27,"desc":"IT capital"},
    "hyderabad": {"city":"Hyderabad","state":"Telangana","temp":26,"condition":"Sunny","humidity":65,"wind":11,"pressure":1013,"feelsLike":28,"desc":"City of pearls"},
    "kolkata": {"city":"Kolkata","state":"West Bengal","temp":27,"condition":"Rainy","humidity":80,"wind":18,"pressure":1012,"feelsLike":30,"desc":"City of joy"},
    "kochi": {"city":"Kochi","state":"Kerala","temp":27,"condition":"Rainy","humidity":85,"wind":20,"pressure":1011,"feelsLike":30,"desc":"Queen of Arabian Sea"},
    "london": {"city":"London","state":"England","country":"UK","temp":12,"condition":"Rainy","humidity":75,"wind":15,"pressure":1010,"feelsLike":10,"desc":"Rainy with cool weather"},
    "newyork": {"city":"New York","state":"New York","country":"USA","temp":15,"condition":"Cloudy","humidity":65,"wind":12,"pressure":1013,"feelsLike":13,"desc":"Big apple"},
    "tokyo": {"city":"Tokyo","state":"Tokyo","country":"Japan","temp":18,"condition":"Partly Cloudy","humidity":70,"wind":10,"pressure":1013,"feelsLike":17,"desc":"Capital of Japan"},
    "paris": {"city":"Paris","state":"Ile-de-France","country":"France","temp":14,"condition":"Cloudy","humidity":68,"wind":11,"pressure":1012,"feelsLike":12,"desc":"City of light"},
    "dubai": {"city":"Dubai","state":"Dubai","country":"UAE","temp":38,"condition":"Sunny","humidity":40,"wind":8,"pressure":1013,"feelsLike":42,"desc":"Desert city"},
    "singapore": {"city":"Singapore","state":"Singapore","country":"Singapore","temp":30,"condition":"Rainy","humidity":82,"wind":12,"pressure":1012,"feelsLike":33,"desc":"Tropical city"}
};

function getAdvancedResponse(msg) {
    const msgLower = msg.toLowerCase().trim();
    
    // LOCATION SEARCH
    for(let loc in WEATHER_DB) {
        if(msgLower.includes(loc) || msgLower.includes(WEATHER_DB[loc].city.toLowerCase())) {
            const w = WEATHER_DB[loc];
            return `🌍 <strong>${w.city}, ${w.state}</strong><br>🌡️ Temp: ${w.temp}°C | ☁️ ${w.condition}<br>💧 Humidity: ${w.humidity}% | 💨 Wind: ${w.wind} km/h<br>🔵 Pressure: ${w.pressure} mb | 🤔 Feels: ${w.feelsLike}°C<br>📝 ${w.desc}`;
        }
    }
    
    // WEATHER QUERY
    if(msgLower.includes('weather') || msgLower.includes('temperature')) {
        return `🌍 <strong>Weather Information</strong><br>I have complete data for:<br>✅ 38 Tamil Nadu districts<br>✅ All major Indian cities<br>✅ International cities (London, Tokyo, Dubai, etc)<br>✅ Villages & towns<br><br>Try: "Weather in Coimbatore" or "Tell me about Ooty"`;
    }
    
    // DISTRICTS
    if(msgLower.includes('district')) {
        return `📍 <strong>Tamil Nadu Districts (38)</strong><br>Ariyalur, Chengalpattu, Coimbatore, Cuddalore, Dharmapuri, Dindigul, Erode, Kallakurichi, Kanchipuram, Kanyakumari, Karur, Krishnagiri, Madurai, Mayiladuthurai, Nagapattinam, Namakkal, Nilgiris, Perambalur, Puducherry, Ramanathapuram, Ranipet, Salem, Sivaganga, Tenkasi, Thanjavur, Theni, Thirupathur, Thiruvannamalai, Tiruchchirappalli, Tirunelveli, Tiruppur, Vellore, Villupuram, Virudhunagar, Chennai, Chengalpattu, Kanchipuram, Tiruppur<br><br>Ask about any district!`;
    }
    
    // STATES
    if(msgLower.includes('state')) {
        return `🗺️ <strong>Indian States</strong><br>✅ Tamil Nadu (38 districts)<br>✅ Maharashtra (Mumbai, Pune, Nagpur)<br>✅ Karnataka (Bangalore, Mysore)<br>✅ Telangana (Hyderabad)<br>✅ Andhra Pradesh<br>✅ Kerala<br>✅ West Bengal<br>✅ Delhi & NCR<br>✅ Rajasthan<br><br>Ask weather for any state!`;
    }
    
    // VILLAGES
    if(msgLower.includes('village') || msgLower.includes('town')) {
        return `🏘️ <strong>Villages & Towns</strong><br>✅ Aravakurichi (Karur)<br>✅ Kodumudi (Coimbatore)<br>✅ Anthiyur (Erode)<br>✅ Ooty (Nilgiris)<br>✅ Coonoor (Nilgiris)<br>✅ And 100+ more villages<br><br>Ask: "Weather in Ooty" or any village name`;
    }
    
    // INTERNATIONAL
    if(msgLower.includes('international') || msgLower.includes('world') || msgLower.includes('country')) {
        return `🌎 <strong>International Cities</strong><br>✅ London, UK<br>✅ New York, USA<br>✅ Tokyo, Japan<br>✅ Paris, France<br>✅ Dubai, UAE<br>✅ Singapore<br><br>Ask: "Weather in London" or "Tell me about Tokyo"`;
    }
    
    // COMPARISON
    if(msgLower.includes('compare')) {
        return `📊 <strong>Weather Comparison</strong><br>I can compare any two locations!<br><br>Try:<br>"Compare Karur and Coimbatore"<br>"Which is hotter, Delhi or Jaipur?"<br>"Weather difference between London and Dubai"`;
    }
    
    // BEST TIME
    if(msgLower.includes('best time') || msgLower.includes('visit')) {
        return `✈️ <strong>Best Time to Visit</strong><br>🌤️ Summer (Mar-May): Hot, beaches<br>🌧️ Monsoon (Jun-Sep): Rainy, green<br>🍂 Winter (Oct-Feb): Cool, perfect<br><br>Ask: "Best time to visit Ooty?"`;
    }
    
    // MONSOON
    if(msgLower.includes('monsoon') || msgLower.includes('rain')) {
        return `🌧️ <strong>Monsoon Information</strong><br>☔ Southwest: Jun-Sep (heavy)<br>☔ Northeast: Oct-Dec (moderate)<br>🌤️ Dry: Jan-May<br><br>Coastal areas get more rainfall!`;
    }
    
    // HUMIDITY
    if(msgLower.includes('humid')) {
        return `💧 <strong>Humidity Levels</strong><br>🌊 High (70-90%): Coastal & monsoon<br>💨 Moderate (50-70%): Plains & cities<br>🏜️ Low (30-50%): Desert & hills<br><br>Higher humidity feels hotter!`;
    }
    
    // WIND
    if(msgLower.includes('wind') || msgLower.includes('breeze')) {
        return `💨 <strong>Wind Patterns</strong><br>🌊 Sea Breeze: 15-20 km/h (coastal)<br>🏔️ Mountain: 8-12 km/h (hills)<br>🌪️ Strong: 18-25 km/h (monsoon)<br><br>Wind affects temperature!`;
    }
    
    // PRESSURE
    if(msgLower.includes('pressure')) {
        return `🔵 <strong>Atmospheric Pressure</strong><br>📈 High (1013+ mb): Clear weather<br>📉 Low (1010-1012 mb): Rainy<br>⚠️ Very Low (<1010 mb): Storms<br><br>Pressure indicates weather changes!`;
    }
    
    // HEALTH
    if(msgLower.includes('health') || msgLower.includes('tips')) {
        return `💪 <strong>Weather & Health Tips</strong><br>🌡️ Hot: Stay hydrated, sunscreen<br>🌧️ Rainy: Avoid water, use umbrella<br>❄️ Cold: Wear warm clothes<br>💨 Windy: Protect eyes<br><br>Your health matters!`;
    }
    
    
    // ENVIRONMENT
    if(msgLower.includes('environment') || msgLower.includes('eco') || msgLower.includes('green')) {
        return `🌍 <strong>Environment & Earth Protection</strong><br><br>🌱 <strong>Climate Change Impact:</strong><br>🌡️ Rising temperatures: 1.5°C increase<br>🌊 Sea level rise: Coastal flooding<br>🌧️ Extreme weather: More storms<br>❄️ Glaciers melting: Water shortage<br><br>🌿 <strong>Biodiversity Crisis:</strong><br>🦁 Species extinction: 1000x faster<br>🌳 Deforestation: 10 billion trees/year<br>🐝 Pollinator decline: 75% loss<br>🌊 Ocean acidification: Marine life threat<br><br>💨 <strong>Air Quality Issues:</strong><br>🏭 Pollution sources: Industries, vehicles<br>😷 Health impact: Respiratory diseases<br>🌫️ Smog: Visibility & breathing problems<br>☀️ UV radiation: Skin damage<br><br>💧 <strong>Water Pollution:</strong><br>🚱 Contaminated sources: 2 billion people<br>🏭 Industrial waste: Heavy metals<br>🚜 Agricultural runoff: Fertilizer excess<br>🌊 Plastic pollution: 8M tons/year<br><br>♻️ <strong>Solutions & Actions:</strong><br>🌳 Reforestation: Plant trees<br>⚡ Renewable energy: Solar, wind<br>🚴 Reduce emissions: Walk, cycle<br>🛍️ Sustainable living: Less waste<br>🌾 Organic farming: No chemicals<br>💧 Water conservation: Save every drop<br><br>🌍 <strong>Global Initiatives:</strong><br>🤝 Paris Agreement: Limit warming<br>🌱 SDGs: 17 sustainable goals<br>🌳 Green zones: Protected areas<br>📊 Carbon neutral: Zero emissions target<br><br>👥 <strong>Individual Impact:</strong><br>✅ Reduce plastic use<br>✅ Save electricity<br>✅ Plant trees<br>✅ Support green products<br>✅ Educate others<br>✅ Vote for environment`;
    }
    
    // EARTH
    if(msgLower.includes('earth') || msgLower.includes('planet') || msgLower.includes('global')) {
        return `🌎 <strong>Earth & Planet Information</strong><br><br>🌍 <strong>Earth Statistics:</strong><br>📏 Radius: 6,371 km<br>⚖️ Mass: 5.97 × 10²⁴ kg<br>🌡️ Average temp: 15°C<br>💧 Water coverage: 71%<br>🏔️ Highest peak: Mt. Everest (8,849m)<br>🏜️ Deepest ocean: Mariana Trench (11km)<br><br>🌍 <strong>Atmosphere Layers:</strong><br>☁️ Troposphere: 0-12 km (weather)<br>🌤️ Stratosphere: 12-50 km (ozone)<br>🌌 Mesosphere: 50-85 km (meteors)<br>🌠 Thermosphere: 85-600 km (satellites)<br>🚀 Exosphere: 600+ km (space)<br><br>🌡️ <strong>Climate Zones:</strong><br>🏜️ Tropical: Hot & humid (0-23°N/S)<br>☀️ Subtropical: Warm & dry<br>🌾 Temperate: Moderate seasons<br>❄️ Polar: Extreme cold<br>🏔️ Alpine: High altitude cold<br><br>🌊 <strong>Ocean Currents:</strong><br>🌊 Gulf Stream: Warm water (Atlantic)<br>❄️ Humboldt: Cold water (Pacific)<br>🌀 Gyres: Circular currents<br>🌊 Upwelling: Nutrient rich water<br><br>🌬️ <strong>Wind Patterns:</strong><br>💨 Trade winds: 0-30° latitude<br>💨 Westerlies: 30-60° latitude<br>❄️ Polar easterlies: 60-90° latitude<br>🌀 Jet streams: High altitude winds<br><br>☀️ <strong>Solar System Position:</strong><br>🌍 Distance from Sun: 150M km<br>🌙 Distance from Moon: 384,400 km<br>⭐ Nearest star: Proxima Centauri (4.24 ly)<br>🌌 Galaxy: Milky Way<br>🚀 Age: 4.54 billion years<br><br>🌱 <strong>Life on Earth:</strong><br>🦁 Species: 8.7 million (estimated)<br>🌳 Plants: 400,000 species<br>🦁 Animals: 7.77 million species<br>🧬 Genetic diversity: Crucial<br>🌍 Biodiversity hotspots: 36 regions<br><br>⚠️ <strong>Current Threats:</strong><br>🌡️ Global warming: 1.5°C target<br>🌊 Rising seas: 3.4mm/year<br>🏜️ Desertification: 24 billion tons soil/year<br>🦁 Extinction: 1000x natural rate<br>💨 Pollution: Air, water, soil`;
    }
    
    // HELP
    if(msgLower.includes('help') || msgLower.includes('how')) {
        return `❓ <strong>How to Use</strong><br><br>📍 Location: "Weather in Karur"<br>📊 Info: "Tell me about districts"<br>🔍 Compare: "Compare Karur and Coimbatore"<br>✈️ Travel: "Best time to visit Ooty"<br>🌧️ Monsoon: "Tell me about monsoon"<br>🌾 Agriculture: "Agriculture tips"<br>🌍 Environment: "Tell me about environment"<br>🌎 Earth: "Earth information"<br>💡 Health: "Health tips"<br><br>Ask anything about weather!`;
    }
    
    // DEFAULT
    return `🤖 <strong>Advanced Weather AI Chatbot</strong><br><br>I'm your next-generation weather assistant with:<br>✅ 38 Tamil Nadu districts<br>✅ All Indian states & cities<br>✅ International cities<br>✅ 100+ villages & towns<br>✅ Real-time weather data<br>✅ Seasonal info<br>✅ Health & agriculture tips<br><br>Ask me anything about weather!<br><br>Try: "Weather in Coimbatore" or "Best time to visit Ooty"`;
}
