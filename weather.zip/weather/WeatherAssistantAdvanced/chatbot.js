// ===========================
// CHATBOT MODULE
// ===========================

let chatbotActive = false;
let messageHistory = [];

function initializeChatbot() {
    try {
        const chatbotIcon = document.getElementById('chatbotIcon');
        const sendBtn = document.getElementById('sendBtn');
        const voiceBtn = document.getElementById('voiceBtn');
        const chatInput = document.getElementById('chatInput');
        
        if (chatbotIcon) chatbotIcon.addEventListener('click', toggleChatbot);
        if (sendBtn) sendBtn.addEventListener('click', sendMessage);
        if (voiceBtn) voiceBtn.addEventListener('click', startVoiceInput);
        
        if (chatInput) {
            chatInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') sendMessage();
            });
        }
        
        displayWelcomeMessage();
    } catch (error) {
        console.error('Chatbot initialization error:', error);
    }
}

function toggleChatbot() {
    const chatbotWindow = document.getElementById('chatbotWindow');
    chatbotWindow.classList.toggle('active');
    chatbotActive = !chatbotActive;
}

function closeChatbot() {
    const chatbotWindow = document.getElementById('chatbotWindow');
    chatbotWindow.classList.remove('active');
    chatbotActive = false;
}

function displayWelcomeMessage() {
    const messagesContainer = document.getElementById('chatMessages');
    const welcomeMsg = document.createElement('div');
    welcomeMsg.className = 'chat-message';
    welcomeMsg.innerHTML = `
        <div class="message-content">
            <strong>👋 Welcome!</strong><br>
            Ask me about weather, forecast, humidity, wind, or alerts!
        </div>
    `;
    messagesContainer.appendChild(welcomeMsg);
}

function sendMessage() {
    const chatInput = document.getElementById('chatInput');
    const message = chatInput.value.trim();
    
    if (!message) return;
    
    // Display user message
    displayMessage(message, 'user');
    chatInput.value = '';
    
    // Get bot response
    const response = getBotResponse(message);
    
    // Display bot response
    setTimeout(() => {
        displayMessage(response, 'bot');
        // Speak response
        speakMessage(response);
    }, 500);
}

function displayMessage(text, sender) {
    const messagesContainer = document.getElementById('chatMessages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `chat-message ${sender === 'user' ? 'message-user' : ''}`;
    messageDiv.innerHTML = `<div class="message-content">${text}</div>`;
    messagesContainer.appendChild(messageDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
    
    messageHistory.push({ sender, text });
}

function getBotResponse(message) {
    const msg = message.toLowerCase();
    
    if (!currentWeather) {
        return 'Please search for a city first to get weather information.';
    }
    
    if (msg.includes('weather') || msg.includes('condition')) {
        return `The weather in ${currentWeather.city} is ${currentWeather.condition} with a temperature of ${Math.round(currentWeather.temp)}°C.`;
    }
    
    if (msg.includes('temperature') || msg.includes('temp')) {
        return `The current temperature in ${currentWeather.city} is ${Math.round(currentWeather.temp)}°C, and it feels like ${Math.round(currentWeather.feelsLike)}°C.`;
    }
    
    if (msg.includes('humidity')) {
        return `The humidity level in ${currentWeather.city} is ${currentWeather.humidity}%.`;
    }
    
    if (msg.includes('wind')) {
        return `The wind speed in ${currentWeather.city} is ${currentWeather.windSpeed} km/h.`;
    }
    
    if (msg.includes('rain') || msg.includes('forecast')) {
        return `The forecast for ${currentWeather.city} shows ${currentWeather.condition} conditions. Rain chance is ${currentWeather.rainChance}%.`;
    }
    
    if (msg.includes('alert')) {
        if (currentWeather.alerts && currentWeather.alerts.length > 0) {
            return `⚠️ Alert: ${currentWeather.alerts[0].description}`;
        }
        return 'No active weather alerts for this location.';
    }
    
    if (msg.includes('pressure')) {
        return `The atmospheric pressure in ${currentWeather.city} is ${currentWeather.pressure} mb.`;
    }
    
    return 'I can help with weather information. Ask me about temperature, humidity, wind, forecast, or alerts!';
}

function startVoiceInput() {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
        alert('Speech Recognition not supported in this browser');
        return;
    }
    
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    
    recognition.onstart = () => {
        document.getElementById('voiceBtn').style.background = '#ff6b6b';
    };
    
    recognition.onresult = (event) => {
        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
            transcript += event.results[i][0].transcript;
        }
        document.getElementById('chatInput').value = transcript;
        document.getElementById('voiceBtn').style.background = '';
    };
    
    recognition.onerror = (event) => {
        console.error('Speech recognition error', event.error);
        document.getElementById('voiceBtn').style.background = '';
    };
    
    recognition.start();
}

function speakMessage(text) {
    if (!('speechSynthesis' in window)) {
        console.log('Speech Synthesis not supported');
        return;
    }
    
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1;
    utterance.pitch = 1;
    utterance.volume = 1;
    
    window.speechSynthesis.speak(utterance);
}
