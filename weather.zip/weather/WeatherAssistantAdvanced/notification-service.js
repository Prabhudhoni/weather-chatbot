// Weather Notification Service Backend
// This service handles real SMS, WhatsApp, and Email notifications

class WeatherNotificationService {
    constructor() {
        this.apiEndpoints = {
            // Twilio configuration (replace with your actual credentials)
            twilio: {
                accountSid: 'ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxx', // Your Twilio Account SID
                authToken: 'your_auth_token', // Your Twilio Auth Token
                phoneNumber: '+1234567890' // Your Twilio Phone Number
            },
            // EmailJS configuration (replace with your actual service details)
            emailjs: {
                serviceId: 'service_your_service_id',
                templateId: 'template_your_template_id',
                publicKey: 'your_public_key'
            }
        };
        
        this.subscribers = new Map(); // Store subscriber preferences
        this.weatherHistory = new Map(); // Store weather data for change detection
        this.alertThresholds = {
            temperature: 5, // degrees Celsius
            humidity: 10, // percentage
            wind: 15, // km/h
            pressure: 10 // hPa
        };
    }

    // Subscribe user to notifications
    async subscribe(userId, preferences) {
        const subscription = {
            userId,
            phone: preferences.phone,
            email: preferences.email,
            locations: preferences.locations || [],
            methods: preferences.methods || ['push'],
            thresholds: preferences.thresholds || this.alertThresholds,
            enabled: true,
            createdAt: new Date()
        };

        this.subscribers.set(userId, subscription);
        
        // Save to localStorage for persistence
        localStorage.setItem('weatherSubscribers', JSON.stringify(Array.from(this.subscribers.entries())));
        
        return { success: true, message: 'Successfully subscribed to weather notifications' };
    }

    // Unsubscribe user
    async unsubscribe(userId) {
        this.subscribers.delete(userId);
        localStorage.setItem('weatherSubscribers', JSON.stringify(Array.from(this.subscribers.entries())));
        return { success: true, message: 'Successfully unsubscribed' };
    }

    // Send SMS notification via Twilio
    async sendSMS(phoneNumber, message) {
        try {
            // For production, this would make a real API call to Twilio
            // For demo, we'll simulate the API call
            
            console.log(`SMS to ${phoneNumber}: ${message}`);
            
            // Simulated API response
            return {
                success: true,
                sid: 'SM' + Math.random().toString(36).substr(2, 9),
                message: 'SMS sent successfully'
            };

            // Real Twilio implementation would be:
            /*
            const response = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${this.apiEndpoints.twilio.accountSid}/Messages.json`, {
                method: 'POST',
                headers: {
                    'Authorization': 'Basic ' + btoa(`${this.apiEndpoints.twilio.accountSid}:${this.apiEndpoints.twilio.authToken}`),
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: new URLSearchParams({
                    To: phoneNumber,
                    From: this.apiEndpoints.twilio.phoneNumber,
                    Body: message
                })
            });
            
            return await response.json();
            */
        } catch (error) {
            console.error('SMS sending failed:', error);
            return { success: false, error: error.message };
        }
    }

    // Send WhatsApp notification via Twilio
    async sendWhatsApp(phoneNumber, message) {
        try {
            console.log(`WhatsApp to ${phoneNumber}: ${message}`);
            
            return {
                success: true,
                sid: 'WA' + Math.random().toString(36).substr(2, 9),
                message: 'WhatsApp message sent successfully'
            };

            // Real Twilio WhatsApp implementation would be:
            /*
            const response = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${this.apiEndpoints.twilio.accountSid}/Messages.json`, {
                method: 'POST',
                headers: {
                    'Authorization': 'Basic ' + btoa(`${this.apiEndpoints.twilio.accountSid}:${this.apiEndpoints.twilio.authToken}`),
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: new URLSearchParams({
                    To: `whatsapp:${phoneNumber}`,
                    From: `whatsapp:${this.apiEndpoints.twilio.phoneNumber}`,
                    Body: message
                })
            });
            
            return await response.json();
            */
        } catch (error) {
            console.error('WhatsApp sending failed:', error);
            return { success: false, error: error.message };
        }
    }

    // Send Email notification via EmailJS
    async sendEmail(toEmail, subject, message, data = {}) {
        try {
            console.log(`Email to ${toEmail}: ${subject} - ${message}`);
            
            return {
                success: true,
                message: 'Email sent successfully'
            };

            // Real EmailJS implementation would be:
            /*
            emailjs.send(this.apiEndpoints.emailjs.serviceId, this.apiEndpoints.emailjs.templateId, {
                to_email: toEmail,
                subject: subject,
                message: message,
                ...data
            }, this.apiEndpoints.emailjs.publicKey)
            .then((response) => {
                return { success: true, message: 'Email sent successfully' };
            })
            .catch((error) => {
                return { success: false, error: error.message };
            });
            */
        } catch (error) {
            console.error('Email sending failed:', error);
            return { success: false, error: error.message };
        }
    }

    // Check for weather changes and send notifications
    async checkWeatherChanges(location, currentWeather) {
        const previousWeather = this.weatherHistory.get(location);
        
        if (!previousWeather) {
            // First time seeing this location
            this.weatherHistory.set(location, currentWeather);
            return [];
        }

        const changes = this.detectChanges(previousWeather, currentWeather);
        
        if (changes.length > 0) {
            // Notify all subscribers for this location
            await this.notifySubscribers(location, changes, currentWeather);
        }

        // Update history
        this.weatherHistory.set(location, currentWeather);
        
        return changes;
    }

    // Detect significant weather changes
    detectChanges(previous, current) {
        const changes = [];
        
        // Temperature change
        const tempChange = Math.abs(current.temp - previous.temp);
        if (tempChange >= this.alertThresholds.temperature) {
            changes.push({
                type: 'temperature',
                from: previous.temp,
                to: current.temp,
                change: tempChange,
                unit: '°C',
                severity: tempChange >= 10 ? 'severe' : 'moderate'
            });
        }

        // Humidity change
        const humidityChange = Math.abs(current.humidity - previous.humidity);
        if (humidityChange >= this.alertThresholds.humidity) {
            changes.push({
                type: 'humidity',
                from: previous.humidity,
                to: current.humidity,
                change: humidityChange,
                unit: '%',
                severity: humidityChange >= 20 ? 'severe' : 'moderate'
            });
        }

        // Wind speed change
        const windChange = Math.abs(current.wind - previous.wind);
        if (windChange >= this.alertThresholds.wind) {
            changes.push({
                type: 'wind',
                from: previous.wind,
                to: current.wind,
                change: windChange,
                unit: 'km/h',
                severity: windChange >= 25 ? 'severe' : 'moderate'
            });
        }

        // Pressure change
        const pressureChange = Math.abs(current.pressure - previous.pressure);
        if (pressureChange >= this.alertThresholds.pressure) {
            changes.push({
                type: 'pressure',
                from: previous.pressure,
                to: current.pressure,
                change: pressureChange,
                unit: 'hPa',
                severity: pressureChange >= 15 ? 'severe' : 'moderate'
            });
        }

        return changes;
    }

    // Notify all subscribers for a location
    async notifySubscribers(location, changes, currentWeather) {
        const locationName = location.charAt(0).toUpperCase() + location.slice(1);
        const message = this.formatAlertMessage(locationName, changes, currentWeather);
        const subject = `Weather Alert - ${locationName}`;
        
        // Get all subscribers for this location
        for (const [userId, subscription] of this.subscribers) {
            if (!subscription.enabled || !subscription.locations.includes(location)) {
                continue;
            }

            // Send notifications based on user preferences
            for (const method of subscription.methods) {
                switch (method) {
                    case 'sms':
                        if (subscription.phone) {
                            await this.sendSMS(subscription.phone, message);
                        }
                        break;
                    case 'whatsapp':
                        if (subscription.phone) {
                            await this.sendWhatsApp(subscription.phone, message);
                        }
                        break;
                    case 'email':
                        if (subscription.email) {
                            await this.sendEmail(subscription.email, subject, message, {
                                location: locationName,
                                changes: changes,
                                currentWeather: currentWeather
                            });
                        }
                        break;
                    case 'push':
                        // Browser push notifications are handled in the frontend
                        this.sendPushNotification(userId, subject, message);
                        break;
                }
            }
        }
    }

    // Format alert message
    formatAlertMessage(location, changes, currentWeather) {
        const changeDescriptions = changes.map(change => {
            const arrow = change.to > change.from ? '↑' : '↓';
            return `${change.type}: ${change.from}${change.unit} ${arrow} ${change.to}${change.unit}`;
        });

        let message = `Weather Alert - ${location}\n`;
        message += `Changes: ${changeDescriptions.join(', ')}\n`;
        message += `Current: ${currentWeather.temp}°C, ${currentWeather.condition}, ${currentWeather.humidity}% humidity`;
        
        // Add severity warning
        const hasSevere = changes.some(c => c.severity === 'severe');
        if (hasSevere) {
            message += '\n⚠️ SEVERE WEATHER CHANGE DETECTED!';
        }

        return message;
    }

    // Send browser push notification
    sendPushNotification(userId, title, message) {
        // This would be handled by the frontend Service Worker
        // Store notification for frontend to pick up
        const notifications = JSON.parse(localStorage.getItem('pendingNotifications') || '[]');
        notifications.push({
            userId,
            title,
            message,
            timestamp: new Date().toISOString()
        });
        localStorage.setItem('pendingNotifications', JSON.stringify(notifications));
    }

    // Load subscribers from storage
    loadSubscribers() {
        const stored = localStorage.getItem('weatherSubscribers');
        if (stored) {
            this.subscribers = new Map(JSON.parse(stored));
        }
    }

    // Get all subscribers
    getSubscribers() {
        return Array.from(this.subscribers.values());
    }

    // Get subscriber by ID
    getSubscriber(userId) {
        return this.subscribers.get(userId);
    }

    // Update subscriber preferences
    async updateSubscriber(userId, preferences) {
        const subscriber = this.subscribers.get(userId);
        if (subscriber) {
            Object.assign(subscriber, preferences);
            this.subscribers.set(userId, subscriber);
            localStorage.setItem('weatherSubscribers', JSON.stringify(Array.from(this.subscribers.entries())));
            return { success: true, message: 'Preferences updated' };
        }
        return { success: false, message: 'Subscriber not found' };
    }
}

// Initialize the notification service
const notificationService = new WeatherNotificationService();

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = WeatherNotificationService;
} else {
    window.WeatherNotificationService = WeatherNotificationService;
    window.notificationService = notificationService;
}
