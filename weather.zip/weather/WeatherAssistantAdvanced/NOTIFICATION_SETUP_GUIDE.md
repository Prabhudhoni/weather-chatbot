# Weather Phone Notifications Setup Guide

## Overview
This system allows you to receive real-time weather change notifications on your phone via multiple methods:
- **Browser Push Notifications** (Free - works on desktop/mobile browsers)
- **SMS Messages** (Requires Twilio account)
- **WhatsApp Messages** (Requires Twilio WhatsApp API)
- **Email Alerts** (Requires EmailJS or similar service)

## Quick Start

### 1. Open the Notification System
Navigate to: `weather-notifications.html`

### 2. Setup Your Notification Method

#### Option A: Browser Push Notifications (Free)
1. Click "Setup Notifications"
2. Select "Push Notification (Web)"
3. Click "Setup Notifications" button
4. Allow browser notifications when prompted

#### Option B: SMS Notifications (Paid)
1. **Setup Twilio Account:**
   - Sign up at https://www.twilio.com
   - Get your Account SID and Auth Token
   - Purchase a phone number
2. **Configure the Service:**
   - Open `notification-service.js`
   - Replace the placeholder values with your Twilio credentials
3. **In the Notification System:**
   - Enter your phone number (with country code, e.g., +1234567890)
   - Select "SMS (via Twilio)"
   - Click "Setup Notifications"

#### Option C: WhatsApp Notifications (Paid)
1. **Setup Twilio WhatsApp:**
   - Activate WhatsApp Business API in your Twilio account
   - Get WhatsApp-approved phone number
2. **Configure the Service:**
   - Update `notification-service.js` with your WhatsApp credentials
3. **In the Notification System:**
   - Enter your phone number
   - Select "WhatsApp (via Twilio)"
   - Click "Setup Notifications"

#### Option D: Email Notifications (Free/Paid)
1. **Option 1 - EmailJS (Free tier available):**
   - Sign up at https://www.emailjs.com
   - Create email service and template
   - Get your Service ID, Template ID, and Public Key
2. **Option 2 - Backend Email Service:**
   - Use your own email server or service like SendGrid
3. **Configure the Service:**
   - Update `notification-service.js` with your email service details
4. **In the Notification System:**
   - Select "Email Alert"
   - Enter your email address
   - Click "Setup Notifications"

### 3. Configure Weather Monitoring
1. **Select Location:** Choose the city you want to monitor
2. **Set Check Interval:** How often to check for weather changes
3. **Set Alert Thresholds:** Minimum change required to trigger notification
4. **Click "Start Monitoring"**

## Features

### Real-Time Weather Change Detection
The system monitors:
- **Temperature Changes** (default: 5°C threshold)
- **Humidity Changes** (default: 10% threshold)
- **Wind Speed Changes** (default: 15 km/h threshold)
- **Pressure Changes** (default: 10 hPa threshold)

### Notification Types
- **Moderate Changes:** Standard weather variations
- **Severe Changes:** Significant weather shifts (marked with ⚠️)

### Alert Message Format
```
Weather Alert - [Location]
Changes: temperature: 25°C ↑ 30°C, humidity: 60% ↓ 80%
Current: 30°C, Partly Cloudy, 80% humidity
⚠️ SEVERE WEATHER CHANGE DETECTED! (if applicable)
```

## Configuration Options

### Custom Thresholds
You can customize alert thresholds based on your needs:
- **Temperature:** 1-20°C changes
- **Humidity:** 5-50% changes
- **Wind:** 5-50 km/h changes
- **Pressure:** 2-25 hPa changes

### Multiple Locations
Monitor multiple cities simultaneously:
- Add each location separately
- Set different thresholds per location
- Choose notification methods per location

### Notification Methods
Combine multiple methods:
- Browser + SMS for redundancy
- Email + WhatsApp for detailed alerts
- All methods for maximum coverage

## Technical Setup

### File Structure
```
WeatherAssistantAdvanced/
├── weather-notifications.html      # Main notification interface
├── notification-service.js         # Backend notification service
├── weather-data.json              # Weather dataset
└── NOTIFICATION_SETUP_GUIDE.md     # This guide
```

### API Integration

#### Twilio Setup (SMS/WhatsApp)
```javascript
// In notification-service.js
twilio: {
    accountSid: 'ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxx', // Your Account SID
    authToken: 'your_auth_token',                 // Your Auth Token
    phoneNumber: '+1234567890'                    // Your Twilio Number
}
```

#### EmailJS Setup
```javascript
// In notification-service.js
emailjs: {
    serviceId: 'service_your_service_id',
    templateId: 'template_your_template_id',
    publicKey: 'your_public_key'
}
```

### Browser Push Notifications
Works automatically with modern browsers:
- Chrome/Chromium (desktop and mobile)
- Firefox (desktop and mobile)
- Safari (desktop and mobile)
- Edge (desktop and mobile)

## Testing

### Test Notifications
1. After setup, click "Setup Notifications" to send a test alert
2. Check your chosen notification method
3. Verify the message format and delivery

### Test Weather Changes
1. Start monitoring with a short interval (1 minute)
2. The system simulates weather changes for testing
3. Observe notifications being triggered

## Troubleshooting

### Common Issues

#### Browser Notifications Not Working
- Check if notifications are allowed in browser settings
- Ensure the tab stays open (push notifications require active page)
- Try refreshing the page and re-enabling

#### SMS Not Sending
- Verify Twilio credentials are correct
- Check if phone number format includes country code
- Ensure Twilio account has sufficient balance

#### WhatsApp Not Working
- Verify WhatsApp Business API is activated
- Check if recipient has opted in to receive messages
- Ensure phone number is WhatsApp-registered

#### Email Not Sending
- Verify EmailJS configuration
- Check email template is properly set up
- Ensure email address is valid

### Debug Mode
Enable console logging to troubleshoot:
1. Open browser developer tools (F12)
2. Check Console tab for error messages
3. Look for network requests in Network tab

## Security Considerations

### Protect API Credentials
- Never expose API keys in frontend code
- Use environment variables for sensitive data
- Consider implementing a backend proxy for API calls

### Privacy
- Phone numbers and emails are stored locally
- No data is sent to external servers except notification APIs
- Clear local storage if needed

### Rate Limiting
- Twilio has rate limits for SMS/WhatsApp
- EmailJS has daily sending limits
- Implement delays between notifications if needed

## Advanced Features

### Custom Alert Rules
Create complex alert conditions:
```javascript
// Example: Alert only for temperature drops > 10°C
if (change.type === 'temperature' && change.to < change.from && change.change >= 10) {
    sendAlert();
}
```

### Scheduled Notifications
Set up time-based alerts:
```javascript
// Example: Daily weather summary at 8 AM
if (new Date().getHours() === 8 && new Date().getMinutes() === 0) {
    sendDailySummary();
}
```

### Integration with Weather APIs
Connect to real weather services:
- OpenWeatherMap API
- WeatherAPI.com
- AccuWeather API
- Custom weather data sources

## Support

### Getting Help
- Check this guide first
- Review browser console for errors
- Test with different notification methods
- Verify API service status

### Feature Requests
For additional features:
- Multiple phone numbers
- Custom message templates
- Weather forecast alerts
- Integration with smart home devices

---

**Ready to use!** Open `weather-notifications.html` to start receiving weather alerts on your phone.
