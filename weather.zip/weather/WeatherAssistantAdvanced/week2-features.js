// ============================================
// WEEK 2: ENHANCEMENT FEATURES
// Multi-language, Advanced Charts, User Preferences, Better UI/UX
// ============================================

// ============================================
// 1. MULTI-LANGUAGE SUPPORT
// ============================================
class LanguageManager {
    constructor() {
        this.currentLanguage = localStorage.getItem('language') || 'en';
        this.translations = {
            en: {
                weather: 'Weather',
                temperature: 'Temperature',
                humidity: 'Humidity',
                wind: 'Wind',
                pressure: 'Pressure',
                feelsLike: 'Feels Like',
                search: 'Search',
                forecast: '7-Day Forecast',
                alerts: 'Alerts',
                settings: 'Settings',
                darkMode: 'Dark Mode',
                language: 'Language',
                units: 'Units',
                about: 'About',
                help: 'Help',
                loading: 'Loading...',
                error: 'Error',
                noData: 'No data available',
                location: 'Location',
                condition: 'Condition',
                maxTemp: 'Max Temp',
                minTemp: 'Min Temp',
                rainChance: 'Rain Chance',
                myLocation: 'My Location',
                favorites: 'Favorites',
                addFavorite: 'Add to Favorites',
                removeFavorite: 'Remove from Favorites'
            },
            ta: {
                weather: 'வானிலை',
                temperature: 'வெப்பநிலை',
                humidity: 'ஈரப்பதம்',
                wind: 'காற்று',
                pressure: 'அழுத்தம்',
                feelsLike: 'உணர்ந்த வெப்பநிலை',
                search: 'தேடல்',
                forecast: '7 நாள் முன்னறிவிப்பு',
                alerts: 'எச்சரிக்கைகள்',
                settings: 'அமைப்புகள்',
                darkMode: 'இருண்ட பயன்முறை',
                language: 'மொழி',
                units: 'அலகுகள்',
                about: 'பற்றி',
                help: 'உதவி',
                loading: 'ஏற்றுதல்...',
                error: 'பிழை',
                noData: 'தரவு கிடைக்கவில்லை',
                location: 'இடம்',
                condition: 'நிலை',
                maxTemp: 'அதிகபட்ச வெப்பநிலை',
                minTemp: 'குறைந்தபட்ச வெப்பநிலை',
                rainChance: 'மழை வாய்ப்பு',
                myLocation: 'என் இடம்',
                favorites: 'பிடித்தவை',
                addFavorite: 'பிடித்தவைகளில் சேர்க்கவும்',
                removeFavorite: 'பிடித்தவைகளிலிருந்து அகற்றவும்'
            },
            hi: {
                weather: 'मौसम',
                temperature: 'तापमान',
                humidity: 'आर्द्रता',
                wind: 'हवा',
                pressure: 'दबाव',
                feelsLike: 'महसूस होता है',
                search: 'खोज',
                forecast: '7 दिन का पूर्वानुमान',
                alerts: 'सतर्कताएं',
                settings: 'सेटिंग्स',
                darkMode: 'डार्क मोड',
                language: 'भाषा',
                units: 'इकाइयां',
                about: 'के बारे में',
                help: 'सहायता',
                loading: 'लोड हो रहा है...',
                error: 'त्रुटि',
                noData: 'कोई डेटा उपलब्ध नहीं',
                location: 'स्थान',
                condition: 'स्थिति',
                maxTemp: 'अधिकतम तापमान',
                minTemp: 'न्यूनतम तापमान',
                rainChance: 'बारिश की संभावना',
                myLocation: 'मेरा स्थान',
                favorites: 'पसंदीदा',
                addFavorite: 'पसंदीदा में जोड़ें',
                removeFavorite: 'पसंदीदा से हटाएं'
            },
            te: {
                weather: 'వాతావరణం',
                temperature: 'ఉష్ణోగ్రత',
                humidity: 'ఆర్ద్రత',
                wind: 'గాలి',
                pressure: 'పీడనం',
                feelsLike: 'అనిపిస్తుంది',
                search: 'శోధన',
                forecast: '7 రోజుల సూచన',
                alerts: 'హెచ్చరికలు',
                settings: 'సెట్టింగ్‌లు',
                darkMode: 'డార్క్ మోడ్',
                language: 'భాష',
                units: 'యూనిట్‌లు',
                about: 'గురించి',
                help: 'సహాయం',
                loading: 'లోడ్ చేస్తోంది...',
                error: 'ఎర్రర్',
                noData: 'డేటా అందుబాటులో లేదు',
                location: 'స్థానం',
                condition: 'స్థితి',
                maxTemp: 'గరిష్ట ఉష్ణోగ్రత',
                minTemp: 'కనిష్ట ఉష్ణోగ్రత',
                rainChance: 'వర్షం సంభావ్యత',
                myLocation: 'నా స్థానం',
                favorites: 'ఇష్టమైనవి',
                addFavorite: 'ఇష్టమైనవిలో జోడించండి',
                removeFavorite: 'ఇష్టమైనవి నుండి తీసివేయండి'
            },
            kn: {
                weather: 'ಹವಾಮಾನ',
                temperature: 'ತಾಪಮಾನ',
                humidity: 'ಆರ್ದ್ರತೆ',
                wind: 'ಗಾಳಿ',
                pressure: 'ಒತ್ತಡ',
                feelsLike: 'ಅನುಭವವಾಗುತ್ತದೆ',
                search: 'ಹುಡುಕು',
                forecast: '7 ದಿನಗಳ ಮುನ್ನೋಟ',
                alerts: 'ಎಚ್ಚರಿಕೆಗಳು',
                settings: 'ಸೆಟ್ಟಿಂಗ್‌ಗಳು',
                darkMode: 'ಡಾರ್ಕ್ ಮೋಡ್',
                language: 'ಭಾಷೆ',
                units: 'ಘಟಕಗಳು',
                about: 'ಬಗ್ಗೆ',
                help: 'ಸಹಾಯ',
                loading: 'ಲೋಡ್ ಆಗುತ್ತಿದೆ...',
                error: 'ದೋಷ',
                noData: 'ಡೇಟಾ ಲಭ್ಯವಿಲ್ಲ',
                location: 'ಸ್ಥಳ',
                condition: 'ಸ್ಥಿತಿ',
                maxTemp: 'ಗರಿಷ್ಠ ತಾಪಮಾನ',
                minTemp: 'ಕನಿಷ್ಠ ತಾಪಮಾನ',
                rainChance: 'ಮಳೆಯ ಸಾಧ್ಯತೆ',
                myLocation: 'ನನ್ನ ಸ್ಥಳ',
                favorites: 'ಮೆಚ್ಚಿನವು',
                addFavorite: 'ಮೆಚ್ಚಿನವುಗಳಿಗೆ ಸೇರಿಸಿ',
                removeFavorite: 'ಮೆಚ್ಚಿನವುಗಳಿಂದ ತೆಗೆದುಹಾಕಿ'
            }
        };
        this.init();
    }

    init() {
        this.setLanguage(this.currentLanguage);
    }

    setLanguage(lang) {
        if(!this.translations[lang]) {
            lang = 'en';
        }
        this.currentLanguage = lang;
        localStorage.setItem('language', lang);
        document.documentElement.lang = lang;
        this.updatePageText();
    }

    getTranslation(key) {
        return this.translations[this.currentLanguage][key] || this.translations['en'][key] || key;
    }

    updatePageText() {
        document.querySelectorAll('[data-i18n]').forEach(el => {
            const key = el.getAttribute('data-i18n');
            el.textContent = this.getTranslation(key);
        });
    }

    getAvailableLanguages() {
        return {
            en: 'English',
            ta: 'Tamil',
            hi: 'Hindi',
            te: 'Telugu',
            kn: 'Kannada'
        };
    }
}

// ============================================
// 2. ADVANCED CHARTS
// ============================================
class AdvancedCharts {
    constructor() {
        this.charts = {};
    }

    createTemperatureChart(canvasId, data) {
        const ctx = document.getElementById(canvasId);
        if(!ctx || typeof Chart === 'undefined') return;

        if(this.charts[canvasId]) {
            this.charts[canvasId].destroy();
        }

        this.charts[canvasId] = new Chart(ctx, {
            type: 'line',
            data: {
                labels: data.labels,
                datasets: [
                    {
                        label: 'Max Temperature',
                        data: data.maxTemp,
                        borderColor: '#f44336',
                        backgroundColor: 'rgba(244, 67, 54, 0.1)',
                        tension: 0.4,
                        fill: true
                    },
                    {
                        label: 'Min Temperature',
                        data: data.minTemp,
                        borderColor: '#2196f3',
                        backgroundColor: 'rgba(33, 150, 243, 0.1)',
                        tension: 0.4,
                        fill: true
                    }
                ]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { display: true },
                    title: { display: true, text: 'Temperature Trend' }
                },
                scales: {
                    y: { beginAtZero: false }
                }
            }
        });
    }

    createHumidityChart(canvasId, data) {
        const ctx = document.getElementById(canvasId);
        if(!ctx || typeof Chart === 'undefined') return;

        if(this.charts[canvasId]) {
            this.charts[canvasId].destroy();
        }

        this.charts[canvasId] = new Chart(ctx, {
            type: 'area',
            data: {
                labels: data.labels,
                datasets: [{
                    label: 'Humidity (%)',
                    data: data.humidity,
                    borderColor: '#00bcd4',
                    backgroundColor: 'rgba(0, 188, 212, 0.2)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { display: true },
                    title: { display: true, text: 'Humidity Levels' }
                },
                scales: {
                    y: { min: 0, max: 100 }
                }
            }
        });
    }

    createWindChart(canvasId, data) {
        const ctx = document.getElementById(canvasId);
        if(!ctx || typeof Chart === 'undefined') return;

        if(this.charts[canvasId]) {
            this.charts[canvasId].destroy();
        }

        this.charts[canvasId] = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: data.labels,
                datasets: [{
                    label: 'Wind Speed (km/h)',
                    data: data.windSpeed,
                    backgroundColor: '#9c27b0',
                    borderColor: '#7b1fa2',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { display: true },
                    title: { display: true, text: 'Wind Speed' }
                }
            }
        });
    }

    createRainfallChart(canvasId, data) {
        const ctx = document.getElementById(canvasId);
        if(!ctx || typeof Chart === 'undefined') return;

        if(this.charts[canvasId]) {
            this.charts[canvasId].destroy();
        }

        this.charts[canvasId] = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: data.labels,
                datasets: [{
                    label: 'Rainfall (mm)',
                    data: data.rainfall,
                    backgroundColor: '#4caf50',
                    borderColor: '#388e3c',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { display: true },
                    title: { display: true, text: 'Rainfall' }
                }
            }
        });
    }

    destroyChart(canvasId) {
        if(this.charts[canvasId]) {
            this.charts[canvasId].destroy();
            delete this.charts[canvasId];
        }
    }
}

// ============================================
// 3. USER PREFERENCES
// ============================================
class UserPreferences {
    constructor() {
        this.defaults = {
            units: 'metric',
            theme: 'light',
            language: 'en',
            favorites: [],
            notifications: true,
            autoLocation: true,
            refreshInterval: 30,
            temperatureUnit: 'celsius',
            windUnit: 'kmh',
            pressureUnit: 'mb'
        };
        this.preferences = this.load();
    }

    load() {
        const saved = localStorage.getItem('userPreferences');
        return saved ? JSON.parse(saved) : this.defaults;
    }

    save() {
        localStorage.setItem('userPreferences', JSON.stringify(this.preferences));
    }

    set(key, value) {
        this.preferences[key] = value;
        this.save();
    }

    get(key) {
        return this.preferences[key] !== undefined ? this.preferences[key] : this.defaults[key];
    }

    addFavorite(city) {
        if(!this.preferences.favorites.includes(city)) {
            this.preferences.favorites.push(city);
            this.save();
            return true;
        }
        return false;
    }

    removeFavorite(city) {
        const index = this.preferences.favorites.indexOf(city);
        if(index > -1) {
            this.preferences.favorites.splice(index, 1);
            this.save();
            return true;
        }
        return false;
    }

    getFavorites() {
        return this.preferences.favorites;
    }

    isFavorite(city) {
        return this.preferences.favorites.includes(city);
    }

    reset() {
        this.preferences = { ...this.defaults };
        this.save();
    }
}

// ============================================
// 4. UI/UX ENHANCEMENTS
// ============================================
class UIEnhancements {
    constructor() {
        this.animations = true;
    }

    addLoadingState(element) {
        element.classList.add('loading');
        element.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...';
    }

    removeLoadingState(element, content) {
        element.classList.remove('loading');
        element.innerHTML = content;
    }

    showToast(message, type = 'info', duration = 3000) {
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.textContent = message;
        toast.style.cssText = `
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: ${type === 'success' ? '#4caf50' : type === 'error' ? '#f44336' : '#2196f3'};
            color: white;
            padding: 1rem 1.5rem;
            border-radius: 0.5rem;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            z-index: 10000;
            animation: slideIn 0.3s ease;
        `;

        document.body.appendChild(toast);

        setTimeout(() => {
            toast.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => toast.remove(), 300);
        }, duration);
    }

    showModal(title, content, buttons = []) {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10000;
        `;

        const modalContent = document.createElement('div');
        modalContent.style.cssText = `
            background: white;
            padding: 2rem;
            border-radius: 1rem;
            max-width: 500px;
            width: 90%;
            box-shadow: 0 12px 40px rgba(0,0,0,0.2);
        `;

        modalContent.innerHTML = `
            <h2 style="margin-bottom: 1rem; color: #0066cc">${title}</h2>
            <div style="margin-bottom: 1.5rem">${content}</div>
            <div style="display: flex; gap: 1rem; justify-content: flex-end">
                ${buttons.map(btn => `
                    <button onclick="${btn.action}" style="
                        padding: 0.75rem 1.5rem;
                        border: none;
                        border-radius: 0.5rem;
                        cursor: pointer;
                        font-weight: 600;
                        background: ${btn.type === 'primary' ? '#0066cc' : '#ccc'};
                        color: ${btn.type === 'primary' ? 'white' : '#333'};
                    ">${btn.label}</button>
                `).join('')}
            </div>
        `;

        modal.appendChild(modalContent);
        document.body.appendChild(modal);

        modal.onclick = (e) => {
            if(e.target === modal) modal.remove();
        };

        return modal;
    }

    smoothScroll(element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    addPulseAnimation(element) {
        element.style.animation = 'pulse 2s infinite';
    }

    addFadeInAnimation(element) {
        element.style.animation = 'fadeIn 0.5s ease';
    }
}

// ============================================
// INITIALIZATION
// ============================================
const languageManager = new LanguageManager();
const advancedCharts = new AdvancedCharts();
const userPreferences = new UserPreferences();
const uiEnhancements = new UIEnhancements();

// Export for use in HTML
window.languageManager = languageManager;
window.advancedCharts = advancedCharts;
window.userPreferences = userPreferences;
window.uiEnhancements = uiEnhancements;
