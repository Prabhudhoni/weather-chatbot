// ===========================
// ALERTS MODULE
// ===========================

function initializeAlerts() {
    // Request notification permission
    if ('Notification' in window && Notification.permission === 'default') {
        Notification.requestPermission();
    }
}

function sendNotification(title, options = {}) {
    if ('Notification' in window && Notification.permission === 'granted') {
        new Notification(title, {
            icon: 'https://cdn-icons-png.flaticon.com/512/1779/1779807.png',
            ...options
        });
    }
}

function checkAlerts(weatherData) {
    if (!weatherData || !weatherData.alerts) return;
    
    weatherData.alerts.forEach(alert => {
        sendNotification(alert.title, {
            body: alert.description,
            tag: 'weather-alert',
            requireInteraction: true
        });
    });
}

// Initialize on load
document.addEventListener('DOMContentLoaded', initializeAlerts);
