# Twilio SMS Setup for Weather Notifications

## Overview
This guide will help you set up Twilio SMS service to receive weather alerts on your phone via SMS messages.

## Step 1: Create Twilio Account

### 1.1 Sign Up
1. Go to https://www.twilio.com
2. Click "Sign Up" → "Create an Account"
3. Fill in your details:
   - Email address
   - Password
   - Phone number (for verification)
4. Verify your email and phone number

### 1.2 Choose Plan
- **Trial Account**: Free with $15.50 credit (enough for testing)
- **Paid Plans**: Start from $0.0079 per SMS message

## Step 2: Get Your Twilio Credentials

### 2.1 Find Your Account Details
1. Login to your Twilio Console
2. Go to **Dashboard** → **Project Info**
3. You'll find:
   - **Account SID** (starts with "AC")
   - **Auth Token** (click "Show" to reveal)

### 2.2 Get a Phone Number
1. In Twilio Console, go to **Phone Numbers** → **Manage** → **Buy a Number**
2. Choose your country and capabilities:
   - ✅ **SMS** enabled
   - (Optional) **Voice** enabled
3. Search and select a number
4. Complete the purchase

## Step 3: Configure Your Weather App

### 3.1 Update Notification Service
Open `notification-service.js` and replace the placeholder values:

```javascript
twilio: {
    accountSid: 'ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxx', // Replace with your Account SID
    authToken: 'your_actual_auth_token_here',       // Replace with your Auth Token
    phoneNumber: '+1234567890'                      // Replace with your Twilio phone number
}
```

### 3.2 Example Configuration
```javascript
twilio: {
    accountSid: 'AC1234567890abcdef1234567890abcdef',
    authToken: 'd41d8cd98f00b204e9800998ecf8427e',
    phoneNumber: '+15551234567'
}
```

## Step 4: Test Your Setup

### 4.1 Start the Weather App
1. Double-click `START_NOTIFICATIONS.bat`
2. Open `weather-notifications.html` in your browser

### 4.2 Configure SMS Notifications
1. Enter your phone number (with country code)
   - Example: +919876543210 (India)
   - Example: +15551234567 (USA)
2. Select "SMS (via Twilio)" as notification method
3. Click "Setup Notifications"

### 4.3 Send Test SMS
1. Click "Setup" button
2. You should receive a test SMS message
3. Check your phone for the message

## Step 5: Start Monitoring

### 5.1 Configure Monitoring
1. Select location to monitor (e.g., "karur")
2. Set check interval (e.g., "Every 5 minutes")
3. Set alert thresholds:
   - Temperature: 5°C
   - Humidity: 10%
   - Wind: 15 km/h
   - Pressure: 10 hPa

### 5.2 Start Monitoring
1. Click "Start Monitoring"
2. The system will check for weather changes
3. You'll receive SMS alerts when changes occur

## SMS Message Format

### Standard Alert
```
Weather Alert - Karur
Changes: temperature: 25°C ↑ 30°C, humidity: 60% ↓ 80%
Current: 30°C, Partly Cloudy, 80% humidity
```

### Severe Alert
```
Weather Alert - Chennai
Changes: temperature: 28°C ↑ 38°C, humidity: 40% ↓ 90%
Current: 38°C, Very Hot, 90% humidity
⚠️ SEVERE WEATHER CHANGE DETECTED!
```

## Troubleshooting

### Common Issues

#### SMS Not Sending
**Problem**: No SMS received
**Solutions**:
1. Check Twilio credentials in `notification-service.js`
2. Verify phone number format (include country code: +91xxxxxxxxxx)
3. Check Twilio account balance
4. Verify your phone number can receive SMS

#### Invalid Phone Number
**Problem**: Phone number format error
**Solution**:
- Always include country code
- Format: +[country code][number]
- Examples:
  - India: +919876543210
  - USA: +15551234567
  - UK: +442071234567

#### Twilio Account Issues
**Problem**: Account not verified
**Solution**:
1. Complete Twilio account verification
2. Add payment method for trial account
3. Verify your phone number in Twilio settings

#### CORS Errors (if using backend)
**Problem**: Network errors in browser console
**Solution**:
The demo version works without backend. For production, you'll need a server to handle Twilio API calls.

## Advanced Configuration

### Custom SMS Templates
You can customize SMS messages in `notification-service.js`:

```javascript
formatAlertMessage(location, changes, currentWeather) {
    // Custom message format
    let message = `🌤️ ${location} Weather Alert\n`;
    message += `📊 ${changes.map(c => `${c.type}: ${c.from}→${c.to}${c.unit}`).join(', ')}\n`;
    message += `🌡️ Now: ${currentWeather.temp}°C, ${currentWeather.condition}`;
    return message;
}
```

### Multiple Recipients
Add multiple phone numbers:

```javascript
async subscribeMultiplePhones(userId, phones) {
    for (const phone of phones) {
        await this.subscribe(userId + '_' + phone, {
            phone: phone,
            method: 'sms',
            locations: ['karur', 'chennai', 'coimbatore'],
            methods: ['sms']
        });
    }
}
```

### Scheduled SMS
Send daily weather summaries:

```javascript
async sendDailySummary(location) {
    const weather = await getCurrentWeather(location);
    const message = `🌅 Daily Weather - ${location}\n`;
    message += `🌡️ ${weather.temp}°C, ${weather.condition}\n`;
    message += `💧 ${weather.humidity}% humidity, 💨 ${weather.wind} km/h`;
    
    await this.sendSMS(subscriber.phone, message);
}
```

## Costs and Limits

### Twilio Pricing (as of 2024)
- **USA**: $0.0079 per SMS
- **India**: ₹0.55 per SMS
- **UK**: £0.045 per SMS
- **Other countries**: Varies

### Example Costs
- 100 SMS/month in USA: ~$0.79
- 100 SMS/month in India: ~₹55
- 1000 SMS/month in USA: ~$7.90

### Free Trial
- $15.50 credit when you sign up
- Enough for ~1,900 SMS messages in USA
- Perfect for testing and moderate use

## Security Best Practices

### Protect Your Credentials
1. **Never expose Auth Token in frontend code**
2. Use environment variables for production
3. Consider using a backend proxy

### Example Backend Setup
```javascript
// server.js (Node.js backend)
app.post('/send-sms', async (req, res) => {
    const { to, message } = req.body;
    
    const twilioClient = require('twilio')(accountSid, authToken);
    
    try {
        await twilioClient.messages.create({
            to: to,
            from: twilioPhoneNumber,
            body: message
        });
        res.json({ success: true });
    } catch (error) {
        res.json({ success: false, error: error.message });
    }
});
```

## Alternative: Use Email to SMS Gateway

If you prefer not to use Twilio, many carriers offer email-to-SMS gateways:

### Major Carriers
- **Airtel**: @airtelmail.com
- **Jio**: @jio.com
- **Vodafone**: @vodafone.net
- **AT&T**: @txt.att.net
- **Verizon**: @vtext.com

### Setup Email to SMS
1. Select "Email Alert" in notification settings
2. Use format: `phonenumber@gateway.com`
3. Example: `919876543210@airtelmail.com`

## Support

### Need Help?
1. **Twilio Support**: https://www.twilio.com/help
2. **Weather App Issues**: Check browser console for errors
3. **Testing**: Use Twilio's SMS testing tools

### Quick Test Commands
```javascript
// Test in browser console
integratedNotifications.notificationService.sendSMS(
    '+919876543210', 
    'Test weather alert from your app!'
);
```

---

**Ready to start!** Once you've configured your Twilio credentials in `notification-service.js`, you'll receive instant SMS weather alerts on your phone!
