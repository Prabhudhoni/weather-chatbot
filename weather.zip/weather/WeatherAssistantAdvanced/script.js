// ===========================
// MAIN APPLICATION SCRIPT
// ===========================

const API_KEY = 'YOUR_OPENWEATHERMAP_API_KEY'; // Replace with your API key
const WEATHER_API = 'https://api.openweathermap.org/data/2.5';

let currentWeather = null;
let currentCity = null;
let currentUser = null;

// Initialize App
document.addEventListener('DOMContentLoaded', () => {
    try {
        initializeApp();
        setupEventListeners();
    } catch (error) {
        console.error('Initialization error:', error);
    }
});

function initializeApp() {
    // Check if user is logged in
    const user = localStorage.getItem('currentUser');
    if (user) {
        currentUser = JSON.parse(user);
        document.getElementById('loginBtn').style.display = 'none';
        document.getElementById('logoutBtn').style.display = 'block';
        
        // Set language
        const lang = currentUser.preferredLanguage || 'en';
        document.getElementById('languageDropdown').value = lang;
        changeLanguage(lang);
        
        // Load weather for preferred city
        if (currentUser.preferredCity) {
            searchWeather(currentUser.preferredCity);
        } else {
            useGPS();
        }
    } else {
        document.getElementById('loginBtn').style.display = 'block';
        document.getElementById('logoutBtn').style.display = 'none';
        changeLanguage('en');
        
        // Auto-load Chennai on first visit
        setTimeout(() => {
            searchWeather('Chennai');
        }, 500);
    }
    
    // Initialize chatbot
    initializeChatbot();
}

function setupEventListeners() {
    // Search functionality
    document.getElementById('searchBtn').addEventListener('click', () => {
        const city = document.getElementById('citySearch').value;
        if (city) searchWeather(city);
    });
    
    document.getElementById('citySearch').addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            const city = document.getElementById('citySearch').value;
            if (city) searchWeather(city);
        }
    });
    
    document.getElementById('gpsBtn').addEventListener('click', useGPS);
    
    // Language dropdown
    document.getElementById('languageDropdown').addEventListener('change', (e) => {
        changeLanguage(e.target.value);
    });
    
    // Logout
    document.getElementById('logoutBtn').addEventListener('click', () => {
        localStorage.removeItem('currentUser');
        currentUser = null;
        window.location.href = 'login.html';
    });
    
    // Chatbot
    document.getElementById('chatbotIcon').addEventListener('click', toggleChatbot);
    document.getElementById('closeChatbot').addEventListener('click', closeChatbot);
    
    // Navigation sections
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const section = item.dataset.section;
            switchSection(section);
        });
    });
}

function switchSection(sectionName) {
    // Hide all sections
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });
    
    // Show selected section
    const section = document.getElementById(sectionName);
    if (section) {
        section.classList.add('active');
    }
    
    // Update nav items
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
        if (item.dataset.section === sectionName) {
            item.classList.add('active');
        }
    });
    
    // Populate forecast section if needed
    if (sectionName === 'forecast' && currentWeather) {
        const forecastContainer = document.getElementById('forecastCardsSection');
        if (forecastContainer && forecastContainer.innerHTML === '') {
            displayForecast(currentWeather.forecast);
        }
    }
    
    // Populate alerts section if needed
    if (sectionName === 'alerts' && currentWeather) {
        const alertsContainer = document.getElementById('alertsContainerSection');
        if (alertsContainer && currentWeather.alerts && currentWeather.alerts.length > 0) {
            alertsContainer.innerHTML = '';
            currentWeather.alerts.forEach(alert => {
                const alertDiv = document.createElement('div');
                alertDiv.className = 'alert-item';
                alertDiv.innerHTML = `
                    <div class="alert-header">
                        <i class="fas fa-exclamation-triangle"></i>
                        <strong>${alert.title}</strong>
                    </div>
                    <p>${alert.description}</p>
                `;
                alertsContainer.appendChild(alertDiv);
            });
        }
    }
    
    // Populate analytics section if needed
    if (sectionName === 'analytics' && currentWeather) {
        setTimeout(() => {
            displayAnalyticsCharts(currentWeather);
        }, 100);
    }
}

function displayAnalyticsCharts(data) {
    try {
        if (typeof Chart === 'undefined') return;
        
        const temps = data.forecast.map(f => f.maxTemp);
        const days = data.forecast.map(f => f.day);
        
        // Temperature
        const tempCanvas = document.getElementById('analyticsTemp');
        if (tempCanvas) {
            new Chart(tempCanvas, {
                type: 'line',
                data: {
                    labels: days,
                    datasets: [{
                        label: 'Temperature (°C)',
                        data: temps,
                        borderColor: '#00d4ff',
                        backgroundColor: 'rgba(0, 212, 255, 0.1)',
                        tension: 0.4,
                        fill: true
                    }]
                },
                options: { responsive: true, maintainAspectRatio: true }
            });
        }
        
        // Humidity
        const humidityCanvas = document.getElementById('analyticsHumidity');
        if (humidityCanvas) {
            new Chart(humidityCanvas, {
                type: 'bar',
                data: {
                    labels: days,
                    datasets: [{
                        label: 'Humidity (%)',
                        data: [data.humidity, data.humidity + 5, data.humidity - 10, data.humidity + 3, data.humidity - 5],
                        backgroundColor: 'rgba(0, 212, 255, 0.5)',
                        borderColor: '#00d4ff'
                    }]
                },
                options: { responsive: true, maintainAspectRatio: true }
            });
        }
        
        // Wind
        const windCanvas = document.getElementById('analyticsWind');
        if (windCanvas) {
            new Chart(windCanvas, {
                type: 'radar',
                data: {
                    labels: days,
                    datasets: [{
                        label: 'Wind Speed (km/h)',
                        data: [12, 15, 10, 18, 14],
                        borderColor: '#00d4ff',
                        backgroundColor: 'rgba(0, 212, 255, 0.2)'
                    }]
                },
                options: { responsive: true, maintainAspectRatio: true }
            });
        }
        
        // Precipitation
        const precipCanvas = document.getElementById('analyticsPrecip');
        if (precipCanvas) {
            new Chart(precipCanvas, {
                type: 'bar',
                data: {
                    labels: days,
                    datasets: [{
                        label: 'Precipitation (mm)',
                        data: [0, 5, 10, 2, 0],
                        backgroundColor: '#0099cc'
                    }]
                },
                options: { responsive: true, maintainAspectRatio: true }
            });
        }
        
        // Pressure
        const pressureCanvas = document.getElementById('analyticsPressure');
        if (pressureCanvas) {
            new Chart(pressureCanvas, {
                type: 'line',
                data: {
                    labels: days,
                    datasets: [{
                        label: 'Pressure (mb)',
                        data: [1013, 1012, 1014, 1015, 1013],
                        borderColor: '#51cf66',
                        backgroundColor: 'rgba(81, 207, 102, 0.1)',
                        tension: 0.4,
                        fill: true
                    }]
                },
                options: { responsive: true, maintainAspectRatio: true }
            });
        }
        
        // Distribution
        const distCanvas = document.getElementById('analyticsDistribution');
        if (distCanvas) {
            new Chart(distCanvas, {
                type: 'doughnut',
                data: {
                    labels: ['Sunny', 'Cloudy', 'Rainy', 'Partly Cloudy'],
                    datasets: [{
                        data: [30, 25, 20, 25],
                        backgroundColor: ['#ffd93d', '#b0b0b0', '#0099cc', '#00d4ff']
                    }]
                },
                options: { responsive: true, maintainAspectRatio: true }
            });
        }
    } catch (error) {
        console.error('Error displaying analytics:', error);
    }
}

// Search Weather
async function searchWeather(city) {
    try {
        // Using mock data for demonstration
        const mockData = getMockWeatherData(city);
        displayWeather(mockData);
        currentCity = city;
        document.getElementById('citySearch').value = '';
    } catch (error) {
        console.error('Error fetching weather:', error);
        alert('City not found. Please try another.');
    }
}

// Get GPS Location
function useGPS() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                const { latitude, longitude } = position.coords;
                fetchWeatherByCoords(latitude, longitude);
            },
            (error) => {
                console.log('GPS denied, using search instead');
                document.getElementById('citySearch').focus();
            }
        );
    }
}

// Fetch Weather by Coordinates
async function fetchWeatherByCoords(lat, lon) {
    try {
        const mockData = getMockWeatherDataByCoords(lat, lon);
        displayWeather(mockData);
    } catch (error) {
        console.error('Error fetching weather:', error);
    }
}

// Display Weather
function displayWeather(data) {
    try {
        currentWeather = data;
        
        // Show dashboard
        document.getElementById('dashboard').style.display = 'block';
        document.getElementById('summarySection').style.display = 'block';
        
        // Update current weather
        document.getElementById('cityName').textContent = data.city;
        document.getElementById('weatherDate').textContent = new Date().toLocaleDateString();
        document.getElementById('temp').textContent = Math.round(data.temp);
        document.getElementById('condition').textContent = data.condition;
        document.getElementById('humidity').textContent = data.humidity + '%';
        document.getElementById('windSpeed').textContent = data.windSpeed + ' km/h';
        document.getElementById('pressure').textContent = data.pressure + ' mb';
        document.getElementById('feelsLike').textContent = Math.round(data.feelsLike) + '°C';
        
        // Update weather icon
        updateWeatherIcon(data.condition);
        
        // Display summary
        displaySummary(data);
        
        // Display forecast
        displayForecast(data.forecast);
        
        // Display charts with delay for Chart.js to load
        setTimeout(() => {
            displayCharts(data);
        }, 100);
        
        // Display alerts
        displayAlerts(data.alerts);
        
        // Update radar
        updateRadar(data.city);
        
        // Scroll to dashboard
        setTimeout(() => {
            document.getElementById('dashboard').scrollIntoView({ behavior: 'smooth' });
        }, 200);
        
        console.log('✅ Weather displayed for:', data.city);
    } catch (error) {
        console.error('Error displaying weather:', error);
    }
}

// Update Weather Icon
function updateWeatherIcon(condition) {
    const iconElement = document.getElementById('weatherIcon');
    const conditionLower = condition.toLowerCase();
    
    if (conditionLower.includes('cloud')) {
        iconElement.className = 'fas fa-cloud';
    } else if (conditionLower.includes('rain')) {
        iconElement.className = 'fas fa-cloud-rain';
    } else if (conditionLower.includes('sun') || conditionLower.includes('clear')) {
        iconElement.className = 'fas fa-sun';
    } else if (conditionLower.includes('snow')) {
        iconElement.className = 'fas fa-snowflake';
    } else if (conditionLower.includes('wind')) {
        iconElement.className = 'fas fa-wind';
    } else {
        iconElement.className = 'fas fa-cloud';
    }
}

// Display Summary
function displaySummary(data) {
    const summary = generateWeatherSummary(data);
    document.getElementById('summaryText').textContent = summary;
}

// Generate Weather Summary
function generateWeatherSummary(data) {
    const temp = data.temp;
    const condition = data.condition;
    const humidity = data.humidity;
    const rainChance = data.rainChance || 0;
    
    let summary = `Today will be ${condition.toLowerCase()} with `;
    
    if (humidity > 70) {
        summary += `high humidity (${humidity}%) `;
    } else if (humidity > 40) {
        summary += `moderate humidity (${humidity}%) `;
    } else {
        summary += `low humidity (${humidity}%) `;
    }
    
    if (rainChance > 50) {
        summary += `and high chances of rain. `;
    } else if (rainChance > 20) {
        summary += `and some chances of rain. `;
    } else {
        summary += `and low chances of rain. `;
    }
    
    if (temp > 35) {
        summary += `It will be very hot, stay hydrated!`;
    } else if (temp > 25) {
        summary += `It will be warm and pleasant.`;
    } else if (temp > 15) {
        summary += `It will be cool and comfortable.`;
    } else {
        summary += `It will be cold, wear warm clothes!`;
    }
    
    return summary;
}

// Display Forecast
function displayForecast(forecast) {
    const container = document.getElementById('forecastCards');
    container.innerHTML = '';
    
    forecast.forEach(day => {
        const card = document.createElement('div');
        card.className = 'forecast-card';
        card.innerHTML = `
            <div class="day">${day.day}</div>
            <div class="icon"><i class="fas fa-cloud"></i></div>
            <div class="temp">
                <span class="temp-high">${Math.round(day.maxTemp)}°</span>
                <span class="temp-low">${Math.round(day.minTemp)}°</span>
            </div>
            <div>${day.condition}</div>
        `;
        container.appendChild(card);
    });
}

// Display Alerts
function displayAlerts(alerts) {
    const container = document.getElementById('alertsContainer');
    const section = document.getElementById('alertsSection');
    
    if (alerts && alerts.length > 0) {
        section.style.display = 'block';
        container.innerHTML = '';
        
        alerts.forEach(alert => {
            const banner = document.createElement('div');
            banner.className = 'alert-banner';
            banner.innerHTML = `
                <i class="fas fa-exclamation-triangle"></i>
                <div>
                    <strong>${alert.title}</strong>
                    <p>${alert.description}</p>
                </div>
            `;
            container.appendChild(banner);
            
            // Send browser notification
            if ('Notification' in window && Notification.permission === 'granted') {
                new Notification('Weather Alert', {
                    body: alert.description,
                    icon: 'https://cdn-icons-png.flaticon.com/512/1779/1779807.png'
                });
            }
        });
    } else {
        section.style.display = 'none';
    }
}

// Change Language
function changeLanguage(lang) {
    const translations = getTranslations(lang);
    
    // Update UI text
    document.getElementById('heroTitle').textContent = translations.heroTitle;
    document.getElementById('heroSubtitle').textContent = translations.heroSubtitle;
    document.getElementById('citySearch').placeholder = translations.searchPlaceholder;
    document.getElementById('chatbotTitle').textContent = translations.chatbotTitle;
    document.getElementById('chatInput').placeholder = translations.chatPlaceholder;
    document.getElementById('forecastTitle').textContent = translations.forecastTitle;
    document.getElementById('chartsTitle').textContent = translations.chartsTitle;
    document.getElementById('radarTitle').textContent = translations.radarTitle;
    document.getElementById('summaryTitle').textContent = translations.summaryTitle;
    
    // Save preference
    if (currentUser) {
        currentUser.preferredLanguage = lang;
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
    }
}

// Mock Weather Data
function getMockWeatherData(city) {
    const weatherData = {
        'Chennai': {
            city: 'Chennai',
            temp: 32,
            condition: 'Partly Cloudy',
            humidity: 75,
            windSpeed: 15,
            pressure: 1013,
            feelsLike: 35,
            rainChance: 30,
            alerts: [],
            forecast: [
                { day: 'Mon', maxTemp: 34, minTemp: 28, condition: 'Sunny' },
                { day: 'Tue', maxTemp: 33, minTemp: 27, condition: 'Cloudy' },
                { day: 'Wed', maxTemp: 30, minTemp: 25, condition: 'Rainy' },
                { day: 'Thu', maxTemp: 31, minTemp: 26, condition: 'Partly Cloudy' },
                { day: 'Fri', maxTemp: 35, minTemp: 29, condition: 'Sunny' }
            ]
        },
        'Mumbai': {
            city: 'Mumbai',
            temp: 28,
            condition: 'Cloudy',
            humidity: 82,
            windSpeed: 18,
            pressure: 1015,
            feelsLike: 30,
            rainChance: 60,
            alerts: [{ title: 'Heavy Rain Warning', description: 'Heavy rainfall expected in next 24 hours' }],
            forecast: [
                { day: 'Mon', maxTemp: 29, minTemp: 24, condition: 'Cloudy' },
                { day: 'Tue', maxTemp: 27, minTemp: 22, condition: 'Rainy' },
                { day: 'Wed', maxTemp: 26, minTemp: 21, condition: 'Rainy' },
                { day: 'Thu', maxTemp: 28, minTemp: 23, condition: 'Cloudy' },
                { day: 'Fri', maxTemp: 30, minTemp: 25, condition: 'Sunny' }
            ]
        },
        'Delhi': {
            city: 'Delhi',
            temp: 12,
            condition: 'Foggy',
            humidity: 88,
            windSpeed: 8,
            pressure: 1020,
            feelsLike: 10,
            rainChance: 10,
            alerts: [{ title: 'Dense Fog Warning', description: 'Dense fog expected, visibility low' }],
            forecast: [
                { day: 'Mon', maxTemp: 14, minTemp: 8, condition: 'Foggy' },
                { day: 'Tue', maxTemp: 13, minTemp: 7, condition: 'Foggy' },
                { day: 'Wed', maxTemp: 16, minTemp: 9, condition: 'Clear' },
                { day: 'Thu', maxTemp: 18, minTemp: 11, condition: 'Sunny' },
                { day: 'Fri', maxTemp: 19, minTemp: 12, condition: 'Sunny' }
            ]
        }
    };
    
    return weatherData[city] || weatherData['Chennai'];
}

function getMockWeatherDataByCoords(lat, lon) {
    // Return Chennai data as default
    return getMockWeatherData('Chennai');
}

// Request Notification Permission
if ('Notification' in window && Notification.permission === 'default') {
    Notification.requestPermission();
}
