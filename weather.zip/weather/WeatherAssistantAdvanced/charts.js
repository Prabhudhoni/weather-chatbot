// ===========================
// CHARTS MODULE
// ===========================

let charts = {};

function displayCharts(data) {
    if (!data || !data.forecast) return;
    
    try {
        const temps = data.forecast.map(f => f.maxTemp);
        const days = data.forecast.map(f => f.day);
        const humidity = [data.humidity, data.humidity + 5, data.humidity - 10, data.humidity + 3, data.humidity - 5];
        const rain = data.forecast.map(() => Math.random() * 100);
        
        // Destroy existing charts
        Object.values(charts).forEach(chart => {
            if (chart) chart.destroy();
        });
        
        // Temperature Chart
        const tempCtx = document.getElementById('temperatureChart');
        if (tempCtx && typeof Chart !== 'undefined') {
            charts.temperature = new Chart(tempCtx, {
                type: 'line',
                data: {
                    labels: days,
                    datasets: [{
                        label: 'Temperature (°C)',
                        data: temps,
                        borderColor: '#00d4ff',
                        backgroundColor: 'rgba(0, 212, 255, 0.1)',
                        tension: 0.4,
                        fill: true
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: true,
                    plugins: { legend: { display: true } }
                }
            });
        }
        
        // Humidity Chart
        const humidityCtx = document.getElementById('humidityChart');
        if (humidityCtx && typeof Chart !== 'undefined') {
            charts.humidity = new Chart(humidityCtx, {
                type: 'bar',
                data: {
                    labels: days,
                    datasets: [{
                        label: 'Humidity (%)',
                        data: humidity,
                        backgroundColor: 'rgba(0, 212, 255, 0.5)',
                        borderColor: '#00d4ff',
                        borderWidth: 2
                    }]
                },
                options: { 
                    responsive: true,
                    maintainAspectRatio: true
                }
            });
        }
        
        // Rain Chart
        const rainCtx = document.getElementById('rainChart');
        if (rainCtx && typeof Chart !== 'undefined') {
            charts.rain = new Chart(rainCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Rain Probability', 'No Rain'],
                    datasets: [{
                        data: [data.rainChance, 100 - data.rainChance],
                        backgroundColor: ['#0099cc', '#2a3142'],
                        borderColor: '#00d4ff'
                    }]
                },
                options: { 
                    responsive: true,
                    maintainAspectRatio: true
                }
            });
        }
    } catch (error) {
        console.error('Error displaying charts:', error);
    }
}
