// ============================================
// WEEK 1: QUICK WINS IMPLEMENTATION
// Dark Mode, Geolocation, Real API, PWA, Push Alerts, 7-Day Forecast
// ============================================

// ============================================
// 1. DARK MODE FEATURE
// ============================================
class DarkModeManager {
    constructor() {
        this.isDarkMode = localStorage.getItem('darkMode') === 'true';
        this.init();
    }

    init() {
        if(this.isDarkMode) {
            this.enable();
        }
    }

    toggle() {
        if(this.isDarkMode) {
            this.disable();
        } else {
            this.enable();
        }
    }

    enable() {
        document.documentElement.style.setProperty('--bg-primary', '#1a1a2e');
        document.documentElement.style.setProperty('--bg-secondary', '#0f0f1e');
        document.documentElement.style.setProperty('--text-primary', '#ffffff');
        document.documentElement.style.setProperty('--text-secondary', '#e0e0e0');
        document.body.classList.add('dark-mode');
        localStorage.setItem('darkMode', 'true');
        this.isDarkMode = true;
    }

    disable() {
        document.documentElement.style.setProperty('--bg-primary', '#ffffff');
        document.documentElement.style.setProperty('--bg-secondary', '#f5f5f5');
        document.documentElement.style.setProperty('--text-primary', '#1a1a2e');
        document.documentElement.style.setProperty('--text-secondary', '#666666');
        document.body.classList.remove('dark-mode');
        localStorage.setItem('darkMode', 'false');
        this.isDarkMode = false;
    }
}

// ============================================
// 2. GEOLOCATION FEATURE
// ============================================
class GeolocationManager {
    constructor() {
        this.currentPosition = null;
    }

    async getLocation() {
        return new Promise((resolve, reject) => {
            if(!navigator.geolocation) {
                reject('Geolocation not supported');
                return;
            }

            navigator.geolocation.getCurrentPosition(
                (position) => {
                    this.currentPosition = {
                        latitude: position.coords.latitude,
                        longitude: position.coords.longitude
                    };
                    resolve(this.currentPosition);
                },
                (error) => {
                    reject(error.message);
                }
            );
        });
    }

    async getLocationName(lat, lon) {
        try {
            const response = await fetch(
                `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}`
            );
            const data = await response.json();
            return data.address.city || data.address.town || data.address.county || 'Unknown';
        } catch(error) {
            console.error('Error getting location name:', error);
            return 'Unknown Location';
        }
    }
}

// ============================================
// 3. REAL WEATHER API FEATURE
// ============================================
class WeatherAPIManager {
    constructor(apiKey = 'demo') {
        this.apiKey = apiKey;
        this.baseUrl = 'https://api.openweathermap.org/data/2.5';
        this.forecastUrl = 'https://api.openweathermap.org/data/2.5/forecast';
    }

    async getCurrentWeather(city) {
        try {
            const response = await fetch(
                `${this.baseUrl}/weather?q=${city}&appid=${this.apiKey}&units=metric`
            );
            if(!response.ok) throw new Error('City not found');
            const data = await response.json();
            return {
                city: data.name,
                state: data.sys.country,
                temp: Math.round(data.main.temp),
                feelsLike: Math.round(data.main.feels_like),
                condition: data.weather[0].main,
                description: data.weather[0].description,
                humidity: data.main.humidity,
                pressure: data.main.pressure,
                wind: Math.round(data.wind.speed),
                cloudiness: data.clouds.all,
                icon: data.weather[0].icon
            };
        } catch(error) {
            console.error('Weather API error:', error);
            return null;
        }
    }

    async getWeatherByCoords(lat, lon) {
        try {
            const response = await fetch(
                `${this.baseUrl}/weather?lat=${lat}&lon=${lon}&appid=${this.apiKey}&units=metric`
            );
            const data = await response.json();
            return {
                city: data.name,
                state: data.sys.country,
                temp: Math.round(data.main.temp),
                feelsLike: Math.round(data.main.feels_like),
                condition: data.weather[0].main,
                description: data.weather[0].description,
                humidity: data.main.humidity,
                pressure: data.main.pressure,
                wind: Math.round(data.wind.speed),
                cloudiness: data.clouds.all,
                icon: data.weather[0].icon
            };
        } catch(error) {
            console.error('Weather API error:', error);
            return null;
        }
    }

    async get7DayForecast(city) {
        try {
            const response = await fetch(
                `${this.forecastUrl}?q=${city}&appid=${this.apiKey}&units=metric`
            );
            if(!response.ok) throw new Error('Forecast not available');
            const data = await response.json();
            
            const forecasts = {};
            data.list.forEach(item => {
                const date = new Date(item.dt * 1000).toISOString().split('T')[0];
                if(!forecasts[date]) {
                    forecasts[date] = {
                        date: date,
                        temp: Math.round(item.main.temp),
                        tempMax: Math.round(item.main.temp_max),
                        tempMin: Math.round(item.main.temp_min),
                        condition: item.weather[0].main,
                        humidity: item.main.humidity,
                        windSpeed: Math.round(item.wind.speed),
                        rainChance: item.pop * 100,
                        icon: item.weather[0].icon
                    };
                }
            });

            return Object.values(forecasts).slice(0, 7);
        } catch(error) {
            console.error('Forecast API error:', error);
            return [];
        }
    }
}

// ============================================
// 4. PWA SETUP (Service Worker Registration)
// ============================================
class PWAManager {
    constructor() {
        this.serviceWorkerPath = 'service-worker.js';
    }

    async register() {
        if(!('serviceWorker' in navigator)) {
            console.log('Service Workers not supported');
            return;
        }

        try {
            const registration = await navigator.serviceWorker.register(this.serviceWorkerPath);
            console.log('Service Worker registered:', registration);
            return registration;
        } catch(error) {
            console.error('Service Worker registration failed:', error);
        }
    }

    async unregister() {
        if(!('serviceWorker' in navigator)) return;

        try {
            const registrations = await navigator.serviceWorker.getRegistrations();
            for(let registration of registrations) {
                await registration.unregister();
            }
            console.log('Service Workers unregistered');
        } catch(error) {
            console.error('Error unregistering:', error);
        }
    }

    isInstallable() {
        return window.matchMedia('(display-mode: standalone)').matches ||
               window.navigator.standalone === true;
    }
}

// ============================================
// 5. PUSH NOTIFICATIONS FEATURE
// ============================================
class NotificationManager {
    constructor() {
        this.permission = Notification.permission;
    }

    async requestPermission() {
        if(!('Notification' in window)) {
            console.log('Notifications not supported');
            return false;
        }

        if(this.permission === 'granted') {
            return true;
        }

        if(this.permission !== 'denied') {
            const permission = await Notification.requestPermission();
            this.permission = permission;
            return permission === 'granted';
        }

        return false;
    }

    sendNotification(title, options = {}) {
        if(this.permission !== 'granted') {
            console.log('Notification permission not granted');
            return;
        }

        const defaultOptions = {
            icon: 'https://cdn-icons-png.flaticon.com/512/3050/3050159.png',
            badge: 'https://cdn-icons-png.flaticon.com/512/3050/3050159.png',
            tag: 'weather-notification',
            requireInteraction: false,
            ...options
        };

        new Notification(title, defaultOptions);
    }

    sendWeatherAlert(weather) {
        const alerts = {
            'Thunderstorm': { title: '⚡ Severe Thunderstorm Alert', body: 'Heavy thunderstorm approaching!' },
            'Tornado': { title: '🌪️ Tornado Warning', body: 'Seek shelter immediately!' },
            'Extreme': { title: '🔴 Extreme Weather Alert', body: 'Dangerous conditions ahead!' },
            'Rain': { title: '🌧️ Heavy Rain Alert', body: 'Expect heavy rainfall' },
            'Snow': { title: '❄️ Heavy Snow Alert', body: 'Significant snowfall expected' },
            'Wind': { title: '💨 High Wind Alert', body: 'Strong winds approaching' },
            'Fog': { title: '🌫️ Dense Fog Alert', body: 'Visibility reduced significantly' },
            'Heat': { title: '🔥 Heat Wave Alert', body: 'Extreme heat warning' },
            'Cold': { title: '❄️ Cold Wave Alert', body: 'Extreme cold warning' }
        };

        for(let condition in alerts) {
            if(weather.condition.includes(condition)) {
                this.sendNotification(alerts[condition].title, {
                    body: alerts[condition].body
                });
                break;
            }
        }
    }
}

// ============================================
// 6. 7-DAY FORECAST FEATURE
// ============================================
class ForecastManager {
    constructor() {
        this.forecasts = [];
    }

    setForecasts(data) {
        this.forecasts = data;
    }

    getForecasts() {
        return this.forecasts;
    }

    renderForecastCards(containerId) {
        const container = document.getElementById(containerId);
        if(!container) return;

        container.innerHTML = '';

        this.forecasts.forEach(forecast => {
            const card = document.createElement('div');
            card.className = 'forecast-card';
            card.innerHTML = `
                <div style="text-align:center;padding:1rem;background:white;border-radius:0.75rem;box-shadow:0 2px 8px rgba(0,0,0,0.1)">
                    <div style="font-weight:bold;margin-bottom:0.5rem">${new Date(forecast.date).toLocaleDateString('en-US', {weekday: 'short', month: 'short', day: 'numeric'})}</div>
                    <div style="font-size:2rem;margin:0.5rem 0">🌤️</div>
                    <div style="font-size:1.5rem;color:#0066cc;font-weight:bold">${forecast.tempMax}°</div>
                    <div style="font-size:0.9rem;color:#666">${forecast.tempMin}°</div>
                    <div style="font-size:0.85rem;margin-top:0.5rem">${forecast.condition}</div>
                    <div style="font-size:0.8rem;color:#999;margin-top:0.25rem">💧 ${forecast.humidity}%</div>
                    <div style="font-size:0.8rem;color:#999">💨 ${forecast.windSpeed} km/h</div>
                    <div style="font-size:0.8rem;color:#999">🌧️ ${Math.round(forecast.rainChance)}%</div>
                </div>
            `;
            container.appendChild(card);
        });
    }

    renderForecastTable(containerId) {
        const container = document.getElementById(containerId);
        if(!container) return;

        let html = `
            <table style="width:100%;border-collapse:collapse;margin-top:1rem">
                <thead>
                    <tr style="background:#0066cc;color:white">
                        <th style="padding:0.75rem;text-align:left">Date</th>
                        <th style="padding:0.75rem;text-align:center">Max Temp</th>
                        <th style="padding:0.75rem;text-align:center">Min Temp</th>
                        <th style="padding:0.75rem;text-align:left">Condition</th>
                        <th style="padding:0.75rem;text-align:center">Humidity</th>
                        <th style="padding:0.75rem;text-align:center">Wind</th>
                        <th style="padding:0.75rem;text-align:center">Rain %</th>
                    </tr>
                </thead>
                <tbody>
        `;

        this.forecasts.forEach(forecast => {
            html += `
                <tr style="border-bottom:1px solid #ddd">
                    <td style="padding:0.75rem">${new Date(forecast.date).toLocaleDateString()}</td>
                    <td style="padding:0.75rem;text-align:center;color:#f44336;font-weight:bold">${forecast.tempMax}°C</td>
                    <td style="padding:0.75rem;text-align:center;color:#2196f3;font-weight:bold">${forecast.tempMin}°C</td>
                    <td style="padding:0.75rem">${forecast.condition}</td>
                    <td style="padding:0.75rem;text-align:center">${forecast.humidity}%</td>
                    <td style="padding:0.75rem;text-align:center">${forecast.windSpeed} km/h</td>
                    <td style="padding:0.75rem;text-align:center">${Math.round(forecast.rainChance)}%</td>
                </tr>
            `;
        });

        html += `
                </tbody>
            </table>
        `;

        container.innerHTML = html;
    }
}

// ============================================
// INITIALIZATION
// ============================================
const darkMode = new DarkModeManager();
const geolocation = new GeolocationManager();
const weatherAPI = new WeatherAPIManager('demo'); // Replace 'demo' with real API key
const pwa = new PWAManager();
const notifications = new NotificationManager();
const forecast = new ForecastManager();

// Initialize on page load
document.addEventListener('DOMContentLoaded', async () => {
    // Register PWA
    await pwa.register();

    // Request notification permission
    await notifications.requestPermission();

    console.log('Week 1 features initialized!');
});

// Export for use in HTML
window.darkMode = darkMode;
window.geolocation = geolocation;
window.weatherAPI = weatherAPI;
window.pwa = pwa;
window.notifications = notifications;
window.forecast = forecast;
