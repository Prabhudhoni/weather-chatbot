// Integrated Weather Notifications - Works with main weather app
// This script integrates notification system with existing weather application

class IntegratedWeatherNotifications {
    constructor() {
        this.notificationService = new WeatherNotificationService();
        this.isMonitoring = false;
        this.monitoringInterval = null;
        this.currentLocation = null;
        this.subscribers = new Map();
        this.weatherData = {};
        
        // Load existing weather data
        this.loadWeatherData();
        
        // Initialize notification service
        this.notificationService.loadSubscribers();
        
        // Set up event listeners
        this.setupEventListeners();
    }

    // Load weather data from the main app's dataset
    async loadWeatherData() {
        try {
            // Try to fetch from the same directory
            const response = await fetch('./weather-data.json');
            if (response.ok) {
                const data = await response.json();
                this.weatherData = data.locations;
                console.log('Weather data loaded:', Object.keys(this.weatherData));
            }
        } catch (error) {
            console.log('Using fallback weather data');
            // Use fallback data if file not found
            this.weatherData = {
                "karur": { temp: 31, condition: "Partly Cloudy", humidity: 71, wind: 15, pressure: 1013 },
                "coimbatore": { temp: 29, condition: "Sunny", humidity: 65, wind: 12, pressure: 1015 },
                "chennai": { temp: 32, condition: "Humid", humidity: 80, wind: 18, pressure: 1010 },
                "delhi": { temp: 28, condition: "Clear", humidity: 45, wind: 8, pressure: 1018 },
                "mumbai": { temp: 30, condition: "Cloudy", humidity: 75, wind: 20, pressure: 1008 }
            };
        }
    }

    // Setup event listeners for integration with main app
    setupEventListeners() {
        // Listen for weather updates from main app
        window.addEventListener('weatherUpdate', (event) => {
            this.handleWeatherUpdate(event.detail);
        });

        // Listen for location changes
        window.addEventListener('locationChange', (event) => {
            this.handleLocationChange(event.detail);
        });

        // Add notification controls to main app
        this.addNotificationControls();
    }

    // Handle weather updates from main app
    handleWeatherUpdate(weatherData) {
        if (!this.isMonitoring || !this.currentLocation) return;

        const location = this.currentLocation.toLowerCase();
        const currentWeather = {
            temp: weatherData.temperature,
            condition: weatherData.condition,
            humidity: weatherData.humidity,
            wind: weatherData.windSpeed,
            pressure: weatherData.pressure
        };

        // Check for changes and send notifications
        this.notificationService.checkWeatherChanges(location, currentWeather);
    }

    // Handle location changes
    handleLocationChange(locationData) {
        this.currentLocation = locationData.city;
        console.log(`Monitoring location changed to: ${this.currentLocation}`);
        
        // Update monitoring if active
        if (this.isMonitoring) {
            this.restartMonitoring();
        }
    }

    // Add notification controls to main app UI
    addNotificationControls() {
        // Wait for DOM to be ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.createNotificationUI());
        } else {
            this.createNotificationUI();
        }
    }

    // Create notification UI in main app
    createNotificationUI() {
        // Find a suitable place to add notification controls
        const navbar = document.querySelector('.navbar');
        const settingsSection = document.querySelector('.settings-section');
        
        if (settingsSection) {
            // Add to settings section
            const notificationSettings = this.createNotificationSettingsHTML();
            settingsSection.insertAdjacentHTML('beforeend', notificationSettings);
        } else if (navbar) {
            // Add floating notification button
            const floatingButton = this.createFloatingNotificationButton();
            document.body.appendChild(floatingButton);
        }

        // Add notification status indicator
        this.addStatusIndicator();
    }

    // Create notification settings HTML
    createNotificationSettingsHTML() {
        return `
            <div class="notification-settings" style="margin-top: 2rem; padding: 1.5rem; background: var(--surface); border-radius: 1rem; border: 2px solid var(--neon-blue);">
                <h3 style="color: var(--neon-cyan); margin-bottom: 1rem;">
                    <i class="fas fa-bell"></i> Phone Notifications
                </h3>
                
                <div class="notification-status" id="notificationStatus">
                    <span class="status-badge status-inactive">
                        <i class="fas fa-circle"></i> Notifications Disabled
                    </span>
                </div>
                
                <div class="notification-controls" style="margin-top: 1rem;">
                    <div style="margin-bottom: 1rem;">
                        <label style="display: block; color: var(--text-secondary); margin-bottom: 0.5rem;">Phone Number</label>
                        <input type="tel" id="notificationPhone" placeholder="+1234567890" 
                               style="width: 100%; padding: 0.5rem; background: var(--background); border: 1px solid var(--border); border-radius: 0.5rem; color: var(--text);">
                    </div>
                    
                    <div style="margin-bottom: 1rem;">
                        <label style="display: block; color: var(--text-secondary); margin-bottom: 0.5rem;">Notification Method</label>
                        <select id="notificationMethod" style="width: 100%; padding: 0.5rem; background: var(--background); border: 1px solid var(--border); border-radius: 0.5rem; color: var(--text);">
                            <option value="push">Browser Push</option>
                            <option value="sms">SMS</option>
                            <option value="whatsapp">WhatsApp</option>
                            <option value="email">Email</option>
                        </select>
                    </div>
                    
                    <div style="margin-bottom: 1rem;">
                        <label style="display: block; color: var(--text-secondary); margin-bottom: 0.5rem;">Check Interval</label>
                        <select id="checkInterval" style="width: 100%; padding: 0.5rem; background: var(--background); border: 1px solid var(--border); border-radius: 0.5rem; color: var(--text);">
                            <option value="1">Every 1 minute</option>
                            <option value="5">Every 5 minutes</option>
                            <option value="15">Every 15 minutes</option>
                            <option value="30">Every 30 minutes</option>
                        </select>
                    </div>
                    
                    <div style="display: flex; gap: 1rem;">
                        <button onclick="integratedNotifications.setupNotifications()" 
                                style="flex: 1; padding: 0.75rem; background: linear-gradient(135deg, var(--neon-blue), var(--neon-cyan)); border: none; border-radius: 0.5rem; color: var(--background); font-weight: 600; cursor: pointer;">
                            <i class="fas fa-cog"></i> Setup
                        </button>
                        <button onclick="integratedNotifications.toggleMonitoring()" 
                                style="flex: 1; padding: 0.75rem; background: linear-gradient(135deg, var(--success), #00cc66); border: none; border-radius: 0.5rem; color: var(--background); font-weight: 600; cursor: pointer;">
                            <i class="fas fa-play"></i> Start
                        </button>
                    </div>
                </div>
                
                <div class="notification-log" style="margin-top: 1rem; max-height: 200px; overflow-y: auto;">
                    <div style="padding: 0.5rem; background: var(--surface-light); border-radius: 0.5rem; margin-bottom: 0.5rem;">
                        <small style="color: var(--text-secondary);">System ready for notifications</small>
                    </div>
                </div>
            </div>
        `;
    }

    // Create floating notification button
    createFloatingNotificationButton() {
        const button = document.createElement('div');
        button.id = 'notificationButton';
        button.innerHTML = `
            <div style="position: fixed; bottom: 2rem; right: 2rem; z-index: 1000;">
                <button onclick="integratedNotifications.showNotificationPanel()" 
                        style="width: 60px; height: 60px; border-radius: 50%; background: linear-gradient(135deg, var(--neon-blue), var(--neon-cyan)); border: none; color: var(--background); font-size: 1.5rem; cursor: pointer; box-shadow: 0 8px 25px rgba(0, 102, 255, 0.4); position: relative;">
                    <i class="fas fa-bell"></i>
                    <span id="notificationIndicator" style="position: absolute; top: 0; right: 0; width: 20px; height: 20px; background: var(--danger); border-radius: 50%; display: none;"></span>
                </button>
            </div>
        `;
        return button;
    }

    // Add status indicator to main app
    addStatusIndicator() {
        const statusDiv = document.createElement('div');
        statusDiv.id = 'notificationStatusIndicator';
        statusDiv.style.cssText = `
            position: fixed;
            top: 1rem;
            right: 1rem;
            z-index: 999;
            padding: 0.5rem 1rem;
            background: var(--surface);
            border: 1px solid var(--neon-blue);
            border-radius: 2rem;
            font-size: 0.9rem;
            color: var(--text-secondary);
        `;
        statusDiv.innerHTML = '<i class="fas fa-bell-slash"></i> Notifications Off';
        document.body.appendChild(statusDiv);
    }

    // Setup notifications
    async setupNotifications() {
        const phone = document.getElementById('notificationPhone')?.value;
        const method = document.getElementById('notificationMethod')?.value;
        
        if (!phone && method !== 'push') {
            this.showAlert('Please enter your phone number', 'warning');
            return;
        }

        // Create user subscription
        const userId = 'user_' + Date.now();
        const preferences = {
            phone: phone,
            method: method,
            locations: [this.getCurrentLocation()],
            methods: [method],
            thresholds: {
                temperature: 5,
                humidity: 10,
                wind: 15,
                pressure: 10
            }
        };

        await this.notificationService.subscribe(userId, preferences);
        this.subscribers.set(userId, preferences);

        // Update UI
        this.updateNotificationStatus(true);
        this.showAlert('Notifications setup complete!', 'success');
        
        // Send test notification
        this.sendTestNotification();
    }

    // Toggle monitoring
    toggleMonitoring() {
        if (this.isMonitoring) {
            this.stopMonitoring();
        } else {
            this.startMonitoring();
        }
    }

    // Start weather monitoring
    startMonitoring() {
        const interval = parseInt(document.getElementById('checkInterval')?.value || 5);
        
        if (this.monitoringInterval) {
            clearInterval(this.monitoringInterval);
        }

        this.isMonitoring = true;
        this.monitoringInterval = setInterval(() => {
            this.checkWeatherChanges();
        }, interval * 60 * 1000);

        // Check immediately
        this.checkWeatherChanges();

        // Update UI
        this.updateMonitoringStatus(true);
        this.showAlert(`Started monitoring every ${interval} minutes`, 'success');
    }

    // Stop monitoring
    stopMonitoring() {
        if (this.monitoringInterval) {
            clearInterval(this.monitoringInterval);
            this.monitoringInterval = null;
        }

        this.isMonitoring = false;
        this.updateMonitoringStatus(false);
        this.showAlert('Monitoring stopped', 'info');
    }

    // Restart monitoring with new settings
    restartMonitoring() {
        if (this.isMonitoring) {
            this.stopMonitoring();
            this.startMonitoring();
        }
    }

    // Check weather changes
    async checkWeatherChanges() {
        const location = this.getCurrentLocation();
        if (!location || !this.weatherData[location]) return;

        // Simulate weather changes (in real app, this would fetch actual data)
        const currentWeather = this.simulateWeatherChange(location);
        
        // Check for changes and send notifications
        const changes = await this.notificationService.checkWeatherChanges(location, currentWeather);
        
        if (changes.length > 0) {
            this.showNotificationIndicator();
            this.logNotification(`Weather changes detected: ${changes.length} alerts sent`);
        }
    }

    // Simulate weather changes for testing
    simulateWeatherChange(location) {
        const base = this.weatherData[location];
        const variation = {
            temp: Math.random() * 10 - 5,
            humidity: Math.random() * 20 - 10,
            wind: Math.random() * 10 - 5,
            pressure: Math.random() * 10 - 5
        };

        return {
            temp: base.temp + variation.temp,
            condition: base.condition,
            humidity: base.humidity + variation.humidity,
            wind: base.wind + variation.wind,
            pressure: base.pressure + variation.pressure
        };
    }

    // Get current location from main app
    getCurrentLocation() {
        // Try to get from main app's current location
        const locationElement = document.querySelector('.location-display, .city-name, .current-location');
        if (locationElement) {
            return locationElement.textContent.toLowerCase().trim();
        }
        
        // Fallback to first available location
        return Object.keys(this.weatherData)[0];
    }

    // Send test notification
    sendTestNotification() {
        const message = "Weather notifications are now active! You'll receive alerts for weather changes.";
        
        // Show browser notification
        if (Notification.permission === "granted") {
            new Notification("Weather Alert Test", {
                body: message,
                icon: "https://cdn-icons-png.flaticon.com/512/1146/1146869.png"
            });
        }
        
        this.logNotification("Test notification sent");
    }

    // Update notification status in UI
    updateNotificationStatus(enabled) {
        const statusElement = document.getElementById('notificationStatus')?.querySelector('.status-badge');
        if (statusElement) {
            if (enabled) {
                statusElement.className = 'status-badge status-active';
                statusElement.innerHTML = '<i class="fas fa-check-circle"></i> Notifications Active';
            } else {
                statusElement.className = 'status-badge status-inactive';
                statusElement.innerHTML = '<i class="fas fa-circle"></i> Notifications Disabled';
            }
        }

        // Update status indicator
        const indicator = document.getElementById('notificationStatusIndicator');
        if (indicator) {
            if (enabled) {
                indicator.innerHTML = '<i class="fas fa-bell"></i> Notifications Active';
                indicator.style.borderColor = 'var(--success)';
            } else {
                indicator.innerHTML = '<i class="fas fa-bell-slash"></i> Notifications Off';
                indicator.style.borderColor = 'var(--neon-blue)';
            }
        }
    }

    // Update monitoring status in UI
    updateMonitoringStatus(active) {
        const button = document.querySelector('button[onclick*="toggleMonitoring"]');
        if (button) {
            if (active) {
                button.innerHTML = '<i class="fas fa-stop"></i> Stop';
                button.style.background = 'linear-gradient(135deg, var(--danger), #cc0033)';
            } else {
                button.innerHTML = '<i class="fas fa-play"></i> Start';
                button.style.background = 'linear-gradient(135deg, var(--success), #00cc66)';
            }
        }
    }

    // Show notification indicator
    showNotificationIndicator() {
        const indicator = document.getElementById('notificationIndicator');
        if (indicator) {
            indicator.style.display = 'block';
            setTimeout(() => {
                indicator.style.display = 'none';
            }, 5000);
        }
    }

    // Log notification
    logNotification(message) {
        const logElement = document.querySelector('.notification-log');
        if (logElement) {
            const logEntry = document.createElement('div');
            logEntry.style.cssText = 'padding: 0.5rem; background: var(--surface-light); border-radius: 0.5rem; margin-bottom: 0.5rem;';
            logEntry.innerHTML = `
                <small style="color: var(--text-secondary);">${new Date().toLocaleTimeString()}</small><br>
                <small style="color: var(--text);">${message}</small>
            `;
            logElement.insertBefore(logEntry, logElement.firstChild);
            
            // Keep only last 10 entries
            while (logElement.children.length > 10) {
                logElement.removeChild(logElement.lastChild);
            }
        }
    }

    // Show alert message
    showAlert(message, type = 'info') {
        // Create alert element
        const alert = document.createElement('div');
        alert.style.cssText = `
            position: fixed;
            top: 2rem;
            left: 50%;
            transform: translateX(-50%);
            z-index: 10000;
            padding: 1rem 2rem;
            border-radius: 0.5rem;
            color: white;
            font-weight: 600;
            animation: slideDown 0.3s ease;
        `;
        
        // Set color based on type
        const colors = {
            success: 'linear-gradient(135deg, var(--success), #00cc66)',
            warning: 'linear-gradient(135deg, var(--warning), #ff8800)',
            danger: 'linear-gradient(135deg, var(--danger), #cc0033)',
            info: 'linear-gradient(135deg, var(--neon-blue), var(--neon-cyan))'
        };
        
        alert.style.background = colors[type] || colors.info;
        alert.textContent = message;
        
        document.body.appendChild(alert);
        
        // Remove after 3 seconds
        setTimeout(() => {
            alert.remove();
        }, 3000);
    }

    // Show notification panel (for floating button)
    showNotificationPanel() {
        // Create modal panel
        const panel = document.createElement('div');
        panel.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 10000;
            background: var(--surface);
            border: 2px solid var(--neon-blue);
            border-radius: 1rem;
            padding: 2rem;
            min-width: 400px;
            max-width: 90vw;
            max-height: 80vh;
            overflow-y: auto;
        `;
        
        panel.innerHTML = `
            <h3 style="color: var(--neon-cyan); margin-bottom: 1.5rem;">
                <i class="fas fa-bell"></i> Weather Notifications
            </h3>
            
            <div style="margin-bottom: 1rem;">
                <label style="display: block; color: var(--text-secondary); margin-bottom: 0.5rem;">Phone Number</label>
                <input type="tel" id="modalPhone" placeholder="+1234567890" 
                       style="width: 100%; padding: 0.5rem; background: var(--background); border: 1px solid var(--border); border-radius: 0.5rem; color: var(--text);">
            </div>
            
            <div style="margin-bottom: 1rem;">
                <label style="display: block; color: var(--text-secondary); margin-bottom: 0.5rem;">Method</label>
                <select id="modalMethod" style="width: 100%; padding: 0.5rem; background: var(--background); border: 1px solid var(--border); border-radius: 0.5rem; color: var(--text);">
                    <option value="push">Browser Push</option>
                    <option value="sms">SMS</option>
                    <option value="whatsapp">WhatsApp</option>
                    <option value="email">Email</option>
                </select>
            </div>
            
            <div style="display: flex; gap: 1rem; margin-top: 1.5rem;">
                <button onclick="integratedNotifications.setupFromModal(); this.closest('div').parentElement.remove();" 
                        style="flex: 1; padding: 0.75rem; background: linear-gradient(135deg, var(--neon-blue), var(--neon-cyan)); border: none; border-radius: 0.5rem; color: var(--background); font-weight: 600; cursor: pointer;">
                    Setup
                </button>
                <button onclick="this.closest('div').parentElement.remove()" 
                        style="flex: 1; padding: 0.75rem; background: var(--surface-light); border: 1px solid var(--border); border-radius: 0.5rem; color: var(--text); font-weight: 600; cursor: pointer;">
                    Cancel
                </button>
            </div>
        `;
        
        // Add backdrop
        const backdrop = document.createElement('div');
        backdrop.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            z-index: 9999;
        `;
        backdrop.onclick = () => {
            panel.remove();
            backdrop.remove();
        };
        
        document.body.appendChild(backdrop);
        document.body.appendChild(panel);
    }

    // Setup from modal
    setupFromModal() {
        const phone = document.getElementById('modalPhone')?.value;
        const method = document.getElementById('modalMethod')?.value;
        
        // Copy to main form if it exists
        const phoneInput = document.getElementById('notificationPhone');
        const methodSelect = document.getElementById('notificationMethod');
        
        if (phoneInput) phoneInput.value = phone;
        if (methodSelect) methodSelect.value = method;
        
        // Setup notifications
        this.setupNotifications();
    }
}

// Initialize the integrated notifications system
let integratedNotifications;

// Auto-initialize when page loads
window.addEventListener('load', () => {
    integratedNotifications = new IntegratedWeatherNotifications();
    console.log('Integrated Weather Notifications initialized');
});

// Make it globally available
window.integratedNotifications = integratedNotifications;
