# 🔧 Fix: "Failed to fetch" Error

## Problem

You're seeing this error:
```
Error loading dataset: TypeError: Failed to fetch
```

## Root Cause

The application is being opened using the `file://` protocol (double-clicking `index.html`), which has CORS (Cross-Origin Resource Sharing) restrictions that prevent fetching local JSON files.

## Solution

You need to run the application through a **local web server** instead of opening it directly as a file.

---

## ✅ Quick Fix (Choose One)

### Option 1: Use Batch File (Windows - Easiest)

1. **Find the file**: `START_SERVER.bat` in your project folder
2. **Double-click it**: The server will start automatically
3. **Open browser**: Go to `http://localhost:8000`
4. **Done!** Application loads with all data

### Option 2: Use PowerShell Script (Windows)

1. **Right-click** `START_SERVER.ps1`
2. **Select**: "Run with PowerShell"
3. **If prompted**: Click "Run anyway"
4. **Open browser**: Go to `http://localhost:8000`
5. **Done!** Application loads with all data

### Option 3: Manual Python Server (Windows/Mac/Linux)

1. **Open Terminal/Command Prompt**
2. **Navigate to project folder**:
   ```bash
   cd "C:\Users\prabh\OneDrive\Desktop\weather"
   ```
3. **Start server**:
   ```bash
   python -m http.server 8000
   ```
4. **Open browser**: Go to `http://localhost:8000`
5. **Done!** Application loads with all data

### Option 4: Use Node.js (If Installed)

1. **Open Terminal/Command Prompt**
2. **Navigate to project folder**
3. **Install http-server** (one-time):
   ```bash
   npm install -g http-server
   ```
4. **Start server**:
   ```bash
   http-server
   ```
5. **Open browser**: Go to `http://localhost:8080`
6. **Done!** Application loads with all data

---

## 📋 Step-by-Step Guide (Windows)

### Method 1: Batch File (Recommended)

**Step 1**: Find `START_SERVER.bat`
- Location: `C:\Users\prabh\OneDrive\Desktop\weather\START_SERVER.bat`

**Step 2**: Double-click the file
- A command window opens
- You see: "Starting local web server..."

**Step 3**: Open browser
- Go to: `http://localhost:8000`
- Application loads successfully

**Step 4**: Use the application
- View weather data
- Search cities
- Use chatbot
- Everything works!

**Step 5**: Stop server
- Press `Ctrl+C` in the command window
- Or close the command window

### Method 2: Command Prompt

**Step 1**: Open Command Prompt
- Press: `Win + R`
- Type: `cmd`
- Press: `Enter`

**Step 2**: Navigate to folder
```bash
cd C:\Users\prabh\OneDrive\Desktop\weather
```

**Step 3**: Start server
```bash
python -m http.server 8000
```

**Step 4**: Open browser
- Go to: `http://localhost:8000`

**Step 5**: Done!
- Application loads with all data

---

## 🔍 Verify It's Working

### Check in Browser Console

1. **Open browser**: `http://localhost:8000`
2. **Press**: `F12` (Developer Tools)
3. **Click**: "Console" tab
4. **Look for**: `"Successfully loaded villages dataset with 15 cities"`
5. **If you see this**: ✅ Everything is working!

### What You Should See

✅ Weather cards displayed  
✅ All cities visible  
✅ Search bar working  
✅ Chatbot icon visible  
✅ No red error messages  

### What NOT to See

❌ "Failed to fetch" error  
❌ Blank weather section  
❌ No cities displayed  
❌ Error in console  

---

## 🆘 Troubleshooting

### Issue: "Python is not recognized"

**Solution**:
1. Install Python from: https://www.python.org/downloads/
2. **Important**: Check "Add Python to PATH" during installation
3. Restart Command Prompt
4. Try again

### Issue: "Port 8000 already in use"

**Solution**:
1. Use a different port:
   ```bash
   python -m http.server 8001
   ```
2. Go to: `http://localhost:8001`

### Issue: Browser shows "Connection refused"

**Solution**:
1. Make sure server is running (check command window)
2. Make sure you're using `http://` not `https://`
3. Check the port number matches (8000 by default)
4. Try: `http://127.0.0.1:8000`

### Issue: Still getting "Failed to fetch"

**Solution**:
1. Stop the server (Ctrl+C)
2. Verify all dataset files exist:
   - `dataset-villages.json`
   - `dataset-expanded.json`
   - `dataset.json`
3. Restart server
4. Refresh browser (Ctrl+R)

---

## 📝 Important Notes

### Never Use `file://` Protocol
❌ **Wrong**: Double-click `index.html` (opens as `file:///...`)  
✅ **Right**: Use `http://localhost:8000`

### Why This Matters
- Browser security prevents loading local files via `file://`
- Web server (`http://`) bypasses this restriction
- This is standard web development practice

### Server Keeps Running
- Server runs until you stop it
- You can keep browser open and refresh
- Multiple browser tabs can access it
- Just don't close the command window

---

## 🎯 Quick Reference

| Task | Command |
|------|---------|
| Start server | `python -m http.server 8000` |
| Open app | `http://localhost:8000` |
| Stop server | `Ctrl+C` |
| Check logs | Look at command window |
| Different port | `python -m http.server 8001` |

---

## ✅ Verification Checklist

- [ ] Server is running (command window open)
- [ ] Browser shows `http://localhost:8000`
- [ ] Weather cards are visible
- [ ] No red error messages
- [ ] Console shows "Successfully loaded" message
- [ ] Search bar works
- [ ] Chatbot icon visible
- [ ] All features working

---

## 🎉 Success!

Once you see the weather data loading:
- ✅ Error is fixed
- ✅ Application is working
- ✅ All features available
- ✅ Ready to use!

---

## 📞 Still Having Issues?

1. **Check Python**: `python --version`
2. **Check files exist**: All `.json` files in folder
3. **Check port**: Make sure 8000 is free
4. **Check URL**: Use `http://` not `https://` or `file://`
5. **Refresh browser**: `Ctrl+R` or `Cmd+R`
6. **Clear cache**: `Ctrl+Shift+Delete`

---

**The application works perfectly once served through HTTP!** 🌤️
