# 🌤️ Weather Info Assistant

A modern, responsive web-based weather application with real-time weather data, 5-day forecasts, weather alerts, and an AI-powered chatbot for weather queries.

---

## 📋 Project Overview

**Weather Info Assistant** is a complete weather information system that provides users with:
- Current weather conditions for multiple cities
- 5-day weather forecasts
- Real-time weather alerts
- AI-powered chatbot for weather-related questions
- Beautiful, responsive UI optimized for all devices

---

## 🎯 Features

### 1. **Current Weather Display**
- Real-time weather data from local dataset
- Temperature, humidity, wind speed, pressure, and "feels like" temperature
- Weather condition icons and descriptions
- Multiple cities displayed in a grid layout

### 2. **5-Day Forecast**
- Detailed 5-day weather forecast for each city
- Maximum and minimum temperatures
- Weather conditions and wind speed
- Humidity information

### 3. **Weather Alerts**
- Real-time weather alerts and warnings
- Color-coded alerts (warning, danger, info)
- Specific alerts for extreme temperatures, fog, rain, etc.
- Auto-generated alerts based on weather conditions

### 4. **Search Functionality**
- Search for any city in the dataset
- Auto-complete suggestions
- Instant weather updates for selected city
- Error handling for invalid cities

### 5. **AI-Powered Chatbot**
- Floating chat icon that opens a chat window
- Ask weather-related questions naturally
- Powered by Google Generative AI (Gemini)
- Fallback responses when API is unavailable
- Clean, intuitive chat interface

### 6. **Responsive Design**
- Mobile-first design approach
- Optimized for desktop, tablet, and mobile devices
- Smooth animations and transitions
- Modern gradient backgrounds and styling

---

## 📁 Project Structure

```
WeatherInfoAssistant/
├── index.html              # Main HTML file
├── style.css              # Main stylesheet
├── script.js              # Main JavaScript (UI, Weather, Forecast, Alerts modules)
├── chatbot.js             # Chatbot module with AI integration
├── chatbot-style.css      # Chatbot styling
├── dataset.json           # Weather dataset with sample cities
└── README.md              # This file
```

---

## 🚀 How to Run the Project

### Prerequisites
- A modern web browser (Chrome, Firefox, Safari, Edge)
- Internet connection (for AI chatbot API calls)
- No server or build tools required!

### Steps to Run

1. **Download/Clone the Project**
   ```bash
   # Extract the WeatherInfoAssistant folder to your desired location
   ```

2. **Open in Browser**
   - Simply double-click `index.html` to open it in your default browser
   - OR right-click `index.html` → Open with → Select your browser

3. **Start Using**
   - View current weather for all cities on the homepage
   - Use the search bar to find weather for a specific city
   - Click the floating chat icon (💬) to open the chatbot
   - Ask weather-related questions in the chat

---

## 💻 Technical Stack

### Frontend
- **HTML5** - Semantic markup
- **CSS3** - Modern styling with gradients, animations, and flexbox/grid
- **JavaScript (ES6+)** - Modular architecture with multiple modules

### APIs & Services
- **Google Generative AI (Gemini)** - For chatbot responses
- **Local JSON Dataset** - For weather data storage

### Architecture
The project follows a modular architecture with the following modules:

1. **UI Module** - Handles all UI rendering and updates
2. **Dataset Loader Module** - Loads and manages local weather data
3. **Weather Fetch Module** - Fetches weather information
4. **Weather Forecast Module** - Manages forecast data
5. **Alerts Module** - Generates and displays weather alerts
6. **Chatbot Module** - Handles chatbot functionality and AI integration

---

## 🔧 Configuration

### API Key Setup (Optional)

The project comes with a pre-configured Google Generative AI API key. If you want to use your own:

1. Go to [Google AI Studio](https://aistudio.google.com/app/apikey)
2. Create a new API key
3. Open `chatbot.js`
4. Find the line: `apiKey: 'AIzaSyB1ChlVjhz2Z717cYX-W8IUXslDFURsCs0'`
5. Replace with your API key

### Adding More Cities

To add more cities to the dataset:

1. Open `dataset.json`
2. Add a new city object to the `cities` array:
```json
{
  "city": "Your City Name",
  "temperature": 25,
  "condition": "Sunny",
  "humidity": 60,
  "windSpeed": 15,
  "feelsLike": 24,
  "pressure": 1013,
  "forecast": [
    {
      "date": "Mon, Dec 18",
      "condition": "Sunny",
      "maxTemp": 28,
      "minTemp": 20,
      "humidity": 55,
      "windSpeed": 12
    }
    // ... 4 more days
  ]
}
```

---

## 📱 Responsive Breakpoints

- **Desktop** (1200px+) - Full layout with all features
- **Tablet** (768px - 1199px) - Optimized grid layout
- **Mobile** (480px - 767px) - Single column layout
- **Small Mobile** (< 480px) - Compact layout

---

## 🎨 Color Scheme

- **Primary**: #1e3c72 (Dark Blue)
- **Secondary**: #2a5298 (Medium Blue)
- **Accent**: #00d4ff (Cyan)
- **Danger**: #ff6b6b (Red)
- **Warning**: #ffa500 (Orange)
- **Success**: #51cf66 (Green)

---

## 🤖 Chatbot Features

### Capabilities
- Answer weather-related questions
- Provide weather advice based on conditions
- Extract city names from natural language queries
- Fallback responses when API is unavailable
- Support for multiple question formats

### Example Questions
- "Weather in Chennai?"
- "Will it rain today?"
- "What's the temperature in London?"
- "Is it cold outside?"
- "Tell me about the weather in Mumbai"

---

## 📊 Dataset Information

The `dataset.json` file contains:

### Cities Included
1. Chennai
2. Mumbai
3. Delhi
4. Bangalore
5. Kolkata
6. Hyderabad
7. Pune
8. Jaipur
9. Ahmedabad
10. Lucknow

### Data Fields per City
- `city` - City name
- `temperature` - Current temperature in Celsius
- `condition` - Weather condition (Sunny, Rainy, Cloudy, etc.)
- `humidity` - Humidity percentage
- `windSpeed` - Wind speed in km/h
- `feelsLike` - Feels like temperature in Celsius
- `pressure` - Atmospheric pressure in mb
- `forecast` - Array of 5-day forecast data

---

## 🐛 Troubleshooting

### Chatbot not responding
- Check internet connection
- Verify API key is valid
- Check browser console for errors (F12)
- Try refreshing the page

### Weather data not loading
- Ensure `dataset.json` is in the same folder as `index.html`
- Check browser console for file loading errors
- Verify JSON file is valid

### Search not working
- Ensure city name matches exactly (case-insensitive)
- Check that the city exists in `dataset.json`
- Try using the search suggestions dropdown

### Styling issues
- Clear browser cache (Ctrl+Shift+Delete)
- Ensure all CSS files are loaded
- Try a different browser
- Check that all files are in the correct location

---

## 🔐 Security Notes

- API keys are visible in the code (for demo purposes)
- In production, use environment variables or backend proxy
- Never commit API keys to public repositories
- Consider implementing rate limiting for API calls

---

## 📈 Future Enhancements

- [ ] Integration with real-time weather APIs (OpenWeatherMap, WeatherAPI)
- [ ] User location detection using geolocation
- [ ] Weather history and trends
- [ ] Multiple language support
- [ ] Dark/Light theme toggle
- [ ] Weather notifications
- [ ] Export weather data as PDF
- [ ] Integration with calendar for weather planning

---

## 📄 License

This project is open source and available for personal and educational use.

---

## 👨‍💻 Developer Notes

### Module Descriptions

#### UI Module (`UIModule`)
Handles all visual rendering:
- `displayCurrentWeather()` - Renders current weather cards
- `displayForecast()` - Renders forecast cards
- `displayAlerts()` - Renders alert boxes
- `getWeatherIcon()` - Returns emoji icon for weather condition

#### Dataset Loader Module (`DatasetLoaderModule`)
Manages local data:
- `loadDataset()` - Loads JSON file
- `getAllCities()` - Returns all cities
- `getCityData()` - Gets specific city data
- `getAllAlerts()` - Returns all alerts

#### Weather Fetch Module (`WeatherFetchModule`)
Fetches weather data:
- `fetchWeatherFromDataset()` - Gets weather from local dataset
- `getAllWeatherData()` - Gets all weather data

#### Weather Forecast Module (`WeatherForecastModule`)
Manages forecast data:
- `getForecast()` - Gets 5-day forecast
- `generateForecast()` - Generates fallback forecast

#### Alerts Module (`AlertsModule`)
Manages alerts:
- `getAllAlerts()` - Gets all alerts
- `getAlertsForCity()` - Gets city-specific alerts
- `generateAlerts()` - Generates alerts from weather data

#### Chatbot Module (`ChatbotModule`)
Handles chatbot functionality:
- `init()` - Initializes chatbot
- `sendMessage()` - Sends user message
- `getAIResponse()` - Gets response from Google Generative AI
- `getFallbackResponse()` - Provides fallback response

---

## 📞 Support

For issues or questions:
1. Check the Troubleshooting section
2. Review browser console for error messages
3. Verify all files are in correct locations
4. Ensure internet connection for chatbot

---

## ✨ Credits

- **Weather Data**: Sample dataset created for demonstration
- **Icons**: Unicode emoji characters
- **AI**: Google Generative AI (Gemini)
- **Design**: Modern gradient and responsive design principles

---

**Enjoy using Weather Info Assistant! 🌤️**
