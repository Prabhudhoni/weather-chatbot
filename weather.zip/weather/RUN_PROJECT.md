# 🚀 How to Run Your Weather Info Assistant

## Quick Start (2 Steps)

### Step 1: Start the Server
**Option A - Easiest (Windows)**
```
Double-click: START_SERVER.bat
```

**Option B - Command Line**
```bash
cd C:\Users\prabh\OneDrive\Desktop\weather
python -m http.server 8000
```

**Option C - VS Code Debug**
1. Open VS Code
2. Press `F5` or go to Run → Start Debugging
3. Select "Launch Weather App"
4. Chrome opens automatically at `http://localhost:8000`

### Step 2: Open Application
- **If using Option A or B**: Open browser and go to `http://localhost:8000`
- **If using Option C**: Chrome opens automatically

---

## ✅ What You Should See

After opening the application:
- ✅ Beautiful green gradient background
- ✅ Weather cards with 15 cities
- ✅ Search bar at the top
- ✅ 5-Day Forecast section
- ✅ Weather Alerts section
- ✅ Chatbot icon (bottom-right)
- ✅ No error messages

---

## 🎮 Features to Try

### 1. View Weather
- Scroll down to see all 15 cities
- Each shows: City, Village, District, State, Country
- Temperature, humidity, wind speed, pressure

### 2. Search Cities
- Type in search bar: "Chennai"
- Select from suggestions
- Weather updates instantly

### 3. Check Forecast
- Scroll to "5-Day Forecast"
- See temperature trends
- Check conditions for each day

### 4. Chat with Bot
- Click 💬 icon (bottom-right)
- Ask: "Weather in London?"
- Get AI response

### 5. View Alerts
- Scroll to "Weather Alerts"
- See important weather warnings

---

## 🔧 Troubleshooting

### Issue: "Failed to fetch" error
**Solution**: Make sure server is running
- Check command window is open
- Verify URL is `http://localhost:8000` (not `file://`)
- Refresh browser (Ctrl+R)

### Issue: Port 8000 already in use
**Solution**: Use different port
```bash
python -m http.server 8001
# Then go to: http://localhost:8001
```

### Issue: Python not found
**Solution**: Install Python
- Download from: https://www.python.org/downloads/
- Check "Add Python to PATH" during installation

### Issue: Chrome doesn't open with F5
**Solution**: Manual approach
1. Start server: `python -m http.server 8000`
2. Open browser: `http://localhost:8000`

---

## 📊 Project Files

| File | Purpose |
|------|---------|
| index.html | Main page |
| style.css | Styling (green background) |
| script.js | Weather logic |
| chatbot.js | Chatbot AI |
| dataset-villages.json | Weather data (15 cities) |
| START_SERVER.bat | Server starter |
| .vscode/launch.json | VS Code debug config |

---

## 🎯 Running Methods

### Method 1: Batch File (Easiest)
```
Double-click: START_SERVER.bat
Then: Open http://localhost:8000
```

### Method 2: Command Line
```bash
python -m http.server 8000
Then: Open http://localhost:8000
```

### Method 3: VS Code Debug (F5)
```
Press: F5
Chrome opens automatically
```

### Method 4: PowerShell
```
Right-click: START_SERVER.ps1
Select: Run with PowerShell
Then: Open http://localhost:8000
```

---

## 🎉 You're Ready!

Choose any method above and enjoy your Weather Info Assistant! 🌤️

**All features are working:**
- ✅ 15 cities with villages
- ✅ Green gradient background
- ✅ Search functionality
- ✅ 5-day forecasts
- ✅ Weather alerts
- ✅ AI chatbot
- ✅ Smooth animations

---

## 📞 Quick Commands

| Action | Command |
|--------|---------|
| Start server | `python -m http.server 8000` |
| Stop server | `Ctrl+C` |
| Open app | `http://localhost:8000` |
| Debug (VS Code) | Press `F5` |
| Different port | `python -m http.server 8001` |

---

**Happy exploring!** 🚀🌍
